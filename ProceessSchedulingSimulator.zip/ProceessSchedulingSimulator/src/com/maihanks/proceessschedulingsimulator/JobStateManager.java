/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package com.maihanks.proceessschedulingsimulator;

import java.awt.Color;
import java.util.concurrent.Executors;
import java.util.concurrent.locks.Condition;
import java.util.concurrent.locks.Lock;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.swing.JLabel;

/**
 *
 * @author MAIHANKS
 */
public class JobStateManager implements Runnable {

    private String schedulingAlgorithm;
    private String[] algorithms = {"FCFS", "SJF", "RR"};
    String[] jobTitles;
    int[] burstTimes;
    int[] arrivalTimes;
    JLabel[] jobStateLabel;
    private int quantumSlice;
    private int sleepTime;
    private Lock lockObject; // application lock; passed in to constructor
    private Condition suspend; // used to suspend and resume thread       
    private boolean suspended = false; // true if thread suspended        

    public JobStateManager(String theSchedulingAlgorithm, String[] theJobTitles, int[] theBurstTimes, int[] theArrivalTimes, JLabel[] theJobStateLabel, int quantumSlice,int theSimulationSpeedValue,Lock theLock) {
        this.schedulingAlgorithm = theSchedulingAlgorithm;
        this.jobTitles = theJobTitles;
        this.burstTimes = theBurstTimes;
        this.arrivalTimes = theArrivalTimes;
        this.sleepTime = theSimulationSpeedValue;
        this.jobStateLabel = new JLabel[theJobStateLabel.length - 1];
        this.lockObject = theLock;
        this.suspend = lockObject.newCondition(); 
        for (int a = 0; a < jobStateLabel.length; a++) {
            jobStateLabel[a] = theJobStateLabel[a + 1];
        }
        this.quantumSlice = quantumSlice;
    }

    @Override
    public void run() {
        //lockObject.lock();
        if (schedulingAlgorithm.equals(algorithms[0])) {//first come first serve
            firstComeFirstServe();
        } else if (schedulingAlgorithm.equals(algorithms[1])) {//first come first serve
            shortestJobFirst();
        } else if (schedulingAlgorithm.equals(algorithms[2])) {//first come first serve
            roundRobin();
        }
    }
    /**
     *
     * @return the job state manager
     */
    public JobStateManager getJobStateManager() {
        return this;
    }
    
    public void suspendThread() {
        try {
            suspend.await();
        } catch (InterruptedException ex) {
            Logger.getLogger(JobStateManager.class.getName()).log(Level.SEVERE, null, ex);
        }
    }
    
    private void firstComeFirstServe() {
        int percentageExecuted = 0;//the time factions and sleep time 
        String time;//formatted time in string
        int index;
        Color currentColor = jobStateLabel[1].getForeground();
        for (int a = 0; a < jobStateLabel.length; a++) {
            index = Integer.parseInt(jobTitles[a].substring(1));
            index--;
            while (true) {
                jobStateLabel[index].setForeground(Color.GREEN);
                try {
                    Thread.sleep(sleepTime);// duratiad sleeps for the duration denoted by sleepTime thereby halting all subsequent statements for the slotted time
                    percentageExecuted++;//when the thread awakes precisely one second has passed
                    time = percentageExecuted + "%";
                    jobStateLabel[index].setText(time);
                    if (percentageExecuted == 100) {
                        percentageExecuted = 0;
                        break;
                    }
                } catch (InterruptedException ex) {
                }//end catch
            }//end while
            jobStateLabel[index].setForeground(currentColor);
        }//end for
    }//end FirstComeFirstServe()

    private void shortestJobFirst() {
        int percentageExecuted = 0;//the time factions and sleep time 
        String time;//formatted time in string\
        int index;
        Color currentColor = jobStateLabel[1].getForeground();
        for (int a = 0; a < jobStateLabel.length; a++) {
            index = Integer.parseInt(jobTitles[a].substring(1));
            index--;
            while (true) {
                jobStateLabel[index].setForeground(Color.GREEN);
                try {
                    Thread.sleep(sleepTime);// duratiad sleeps for the duration denoted by sleepTime thereby halting all subsequent statements for the slotted time
                    percentageExecuted++;//when the thread awakes precisely one second has passed
                    time = percentageExecuted + "%";
                    jobStateLabel[index].setText(time);
                    if (percentageExecuted == 100) {
                        percentageExecuted = 0;
                        break;
                    }
                } catch (InterruptedException ex) {
                }//end catch
            }//end while
            jobStateLabel[index].setForeground(currentColor);
        }//end for

    }//end ShortestJobFirst()

    /**
     * verifies if all tasks are executed to completion
     *
     * @param percentageExecuted
     * @return
     */
    private boolean areRoundRobinTasksFinished(int[] percentageExecuted) {
        String theCounterSatus = "";
        boolean[] tasksStatus = new boolean[percentageExecuted.length];
        boolean status = false;
        for (int a = 0; a < percentageExecuted.length; a++) {
            if (percentageExecuted[a] < 100) {
             status = false;
             break;
            } else if (percentageExecuted[a] == 100) {
            status = true;
            }
        }//end for

        return status;
    }

    private boolean isSingleRoundRobinTaskFinished(int percentageExecuted) {
        boolean status = false;
        if (percentageExecuted < 100) {
            status = false;
        } else if (percentageExecuted == 100) {
            status = true;
        }
        return status;
    }

    private void roundRobin() {
       
      int[] percentageExecuted = new int[jobStateLabel.length];
        String time;//formatted time in string\
        //quantumSlice
        int quantumSliceInterval = 0;
        int index = 0;
        int counter = 0;
        Color currentColor  = jobStateLabel[1].getForeground();
        int difference = 0;
        while (areRoundRobinTasksFinished(percentageExecuted) == false) {
            for (int a = 0; a < jobStateLabel.length; a++) {
                index = Integer.parseInt(jobTitles[a].substring(1));
                index--;
                difference = 100 - percentageExecuted[a];
                while (true) {
                    jobStateLabel[index].setForeground(Color.GREEN);
                    try {
                        Thread.sleep(sleepTime);// duratiad sleeps for the duration denoted by sleepTime thereby halting all subsequent statements for the slotted time
                        percentageExecuted[a]++;//when the thread awakes precisely one second has passed
                        quantumSliceInterval++;
                        time = percentageExecuted[a] + "%";
                        jobStateLabel[index].setText(time);
                        if(difference < quantumSlice){
                        while(true){     
                           Thread.sleep(sleepTime);// duratiad sleeps for the duration denoted by sleepTime thereby halting all subsequent statements for the slotted time
                           percentageExecuted[a]++;//when the thread awakes precisely one second has passed
                           time = percentageExecuted[a] + "%";
                           jobStateLabel[index].setText(time);
                           if(percentageExecuted[a] == 100){
                           break;
                           }
                        }
                        
                        }
                        if (quantumSliceInterval == quantumSlice) {//quantumSlice exhausted,proceed to perform next task on queue
                            quantumSliceInterval = 0;
                            break;//execute next task
                        }if (percentageExecuted[a] == 100) {
                            break;
                        }
                    } catch (InterruptedException ex) {
                    }//end catch
                }//end while
                jobStateLabel[index].setForeground(currentColor);
                
            }//end for
        }//end while
    }//end RoundRobin()
}

/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package com.maihanks.proceessschedulingsimulator;

import java.awt.Color;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.concurrent.ExecutorService;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.swing.*;

/**
 *
 * @author MAIHANKS
 */
public class InterfaceDesign {
    private JFrame mainFrame;
    private final int NUMBER_OF_ROW_LABELS = 6;
    private final int MAXIMUM_NUMBER_OF_JOBS = 5;
    private final JLabel[] JobsDescription = new JLabel[NUMBER_OF_ROW_LABELS];
    private JComboBox quantumSlice;
    private JLabel quantumSliceLabel = new JLabel("Quantum Slice");
    private JLabel averageWaitingTime, averageTurnAroundTime, throughput;
    private JTextArea[] burstTimes = new JTextArea[NUMBER_OF_ROW_LABELS], arrivalTimes = new JTextArea[NUMBER_OF_ROW_LABELS];
    private JLabel burstTimesLabel = new JLabel("Burst(secs)");
    private JLabel arrivalTimesLabel = new JLabel("Arrival(secs)");
    private JComboBox algorithmComboBox;
    private JLabel algorithmLabel = new JLabel("Algorithms");
    private final String[] simulationSpeeds = {"fast", "medium", "slow"};
    private JLabel simulationSpeedLabel = new JLabel("Speed");
    private JComboBox simulationSpeedComboBox = new javax.swing.JComboBox(simulationSpeeds);
    private JLabel jobStateLabel = new JLabel("States(%)");
    private JLabel[] jobsStates = new JLabel[NUMBER_OF_ROW_LABELS];
    private final String[] algorithms = {"FCFS", "SJF", "RR"};
    private JButton executeButton = new JButton("Execute"), scheduleButton = new JButton("Schedule"), stopButton = new JButton("Stop");
    private JLabel readyQueueLabel = new JLabel("Ready Queue");
    private JLabel[] readyQueue = new JLabel[NUMBER_OF_ROW_LABELS];
    private JLabel[] currentlyExecutingJobs = new JLabel[NUMBER_OF_ROW_LABELS], currentJobsState = new JLabel[NUMBER_OF_ROW_LABELS];
    private JPanel parentPanel = new JPanel();
    private final Color descriptionColor = Color.WHITE;
    private String theAlgorithm;
    private int theQuantumSlice;
    private int[] theBurstTimes = new int[MAXIMUM_NUMBER_OF_JOBS], theArrivalTimes = new int[MAXIMUM_NUMBER_OF_JOBS];
    private boolean areInPutsValid = false;
    private SchedulingAlgorithm theCurrentSchedulingAlgorithm;
    private String[] jobTitles = {"P1", "P2", "P3", "P4", "P5"};
    private ExecutorService theRunningThread;
    private int simulationSpeedValue;
    
    public InterfaceDesign() {
        mainFrame = new JFrame("Job Scheduling Algorithms Simulator");
        algorithmComboBox = new JComboBox(algorithms);
        String[] quantumSlices = {"2 seconds", "3 seconds", "7 seconds"};
        quantumSlice = new javax.swing.JComboBox(quantumSlices);
        averageWaitingTime = new JLabel("Average Waiting Time : ");
        throughput = new JLabel("Throughput : ");
        averageTurnAroundTime = new JLabel("Average Turn Around Time : ");
        for (int a = 0; a < burstTimes.length; a++) {
            burstTimes[a] = new JTextArea();
            arrivalTimes[a] = new JTextArea();
        }
        setUpParentFrame();
        setEventHandlers();
    }

    /**
     * sets up the design for the parent frame
     */
    private void setUpParentFrame() {
        mainFrame.setBounds(200, 100, 1000, 600);
        mainFrame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setUpParentPanel();
        mainFrame.add(parentPanel);
    }

    private void setUpParentPanel() {
        parentPanel.setSize(mainFrame.getWidth(), mainFrame.getHeight());
        parentPanel.setBackground(Color.DARK_GRAY);
        parentPanel.setLayout(null);
        setUpComponents();
        parentPanel.add(algorithmLabel);
        parentPanel.add(algorithmComboBox);
        
        parentPanel.add(simulationSpeedLabel);
        parentPanel.add(simulationSpeedComboBox);

        parentPanel.add(quantumSliceLabel);
        parentPanel.add(quantumSlice);

        parentPanel.add(burstTimesLabel);

        parentPanel.add(arrivalTimesLabel);

        for (int a = 0; a < JobsDescription.length; a++) {
            parentPanel.add(JobsDescription[a]);
            if (a != 0) {
                parentPanel.add(burstTimes[a]);
                parentPanel.add(arrivalTimes[a]);
            }
        }
        parentPanel.add(scheduleButton);
        parentPanel.add(executeButton);
        parentPanel.add(stopButton);
        
        parentPanel.add(readyQueueLabel);

        parentPanel.add(jobStateLabel);

        parentPanel.add(averageWaitingTime);
        parentPanel.add(throughput);
        parentPanel.add(averageTurnAroundTime);

        //parentPanel.add(readyQueue[0]);
        for (int b = 1; b < readyQueue.length; b++) {
            parentPanel.add(readyQueue[b]);
            parentPanel.add(jobsStates[b]);
        }//end for

    }

    private void setUpComponents() {
        algorithmLabel.setBounds(10, 10, 100, 30);
        algorithmLabel.setForeground(descriptionColor);//sets the color of the text
        algorithmComboBox.setBounds(10, 40, 90, 30);
        

        quantumSliceLabel.setBounds(10, 90, 90, 30);
        quantumSliceLabel.setForeground(descriptionColor);
        quantumSlice.setBounds(10, 120, 90, 30);
        
        simulationSpeedLabel.setBounds(10, 175, 90, 30);
        simulationSpeedLabel.setForeground(descriptionColor);
        simulationSpeedComboBox.setBounds(10, 210, 90, 30);
        
        burstTimesLabel.setForeground(descriptionColor);

        arrivalTimesLabel.setForeground(descriptionColor);

        jobStateLabel.setForeground(descriptionColor);

        scheduleButton.setBounds(10, 320, 100, 30);
        executeButton.setBounds(10, 450, 100, 30);
        stopButton.setBounds(130, 450, 100, 30);
        
        readyQueueLabel.setBounds(10, 370, 100, 30);
        readyQueueLabel.setForeground(descriptionColor);

        averageWaitingTime.setBounds(600, 50, 400, 50);
        averageTurnAroundTime.setBounds(600, 100, 400, 50);
        throughput.setBounds(600, 120, 400, 50);

        averageWaitingTime.setForeground(descriptionColor);
        throughput.setForeground(descriptionColor);
        averageTurnAroundTime.setForeground(descriptionColor);

        for (int a = 0; a < JobsDescription.length; a++) {
            burstTimes[a] = new JTextArea("");
            arrivalTimes[a] = new JTextArea("");
            this.jobsStates[a] = new JLabel("0%");
            if (a == 0) {
                JobsDescription[a] = new JLabel("Jobs");
                JobsDescription[a].setBounds(algorithmComboBox.getWidth() + 40, 30, 60, 30);
                burstTimesLabel.setBounds(algorithmComboBox.getWidth() + JobsDescription[0].getWidth() + 40, 30, 90, 30);
                burstTimes[a].setBounds(algorithmComboBox.getWidth() + JobsDescription[0].getWidth() + 40, 30, 60, 30);

                arrivalTimesLabel.setBounds(algorithmComboBox.getWidth() + JobsDescription[0].getWidth() + 115, 30, 90, 30);
                arrivalTimes[a].setBounds(algorithmComboBox.getWidth() + JobsDescription[0].getWidth() + 115, 30, 60, 30);

                jobStateLabel.setBounds(algorithmComboBox.getWidth() + JobsDescription[0].getWidth() + 230, 30, 90, 30);
                this.jobsStates[a].setBounds(algorithmComboBox.getWidth() + JobsDescription[0].getWidth() + 230, 30, 90, 30);
            } else {
                JobsDescription[a] = new JLabel("P" + a);
                JobsDescription[a].setBounds(algorithmComboBox.getWidth() + 40, 30 + JobsDescription[a - 1].getY() + JobsDescription[a - 1].getHeight(), 20, 20);
                burstTimes[a].setBounds(algorithmComboBox.getWidth() + JobsDescription[0].getWidth() + 40, 30 + burstTimes[a - 1].getY() + burstTimes[a - 1].getHeight(), 50, 20);
                arrivalTimes[a].setBounds(algorithmComboBox.getWidth() + JobsDescription[0].getWidth() + 115, 30 + arrivalTimes[a - 1].getY() + arrivalTimes[a - 1].getHeight(), 50, 20);
                this.jobsStates[a].setBounds(algorithmComboBox.getWidth() + JobsDescription[0].getWidth() + 230, 21 + jobsStates[a - 1].getY() + jobsStates[a - 1].getHeight(), 90, 30);
            }//end else
            JobsDescription[a].setForeground(descriptionColor);
            jobsStates[a].setForeground(descriptionColor);
        }

        for (int b = 0; b < readyQueue.length; b++) {
            readyQueue[b] = new JLabel("P" + b);
            readyQueue[b].setForeground(Color.CYAN);
            if (b == 1) {
                readyQueue[b].setBounds(140, 370, 90, 30);
            } else if (b == 2) {
                readyQueue[b].setBounds(210, 370, 90, 30);
            } else if (b == 3) {
                readyQueue[b].setBounds(300, 370, 90, 30);
            } else if (b == 4) {
                readyQueue[b].setBounds(390, 370, 90, 30);
            } else if (b == 5) {
                readyQueue[b].setBounds(480, 370, 90, 30);
            }
        }//end for

    }

    /**
     * updates the ready queue in order of the array(theQueue) elements 1st
     * element is placed at the beginning off the queue
     *
     * @param theQueue jobs in their correct order
     */
    public void setReadyQueue(String[] theQueue) {
        for (int a = 0; a < theQueue.length; a++) {
            readyQueue[a + 1].setText(theQueue[a]);
        }
    }//end updateReadyQueue()

    /**
     * updates the state denoting the percentage of each task executed
     *
     * @param theStates
     */
    public void setStates(String[] theStates) {
        for (int a = 0; a < theStates.length; a++) {
            jobsStates[a + 1].setText(theStates[a]);
        }
    }

    public void setAverageWaitingTime(String averageWaitingTime) {
        this.averageWaitingTime.setText("Average Waiting Time : " + averageWaitingTime+" seconds");
    }

    public void setAverageTurnAroundTime(String averageTurnAroundTime) {
        this.averageTurnAroundTime.setText("Average Turn Around Time : " + averageTurnAroundTime+" seconds");
    }

    public void setThroughput(String throughput) {
        this.throughput.setText("Throughput : " + throughput+" jobs / seconds");
    }

    private String[] determineReadyQueue() {
        String[] queue = null;
        return queue;
    }

    private void collectInputs() {
                if(this.simulationSpeedComboBox.getSelectedItem().toString().equals(simulationSpeeds[0])){
        simulationSpeedValue = 90;
        }else if(this.simulationSpeedComboBox.getSelectedItem().toString().equals(simulationSpeeds[1])){
            simulationSpeedValue = 300;
        }else if(this.simulationSpeedComboBox.getSelectedItem().toString().equals(simulationSpeeds[2])){
            simulationSpeedValue = 1000;
        }
        this.theAlgorithm = this.algorithmComboBox.getSelectedItem().toString();
        if (theAlgorithm.equals(algorithms[0])) {
            theCurrentSchedulingAlgorithm = new FirstComeFirstServe(jobTitles, theBurstTimes, theArrivalTimes, theQuantumSlice,simulationSpeedValue);
        } else if (theAlgorithm.equals(algorithms[1])) {
            theCurrentSchedulingAlgorithm = new ShortestJobFirst(jobTitles, theBurstTimes, theArrivalTimes, theQuantumSlice,simulationSpeedValue);
        } else if (theAlgorithm.equals(algorithms[2])) {
            theCurrentSchedulingAlgorithm = new RoundRobin(jobTitles, theBurstTimes, theArrivalTimes, theQuantumSlice,simulationSpeedValue);
        }//end else if
        
        this.theQuantumSlice = Integer.parseInt(this.quantumSlice.getSelectedItem().toString().charAt(0)+"");
        areInPutsValid = true;
        for (int a = 1; a < this.burstTimes.length; a++) {
            try {
                this.theBurstTimes[a - 1] = Integer.parseInt(this.burstTimes[a].getText().toString());
                this.theArrivalTimes[a - 1] = Integer.parseInt(this.arrivalTimes[a].getText().toString());
            } catch (NumberFormatException ex) {
                areInPutsValid = false;
                break;//exits loop
            }
        }//end for
    }//end collectInputs()

    /**
     * sets up event handlers
     */
    private boolean areOutputsValid(String[] inputs){
        boolean status = false;
        
        return status;
    }
    private void setEventHandlers() {

        this.scheduleButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                collectInputs();
                String[] stattState = {"0%", "0%", "0%", "0%", "0%"};
                setStates(stattState);
                setReadyQueue(theCurrentSchedulingAlgorithm.getReadyQueue());
                setReadyQueue(theCurrentSchedulingAlgorithm.getReadyQueue());
            }
        });
        this.executeButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                collectInputs();
                if(areInPutsValid==true){
                setReadyQueue(theCurrentSchedulingAlgorithm.getReadyQueue());
                theRunningThread =  theCurrentSchedulingAlgorithm.setJobState(jobsStates);
                setAverageWaitingTime(theCurrentSchedulingAlgorithm.getAverageWaitingTime() + "");
                setAverageTurnAroundTime(theCurrentSchedulingAlgorithm.getAverageTurnAroundTime() + "");
                setThroughput(theCurrentSchedulingAlgorithm.getThroughput() + "");
                }else{
                JOptionPane.showMessageDialog(null, "Some inputs are invalid, please ensure that\n that you enter numbers as inputs");
                }
            }
        });
        
        this.stopButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
              mainFrame.dispose();  
              InterfaceDesign interfaceDesign = new InterfaceDesign();
              interfaceDesign.displayInterface();
            }
        });
        
    }//end setEventHandlers()

    /**
     * displays this interface and it's associated components
     */
    public void displayInterface() {
        mainFrame.setVisible(true);
    }//end displayInterface()

    public static void main(String[] args) {
        // TODO code application logic here
        InterfaceDesign interfaceDesign = new InterfaceDesign();
        interfaceDesign.displayInterface();
        
    }
}

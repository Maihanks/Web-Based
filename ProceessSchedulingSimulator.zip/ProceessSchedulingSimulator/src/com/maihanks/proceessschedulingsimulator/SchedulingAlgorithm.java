/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package com.maihanks.proceessschedulingsimulator;

import java.util.concurrent.ExecutorService;
import javax.swing.JLabel;

/**d
 *
 * @author MAIHANKS
 */
public interface SchedulingAlgorithm {
   public String[] getReadyQueue();
   public int[] getJobsState();
   public ExecutorService setJobState(JLabel[] jobsStates);
   public int[] getReadyQueueBurstTimes();
   public int[] getReadyQueueArrivalTimes();
   public double getAverageWaitingTime();
   public double getAverageTurnAroundTime();
   public double getThroughput();
   public JobStateManager getJobStateManager();
}

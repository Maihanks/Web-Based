/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package com.maihanks.proceessschedulingsimulator;

import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.locks.Lock;
import java.util.concurrent.locks.ReentrantLock;
import javax.swing.JLabel;

/**
 *
 * @author MAIHANKS
 */
public class RoundRobin implements SchedulingAlgorithm {
private Lock lockObject = new ReentrantLock(true); // single lock
    private FirstComeFirstServe firstComeFirstServe;
    private String[] readyQueue;
    int[] readyQueueBurstTimes, readyQueueArrivalTimes;
    int[] burstTimes, arrivalTimes;
    private String[] jobTitles;
    private int quantumSlice;
    private JobStateManager jobStateManager;
private int simulationSpeedValue  = 0;
    public RoundRobin(String[] jobTitles, int[] burstTimes, int[] arrivalTimes, int quantumSlice,int theSimulationSpeedValue) {
        this.jobTitles = jobTitles;
        this.burstTimes = burstTimes;
        this.arrivalTimes = arrivalTimes;
        this.quantumSlice = quantumSlice;
        this.simulationSpeedValue = theSimulationSpeedValue;
        firstComeFirstServe = new FirstComeFirstServe(jobTitles, burstTimes, arrivalTimes, quantumSlice,simulationSpeedValue);
        readyQueue = firstComeFirstServe.getReadyQueue();
        readyQueueBurstTimes = firstComeFirstServe.getReadyQueueBurstTimes();
        readyQueueArrivalTimes = firstComeFirstServe.getReadyQueueArrivalTimes();    
    }

    @Override
    public String[] getReadyQueue() {
        return readyQueue;
    }

    @Override
    public int[] getReadyQueueBurstTimes() {
        return readyQueueBurstTimes;
    }

    @Override
    public int[] getReadyQueueArrivalTimes() {
        return readyQueueArrivalTimes;
    }

    @Override
    public int[] getJobsState() {
        throw new UnsupportedOperationException("Not supported yet.");
    }

    @Override
    public ExecutorService setJobState(JLabel[] jobsStates) {
        jobStateManager = new JobStateManager("RR", readyQueue, readyQueueBurstTimes, readyQueueArrivalTimes, jobsStates, quantumSlice,simulationSpeedValue,lockObject);
        ExecutorService threadExecutor = Executors.newFixedThreadPool(1);
        threadExecutor.execute(jobStateManager); //execute thread
        return threadExecutor;
    }
    @Override
    public JobStateManager getJobStateManager(){
return jobStateManager;
}
    @Override
    public double getAverageWaitingTime() {
        int time0 = 0, time1 = 0, time2 = 0, time3 = 0, time4 = 0;
        int waitTime0 = 0, waitTime1 = 0, waitTime2 = 0, waitTime3 = 0, waitTime4 = 0;
        time0 = readyQueueArrivalTimes[0] + readyQueueBurstTimes[0];
        if (readyQueueArrivalTimes[1] < time0) {
            waitTime1 = time0 - readyQueueArrivalTimes[1];
            time1 = time0 - readyQueueArrivalTimes[1] + readyQueueBurstTimes[1];
        } else {
            time1 = readyQueueArrivalTimes[1] + readyQueueBurstTimes[1];
        }

        if (readyQueueArrivalTimes[2] < time1) {
            waitTime2 = time1 - readyQueueArrivalTimes[2];
            time2 = time1 - readyQueueArrivalTimes[2] + readyQueueBurstTimes[2];
        } else {
            time2 = readyQueueArrivalTimes[2] + readyQueueBurstTimes[2];
        }

        if (readyQueueArrivalTimes[3] < time2) {
            waitTime3 = time2 - readyQueueArrivalTimes[3];
            time3 = time2 - readyQueueArrivalTimes[3] + readyQueueBurstTimes[3];
        } else {
            time3 = readyQueueArrivalTimes[3] + readyQueueBurstTimes[3];
        }
        if (readyQueueArrivalTimes[4] < time3) {
            waitTime4 = time3 - readyQueueArrivalTimes[4];
            time4 = time3 - readyQueueArrivalTimes[4] + readyQueueBurstTimes[4];
        } else {
            time4 = readyQueueArrivalTimes[4] + readyQueueBurstTimes[4];
        }
        double totalWaitTime = waitTime0 + waitTime1 + waitTime2 + waitTime3 + waitTime4;
        double averageWaitTime = totalWaitTime / 5.0;
        return Utilities.approximateValue(averageWaitTime);
    }

    @Override
    public double getAverageTurnAroundTime() {
        double averageTurnAroundTime = 0;
        int time0 = 0, time1 = 0, time2 = 0, time3 = 0, time4 = 0;
        time0 = readyQueueArrivalTimes[0] + readyQueueBurstTimes[0];

        if (readyQueueArrivalTimes[1] < time0) {
            time1 = time0 - readyQueueArrivalTimes[1] + readyQueueBurstTimes[1];
        } else {
            time1 = readyQueueArrivalTimes[1] + readyQueueBurstTimes[1];
        }

        if (readyQueueArrivalTimes[2] < time1) {
            time2 = time1 - readyQueueArrivalTimes[2] + readyQueueBurstTimes[2];
        } else {
            time2 = readyQueueArrivalTimes[2] + readyQueueBurstTimes[2];
        }

        if (readyQueueArrivalTimes[3] < time2) {
            time3 = time2 - readyQueueArrivalTimes[3] + readyQueueBurstTimes[3];
        } else {
            time3 = readyQueueArrivalTimes[3] + readyQueueBurstTimes[3];
        }

        if (readyQueueArrivalTimes[4] < time3) {
            time4 = time3 - readyQueueArrivalTimes[4] + readyQueueBurstTimes[4];
        } else {
            time4 = readyQueueArrivalTimes[4] + readyQueueBurstTimes[4];
        }
        int totalWaitTime = time0 + time1 + time2 + time3 + time4;
        int totalBurstTime = readyQueueBurstTimes[0] + readyQueueBurstTimes[1] + readyQueueBurstTimes[2] + readyQueueBurstTimes[3] + readyQueueBurstTimes[4];
        int totalArivalTime = readyQueueArrivalTimes[0] + readyQueueArrivalTimes[1] + readyQueueArrivalTimes[2] + readyQueueArrivalTimes[3] + readyQueueArrivalTimes[4];
        int turnAroundTime = totalWaitTime + totalBurstTime - totalArivalTime;
        averageTurnAroundTime = turnAroundTime / 5;

        return Utilities.approximateValue(averageTurnAroundTime);
    }

    @Override
    public double getThroughput() {
        double systemTime = 0.0;
        int time0 = 0, time1 = 0, time2 = 0, time3 = 0, time4 = 0;
        time0 = readyQueueArrivalTimes[0] + readyQueueBurstTimes[0];

        if (readyQueueArrivalTimes[1] < time0) {
            time1 = time0 - readyQueueArrivalTimes[1] + readyQueueBurstTimes[1];
        } else {
            time1 = readyQueueArrivalTimes[1] + readyQueueBurstTimes[1];
        }

        if (readyQueueArrivalTimes[2] < time1) {
            time2 = time1 - readyQueueArrivalTimes[2] + readyQueueBurstTimes[2];
        } else {
            time2 = readyQueueArrivalTimes[2] + readyQueueBurstTimes[2];
        }

        if (readyQueueArrivalTimes[3] < time2) {
            time3 = time2 - readyQueueArrivalTimes[3] + readyQueueBurstTimes[3];
        } else {
            time3 = readyQueueArrivalTimes[3] + readyQueueBurstTimes[3];
        }

        if (readyQueueArrivalTimes[4] < time3) {
            time4 = time3 - readyQueueArrivalTimes[4] + readyQueueBurstTimes[4];
        } else {
            time4 = readyQueueArrivalTimes[4] + readyQueueBurstTimes[4];
        }

        double totalTime = time0 + time1 + time2 + time3 + time4;
        double throughput = 5 / totalTime;
        return Utilities.approximateValue(throughput);
    }
}

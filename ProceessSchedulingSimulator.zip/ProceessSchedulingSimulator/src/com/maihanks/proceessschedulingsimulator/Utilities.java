/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package com.maihanks.proceessschedulingsimulator;

/**
 *
 * @author MAIHANKS
 */
public class Utilities {

    public static double approximateValue(double number) {
        double answer = 0.0;
        int decimalIndex = 0;
        String numInString = number + "";
        String decimalPortionString = "";
        String integerPortionString = "";
        String answerString = "";
        try{
        decimalIndex = numInString.indexOf(".");
        integerPortionString = numInString.substring(0, decimalIndex);
        decimalPortionString = numInString.substring(decimalIndex + 1);
        
        if(decimalPortionString.length()>4){
            answerString = integerPortionString + "."+decimalPortionString.substring(0, 4);
            answer = Double.parseDouble(answerString);
        }else{
        answer = number;
        }
         }catch(Exception e){
        
        }
        return answer;
    }

    public static void main(String[] args) {
        double number = 1.0/3.0;
        double approximatedValue = approximateValue(number);
        System.out.println("approximated value = "+approximatedValue);
    }
}

<?php
session_start();
include_once ("classes/class.company.php");
include_once ("classes/class.login.php");
include_once ("classes/class.database.php");
include("connect.php");
$databaseAccess = new Database();
$databaseAccess->connectToDatabase();
$companyObj = new Company();

$patientUsername = $_SESSION['username'];
#$_SESSION['diary_pain_case_id'] = ;   
$diary1_pain_case_id = $_SESSION['diary_pain_case_id'];
#$case_id = $theDiary_pain_case_id;
#if ($patientUsername != "") {
    ?>
    <!DOCTYPE html>
    <html>
        <head>
            <meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
            <title>PAIN DIARY</title>
            <link rel="stylesheet" type="text/css" href="myCss/basic.css" />     
        </head>
        <body>
            <form name="form1" method="post" action="">
                <div id="headContainer">
                    <div id="head"><div id="appName">PAIN DIARY</div><!--Links to several pages -->

                    </div>
                    <div id="navigation">
                        <div id="links">
                            <a href = "physicianHome.php">Home</a>                                                                                                                                                                                
                            <a href = "index.php">Log-out</a>     
    
                            <div id="loginFields">                             
                            </div>
                            <font size="3.4" color="green"></font>
                        </div>
                    </div>
                </div>
            </form>
            <div id="page">
                <div id="left-content"><!--left content -->
                    <b> >->->COMPLAINT INBOX<-<-<-</b> <br>
                        <table border="1" bgcolor="silver">   
                            <tr>
                                <td>
                                    <b>Sender</b>    
                                </td>                                
                                <td>
                                    <b>Message</b>
                                </td>
                                <td>
                                    <b>Date & Time</b>
                                </td>
                            </tr>
                            <?php                                                         
                            $theresult = mysqli_query($conn, "SELECT * FROM complaint order by date");                            
                            
                            if( mysqli_num_rows($theresult)==0 ){
                                ?><tr><td colspan="3"> <?php echo '<font color="red">No response messages to complaints available</font>'; ?> </td></tr> <?php 
                            }else{
                            while ($rowA = mysqli_fetch_array($theresult)){ 
                                $rbt = $rowA['user_id'];
                                $tR = mysqli_fetch_array( mysqli_query($conn, "SELECT * FROM patient_biodata where username='$rbt'"));                                 
                                ?>
                            <tr>
                                <td><?php echo $tR['names'].'('.$tR['country'].')'; ?> </td>
                                <td><?php echo $rowA['complaint']; ?>   </td>
                                <td><?php echo $rowA['date'].' '.$rowA['time']; ?>  </td>                                
                            </tr>
                                <?php  }                                 
                            } ?>                            
                        </table>                    
                    
                </div>
                <div id="middle-content">
                
                <form name="form3" action="" method="post" enctype="multipart/form-data" >   
                        <table border="1" bgcolor="grey">                
                            <b>  <font color="black" size="3.3" > <i> Drop your complaint</i> </font></b>                                 
                            <tr>
                                <td>
                                    Patient/Country
                                </td>
                                <td>
                                 Complaint  Message
                                </td>                                
                            </tr>
                            <tr>
                                
                                <tr>                                 
                           <?php 
                    $r2 = mysqli_query($conn, "SELECT * FROM patient_biodata");
                    $n1 = mysqli_num_rows($r2);
                    $record_id = 'R000' . $n1;                
                    $recipientUsername = "";
                    $recipientName = "";
                    $recipientCountry = "";
                    $xy = "";
                    ?>          <td colspan="2">                                                                                                               
                                    <select name="recipientId" id="recipientId" required>                                       
                                        <option value="">Choose Recipient</option>
                                    <?php    
                                        while ($row = $r2->fetch_assoc()) { 
                                                $recipientUsername = $row["username"];
                                                $recipientName =  $row["names"];
                                                $recipientCountry = $row["country"];
                                                $xy = $recipientName."(".$recipientCountry.")";                                                                                                                                                
                                    ?>                                                                                                                                         
                                        <option value="<?php echo $row["username"] ?>"><?php echo $xy;?> </option>                                                                                                             
                                <?php                                                
                                }// end while
                                ?>                                    
                                </select>  
                                     </td>
                            </tr>
                                
                                <td>
                                <textarea  name="message" id="message" cols="20" rows="10" required>
                                </textarea>
                                </td>
                            </tr>
                            
                            <tr>
                                <td colspan="2" align="right">
                                    <input type="submit" name="sendMessageButton"  value="send message">
                                </td>
                            </tr>
                        </table>
                        <?php                                                 
                        if (array_key_exists('sendMessageButton', $_POST)) {                                                         
                            $message = $_POST['message'];
                                                      
                            $ar = mysqli_query($conn, "SELECT * FROM complaint_response");
                            $nr = mysqli_num_rows($ar) + 1;
                            $complaint_id = 'CR000' . $nr;
                            //$sender_id = $patientUsername;
                            $complaint_patient_id = $_POST['recipientId']; 
                            
                            //message_id 	sender_id 	recepient_id 	message 	date 	time 	                            
                            $fieldNamesArray[0] = "id";                                $fieldValuesArray[0] = $complaint_id;
                            $fieldNamesArray[1] = "complaint_id";                      $fieldValuesArray[1] = $complaint_id;
                            $fieldNamesArray[2] = "complaint_patient_id";              $fieldValuesArray[2] = $complaint_patient_id;
                            $fieldNamesArray[3] = "responder_id";                      $fieldValuesArray[3] = "phy1";
                            $fieldNamesArray[4] = "response";                          $fieldValuesArray[4] = $message;                                                        
                            $fieldNamesArray[5] = "date";                              $fieldValuesArray[5] = date('h:i:s a').','.date('d/m/Y');
                            
                           //echo 'recepientId='.$recipientId;
                            $databaseAccess->insertRecord("", "complaint_response", $fieldNamesArray, $fieldValuesArray);                                                        
                 ?>
                <script>alert("Response sent")</script> 
                <?php  
                echo "<meta http-equiv=\"refresh\" content=\"0;URL=attendTocomplaintByPhysician.php\">";
                        }
                        ?>
                    </form>
                </div>
                
                <div id="right-content"><!--right content -->
                    <b> ->RESPONSES TO COMPLAINT MESSAGES<-</b> <br>
                        <table border="1" bgcolor="#9FE2BF">   
                            <tr>                             
                                <td>
                                    <b>Patient</b>
                                </td>
                                <td>
                                    <b>Message</b>
                                </td>
                                <td>
                                    <b>Date & Time</b>
                                </td>
                            </tr>
                            <?php 
                            //$theresult = mysqli_query($conn, "SELECT * FROM pain_record where recipient_id='$patientUsername' group by sender_id");
                            $thers = mysqli_query($conn, "SELECT * FROM complaint_response order by date");                            
                            
                            if( mysqli_num_rows($thers)==0 ){
                                ?><tr><td colspan="3"> <?php echo 'No Sent messages available'; ?> </td></tr> <?php 
                            } else{
                            while ($rowA2 = mysqli_fetch_array($thers)){  
                                $ds = $rowA2['complaint_patient_id'];
                 $tty = mysqli_fetch_array( mysqli_query($conn, "SELECT * FROM patient_biodata where username='$ds'"));                                                                                                                 
                                                $recipientName =  $tty["names"];
                                                $recipientCountry = $tty["country"];
                                                $xy = $recipientName."(".$recipientCountry.")"; 
                                ?>
                            <tr>
                                <td><?php echo $xy; ?>   </td>
                                <td><?php echo $rowA2['response']; ?>   </td>
                                <td><?php echo $rowA2['date']; ?>  </td>                                
                            </tr>
                                <?php
                            }                                 }
                            ?>                            
                        </table>
                    <br><br><br>
                    
                </div>                
                <div id="footer">Copyright &copy;  <?php echo "Munura Maihankali"; ?> MSc Dissertation| 2021 </div>
            </div>
        </body>
    </html>
    <?php
?>
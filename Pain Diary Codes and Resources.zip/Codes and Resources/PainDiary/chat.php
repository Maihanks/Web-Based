<?php
session_start();
include_once ("classes/class.company.php");
include_once ("classes/class.login.php");
include_once ("classes/class.database.php");
include("connect.php");
$databaseAccess = new Database();
$databaseAccess->connectToDatabase();
$companyObj = new Company();

$patientUsername = $_SESSION['username'];
#$_SESSION['diary_pain_case_id'] = ;   
$diary1_pain_case_id = $_SESSION['diary_pain_case_id'];
#$case_id = $theDiary_pain_case_id;
#if ($patientUsername != "") {
    ?>
    <!DOCTYPE html>
    <html>
        <head>
            <meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
            <title>PAIN DIARY</title>
            <link rel="stylesheet" type="text/css" href="myCss/basic.css" />     
        </head>
        <body>
            <form name="form1" method="post" action="">
                <div id="headContainer">
                    <div id="head"><div id="appName">PAIN DIARY</div><!--Links to several pages -->

                    </div>
                    <div id="navigation">
                        <div id="links">
                            <a href = "patientHome.php">Home</a>                                                                                                                        
                            <a href = "complaint.php">Complaint</a> 
                            <a href = "https://www.webmd.com/pain-management/guide/pain-management-treatment-care">Learn About Pain</a>  
                            <a href = "index.php">Log-out</a>     
    
                            <div id="loginFields">                             
                            </div>
                            <font size="3.4" color="green"></font>
                        </div>
                    </div>
                </div>
            </form>
            <div id="page">
                <div id="left-content"><!--left content -->
                    <b> .................INBOX............</b> <br>
                        <table border="1" bgcolor="silver">   
                            <tr>
                                <td>
                                    <b>Sender</b>    
                                </td>                                
                                <td>
                                    <b>Message</b>
                                </td>
                                <td>
                                    <b>Date & Time</b>
                                </td>
                            </tr>
                            <?php 
                            //$theresult = mysqli_query($conn, "SELECT * FROM pain_record where recipient_id='$patientUsername' group by sender_id");
                            $theresult = mysqli_query($conn, "SELECT * FROM chat_message where recepient_id='$patientUsername' order by sender_id");                            
                            
                            if( mysqli_num_rows($theresult)==0 ){
                                ?><tr><td colspan="3"> <?php echo 'No messages available'; ?> </td></tr> <?php 
                            }else
                            {
                            while ($rowA = mysqli_fetch_array($theresult)) {    
                                ?>
                            <tr>
                                <?php 
                                $snId = $rowA['sender_id'];
                               $ry = mysqli_fetch_array(mysqli_query($conn, "SELECT * FROM patient_biodata where username='$snId' "));                             ?>
                                
                                <td><?php echo $ry['names']."(".$ry['country'].")"; ?></td>
                                <td><?php echo $rowA['message']; ?>   </td>
                                <td><?php echo $rowA['date'].' '.$rowA['time'];; ?>  </td>                                
                            </tr>
                                <?php
                            }     
                            
                            }
                            ?>                            
                        </table>                    
                    
                </div>
                <div id="middle-content">
                
                <form name="form3" action="" method="post" enctype="multipart/form-data" >   
                        <table border="1" bgcolor="grey">                
                            <b>  <font color="black" size="3.3" > <i> Share your pain experience by chatting with co-patients</i> </font></b>                                 
                            <tr>
                                <td>
                                    Patient/Location
                                </td>
                                <td>
                                    message
                                </td>                                
                            </tr>
                            <tr>                                 
                           <?php 
                    $r2 = mysqli_query($conn, "SELECT * FROM patient_biodata");
                    $n1 = mysqli_num_rows($r2);
                    $record_id = 'R000' . $n1;                
                    $recipientUsername = "";
                    $recipientName = "";
                    $recipientCountry = "";
                    $xy = "";
                    ?>          <td>                                                                                                               
                                    <select name="recipientId" id="recipientId" required>                                       
                                        <option value="">Choose Recipient</option>
                                    <?php    
                                        while ($row = $r2->fetch_assoc()) { 
                                                $recipientUsername = $row["username"];
                                                $recipientName =  $row["names"];
                                                $recipientCountry = $row["country"];
                                                $xy = $recipientName."(".$recipientCountry.")";
                                                
                                                if($recipientUsername != $patientUsername){
                                    ?>                                                                                                                                         
                                        <option value="<?php echo $row["username"];?>"><?php echo $xy;?> </option>                                                                                                             
                                <?php
                                                }//end if
                                }// end while
                                ?>                                    
                                </select>  
                                     </td>
                                <td>
                                <textarea  name="message" id="message" cols="20" rows="10" required>
                                </textarea>
                                </td>
                            </tr>
                            
                            <tr>
                                <td colspan="2" align="right">
                                    <input type="submit" name="sendMessageButton"  value="send message">
                                </td>
                            </tr>
                        </table>
                        <?php                                                 
                        if (array_key_exists('sendMessageButton', $_POST)) {                             
                            $recipientId = $_POST['recipientId'];
                            $message = $_POST['message'];
                                                      
                            $ar = mysqli_query($conn, "SELECT * FROM chat_message");
                            $nr = mysqli_num_rows($ar) + 1;
                            $message_id = 'M000' . $nr;
                            $sender_id = $patientUsername;
                            
                            //message_id 	sender_id 	recepient_id 	message 	date 	time 	                            
                            $fieldNamesArray[0] = "message_id";                             $fieldValuesArray[0] = $message_id;
                            $fieldNamesArray[1] = "sender_id";                              $fieldValuesArray[1] = $sender_id;
                            $fieldNamesArray[2] = "recepient_id";                           $fieldValuesArray[2] = $recipientId;
                            $fieldNamesArray[3] = "message";                                $fieldValuesArray[3] = $message;                            
                            $fieldNamesArray[4] = "date";                                   $fieldValuesArray[4] = date('d/m/Y');
                            $fieldNamesArray[5] = "time";                                   $fieldValuesArray[5] = date('h:i:s a');
                            
                            $currentDate = date('d/m/Y');
                            $currentTime = date('h:i:s a');
                           //echo 'recepientId='.$recipientId;
                            $databaseAccess->insertRecord("", "chat_message", $fieldNamesArray, $fieldValuesArray);                                                        

                 ?>
                <script>alert("Message sent")</script> 
                <?php  
                echo "<meta http-equiv=\"refresh\" content=\"0;URL=chat.php\">";
                        }
                        ?>
                    </form>
                </div>
                
                <div id="right-content"><!--right content -->
                    <b> ...........SENT MESSAGES..........</b> <br>
                        <table border="1" bgcolor="#9FE2BF">   
                            <tr>
                                <td>
                                    <b>Recepient</b>    
                                </td>                                
                                <td>
                                    <b>Message</b>
                                </td>
                                <td>
                                    <b>Date & Time</b>
                                </td>
                            </tr>
                            <?php 
                            //$theresult = mysqli_query($conn, "SELECT * FROM pain_record where recipient_id='$patientUsername' group by sender_id");
                            $thers = mysqli_query($conn, "SELECT * FROM chat_message where sender_id='$patientUsername' order by recepient_id");                            
                            
                            if( mysqli_num_rows($thers)==0 ){
                                ?><tr><td colspan="3"> <?php echo 'No Sent messages available'; ?> </td></tr> <?php 
                            } else{
                            while ($rowA2 = mysqli_fetch_array($thers)) {    
                                ?>
                            <tr>
                                <?php 
                                $snId = $rowA2['recepient_id'];
                               $rz = mysqli_fetch_array(mysqli_query($conn, "SELECT * FROM patient_biodata where username='$snId' "));                             ?>
                                
                                <td><?php   echo $rz['names']."(".$rz['country'].")"; ?></td>
                                <td><?php echo $rowA2['message']; ?>   </td>
                                <td><?php echo $rowA2['date'].' '.$rowA2['time'];; ?>  </td>                                
                            </tr>
                                <?php
                            }     
                            
                            }
                            ?>                            
                        </table>
                    <br><br><br>

                    
                </div>                
                <div id="footer">Copyright &copy;  <?php echo "Munura Maihankali"; ?> MSc Dissertation| 2021 </div>
            </div>
        </body>
    </html>
    <?php
#} else {
#    echo "<meta http-equiv=\"refresh\" content=\"0;URL=index.php\">";
#}
?>
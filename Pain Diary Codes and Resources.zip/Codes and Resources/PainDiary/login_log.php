<?php
session_start();
#session_destroy();
#session_start();
include_once ("classes/class.company.php");
include_once ("classes/class.login.php");
include_once ("classes/class.database.php");
$databaseAccess = new Database();
$databaseAccess->connectToDatabase();
$companyObj = new Company();
?>
<!DOCTYPE html>
<html>
    <head>
        <meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
        <title>PAIN DIARY</title>
        <link rel="stylesheet" type="text/css" href="myCss/basic.css" />     
    </head>
    <body>
        <form name="form1" method="post" action="">
            <div id="headContainer">
                <div id="head"><div id="appName">PAIN DIARY</div><!--Links to several pages -->

                </div>
                <div id="navigation">
                    <div id="links">
                        <a href="adminHome.php">Home </a>                           
                        <a href = "index.php">Log-out</a>     
                        <div id="loginFields"> 
                        </div>
                        <font size="3.4" color="green"></font>
                    </div>
                </div>
            </div>
        </form>
        <div id="page">
            <div id="left-content"><!--left content -->

            </div>
            <div id="middle-content">
                <form name="form2" action="" method="post" enctype="multipart/form-data" >
                    <table border="1">                
                        <b>  <font color="black" size="3.3" > SYSTEM LOGS </font></b>                                 
                        <tr>
                            <td>
                                Username        
                            </td>
                            <td>
                                Names
                            </td>
                            <td>
                                Date
                            </td>
                            <td>
                                Time
                            </td>
                        </tr>    
                        <?php
                        $sql = "SELECT * FROM login_log";
                        $result = $conn->query($sql);
                        if ($result->num_rows > 0) {
                            while ($row = $result->fetch_assoc()) {
                                ?><tr>  
                                    <td><?php echo $row["username"]; ?></td>>
                                    <td><?php
                                        $us = $row["username"];
                                        ;
                                        $firstStringCharacter = substr($row["username"], 0, 1);
                                        $the_names = "";
                                        if ($firstStringCharacter == 'a') {//administrator 
                                            $fg = mysqli_fetch_assoc(mysqli_query($conn, "SELECT * FROM administrator_biodata where username='$us'"));
                                            $the_names = $fg['names'];
                                        } else if ($firstStringCharacter == 'u') {//patient  
                                            $fg = mysqli_fetch_assoc(mysqli_query($conn, "SELECT * FROM patient_biodata where username='$us'"));
                                            $the_names = $fg['names'];
                                        } else if ($firstStringCharacter == 'p') {// physician                                
                                            $fg = mysqli_fetch_assoc(mysqli_query($conn, "SELECT * FROM physician_biodata where username='$us'"));
                                            $the_names = $fg['name'];
                                        }

                                        echo $the_names;
                                        ?></td>>
                                    <td><?php echo $row["date"]; ?></td>>
                                    <td><?php echo $row["time"]; ?></td>>
                                    <?php
                                }//end while
                                ?></tr>
                                <?php
                        }//end if                                    
                        ?>
                    </table>
                </form>
            </div>
            <div id="middle-content">

            </div>
            <div id="right-content"><!--right content -->

            </div>
            <div id="footer">Copyright &copy;  <?php echo "Munura Maihankali"; ?> MSc Dissertation| 2021 </div>
        </div>
    </body>
</html>

<?php
session_start();
include_once ("classes/class.company.php");
include_once ("classes/class.login.php");
include_once ("classes/class.database.php");
include("connect.php");
$databaseAccess = new Database();
$databaseAccess->connectToDatabase();
$companyObj = new Company();

$patientUsername = $_SESSION['username'];
$r = mysqli_query($conn, "SELECT * FROM pain_case");
$n = mysqli_num_rows($r) + 1;
$case_id = 'P000' . $n;
#if ($patientUsername != "") {
    ?>
    <!DOCTYPE html>
    <html>
        <head>
            <meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
            <title>PAIN DIARY</title>
            <link rel="stylesheet" type="text/css" href="myCss/basic.css" />     
        </head>
        <body>
            <form name="form1" method="post" action="">
                <div id="headContainer">
                    <div id="head"><div id="appName">PAIN DIARY</div><!--Links to several pages -->

                    </div>
                    <div id="navigation">
                        <div id="links">                                 
                            <a href  = "chat.php">Chat</a>                             
                            <a href = "#">Complaint</a>
                            <a href = "#">Contact Us</a> 
                            <a href = "https://www.webmd.com/pain-management/guide/pain-management-treatment-care">Learn About Pain</a>                                                                                      
                            <a href = "index.php">Log-out</a>     
                            <div id="loginFields">                             
                            </div>
                            <font size="3.4" color="green"></font>
                        </div>
                    </div>
                </div>
            </form>
            <div id="page">
                <div id="left-content"><!--left content -->

                    <form name="form2" action="" method="post" enctype="multipart/form-data" >
                        <?php
                        if (array_key_exists('createCase', $_POST)) {

                            $fieldNamesArray[0] = "case_id";
                            $fieldValuesArray[0] = $case_id;
                            $fieldNamesArray[1] = "patient_id";
                            $fieldValuesArray[1] = $patientUsername;
                            $fieldNamesArray[2] = "type_of_pain";
                            $fieldValuesArray[2] = $_POST['type_of_pain'];
                            $fieldNamesArray[3] = "cause_of_pain";
                            $fieldValuesArray[3] = $_POST['cause_of_pain'];
                            $fieldNamesArray[4] = "pain_location";
                            $fieldValuesArray[4] = $_POST['pain_location'];
                            $fieldNamesArray[5] = "intensity";
                            $fieldValuesArray[5] = $_POST['intensity'];
                            $fieldNamesArray[6] = "duration";
                            $fieldValuesArray[6] = $_POST['duration'];
                            $fieldNamesArray[7] = "medication";
                            $fieldValuesArray[7] = $_POST['medication'];
                            $fieldNamesArray[8] = "diet";
                            $fieldValuesArray[8] = $_POST['diet'];
                            $fieldNamesArray[9] = "date";
                            $fieldValuesArray[9] = date('d/m/Y h:i:s a', time());
                            $fieldNamesArray[10] = "lifestyle";
                            $fieldValuesArray[10] = $_POST['lifestyle'];
                            $fieldNamesArray[11] = "allergy";
                            $fieldValuesArray[11] = $_POST['allergy'];
                            $fieldNamesArray[12] = "height";
                            $fieldValuesArray[12] = $_POST['height'];
                            $fieldNamesArray[13] = "weight";
                            $fieldValuesArray[13] = $_POST['weight'];

                            $databaseAccess->insertRecord("", "pain_case", $fieldNamesArray, $fieldValuesArray);
                            ?>
                <script>alert("Successful entry")</script>
                <?php             
                echo "<meta http-equiv=\"refresh\" content=\"0;URL=patientHome.php\">";                            
                        }//end if when submit button is clicked
                        ?>
                        <table border="2" bgcolor="silver">        
                            <tr>
                                <td colspan="2" align="center">
                                    <b>  <font color="blue" size="3.3" ><i> NEW PAIN CASE </i></font></b>                              
                                </td>
                            </tr>                        

                            <tr>
                                <td>
                                    Patient Username:
                                </td>
                                <td>
    <?php echo $patientUsername; ?>
                                </td>
                            </tr>                       
                            
                            <tr>
                                <td>
                                    Age:
                                </td>
                                <td>
                <?php                 
            
            $sql1 = "SELECT * FROM patient_biodata where username ='$patientUsername' ";
            $result1 = $conn->query($sql1);     
            $r1 = $result1->fetch_assoc();
                echo $r1["age"];
            
                    #    echo $r1["age"];                    
                    #echo $patientAge;                
                 ?>
                                </td>
                            </tr>                                                   

                            <tr>
                                <td>
                                    case Id  	                                
                                </td>                            
                                <td>
    <?php
    echo $case_id;
    ?>
                                </td>
                            </tr>

                            <tr>
                                <td>
                                    Current Height (in metres)
                                </td>
                                <td>                                
                                    <input type="decimal" size="2" name="height" min="0" max="2" required>                          
                                </td>
                            </tr>

                            <tr>
                                <td>
                                    Weight(in kg)
                                </td>
                                <td>                                
                                    <input type="decimal" size="2" name="weight" min="1" max="200" required>
                                </td>
                            </tr>


                            <tr>
                                <td>
                                    Cause of pain      
                                </td>
                                <td>
                                    <select name="cause_of_pain" id="cause_of_pain" required>
                                        <option value="">Select Cause</option>
                                        <option value="Exercise">Exercise</option>
                                        <option value="Home Accident">Home Accident</option>
                                        <option value="Drug side effec">Drug side effect</option>
                                        <option value="Unknown/others">Unknown/others</option>
                                    </select>   
                                </td>
                            </tr>

                            <tr> 
                                <td>
                                    Type of Pain 
                                </td>
                                <td>
                                    <select name="type_of_pain" id="type_of_pain" required>
                                        <option value="">Select Pain Type</option>
                                        <option value="Nociceptive Pain">Nociceptive( Arises from injury or rupture of a tissue)</option>
                                        <option value="Inflammatory Pain">Inflammatory (Abnormal inflammation) </option>
                                        <option value="Neuropathic Pain">Neuropathic (nerve irritation)</option>
                                        <option value="Functional Pain">Functional Pain(No clear organic source)</option>                                                                        
                                    </select> 
                                </td>
                            </tr>

                            <tr> 
                                <td>
                                    Pain Location
                                </td>
                                <td>
                                    <select name="pain_location" id="pain_location" required>
                                        <option value="">Select Pain Location</option>
                                        <option value="Abdomen">Abdomen</option>
                                        <option value="Arm">Arm</option>
                                        <option value="Chest">Chest</option>
                                        <option value="Back">Back</option>
                                        <option value="Foot">Foot</option>
                                        <option value="Head">Head</option>
                                        <option value="Leg">Leg</option>
                                        <option value="Neck">Neck</option>                                    
                                        <option value="Thigh and Groin">Thigh and Groin</option>
                                        <option value="Pelvic region">Pelvic region</option>                                                                        
                                        <option value="Joints">Joints(ankle,elbow, wrist, Knee)</option>
                                        <option value="Waist">Waist</option>
                                        <option value="Others">Others</option>
                                    </select> 
                                </td>
                            </tr>

                            <tr>
                                <td>
                                    Intensity
                                </td>   
                                <td>
                                    <select name="intensity" id="intensity" required>
                                        <option value="">Select Intensity</option>
                                        <option value="Mild">Mild</option>
                                        <option value="Moderate">Moderate</option>
                                        <option value="Tolerable">Tolerable</option>
                                        <option value="Hurts a bit">Hurts a bit</option>
                                        <option value="Uncomfortable">Uncomfortable</option>
                                        <option value="Painful">Painful</option>
                                        <option value="Severe">Severe</option>
                                        <option value="Very Severe">Very Severe</option>
                                        <option value="Acute">Acute</option>
                                        <option value="Unbearable">Unbearable</option>
                                    </select>                                                                                                                                                   
                                </td>
                            </tr>

                            <tr>
                                <td>
                                    Duration(Days)
                                </td>
                                <td>                                
                                    <input type="number" size="2" name="duration" min="1" max="200" placeholder="Duration of pain so far" required>
                                </td>
                            </tr>

                            <tr>
                                <td>
                                    Diet
                                </td>
                                <td>
                                    <select name="diet" id="diet" required>
                                        <option value="">Select Diet Type</option>                                        
                                        <option value="Vegan">Vegan</option>                                    
                                        <option value="Paleo">Paleo </option>
                                        <option value="Low-carb">Low-carb</option>
                                        <option value="The Duncan">The Duncan</option>
                                        <option value="Regular">Regular(Omnivore)</option>                                        
                                        <option value="Fast and can Food">Fast and can Food</option>
                                        <option value="Meat">Meat</option>                                    
                                        <option value="Others">Others</option>
                                    </select>  
                                </td>
                            </tr>
                            <tr>
                                <td>
                                    Medication      
                                </td>
                                <td>
                                    <input id="medication" type="text" name="medication" size="40" value="none" required >
                                </td>
                            </tr>

                            <tr>
                                <td>
                                    Lifestyle
                                </td>
                                <td>
                                    <select name="lifestyle" id="lifestyle" required>
                                        <option value="">Select Lifestyle</option>
                                        <option value="Super-Active">Super-Active(Sports Person)</option>
                                        <option value="Active">Active(Weekly Exercises)</option>                                    
                                        <option value="Regular">Regular </option>
                                        <option value="Sedentary">Inactive/Sedentary</option>                                    
                                        <option value="Handicapped">Handicapped</option>                                    
                                        <option value="Others">Others</option>
                                    </select>  
                                </td>
                            </tr>                        
                            <tr>
                                <td>
                                    Allergy
                                </td>
                                <td>
                                    <input type="text" name="allergy" value="none" required>
                                </td>
                            </tr>
                            <tr>                            
                                <td colspan="2" align="center">
                                    <input type="submit" name="createCase"  value="submit">
                                </td>
                            </tr>
                        </table>
                    </form>

                </div>
                <div id="middle-content">
                    <form name="form1" action="" method="post" enctype="multipart/form-data" >

                        <table border="1" bgcolor="white">
                            <tr>
                                <td colspan="4" align="center">                                                            
                                    <b>    EXISTING CASES- SUMMARY </b>                                                          
                                </td>
                                <?php
                                $sql = "SELECT * FROM pain_case where patient_id ='$patientUsername' ";
                                    $result = $conn->query($sql);
                                    if ($result->num_rows > 0) {
                                        ?>
                            <tr>
                                <td>
                                    <i> <b>Date Entered</b></i>
                                </td>
                                     <td>
                                    <i>   <b> Case ID</b></i>
                                    </td>
                                    <td>
                                        <i><b>Type of Pain</b></i>
                                    </td>
                                    <td>
                                        <i><b>Pain Location</b></i>
                                    </td>
                            </tr>
                                <?php
                                        while ($row = $result->fetch_assoc()) {                                     
                                    ?>
                            <tr>                                
                                <td>  
                                    <?php echo $row["date"];?>
                                </td>
                            
                                    <td>
                                        <?php echo $row["case_id"];?>
                                    </td>
                                    <td>
                                        <?php echo $row["type_of_pain"];?>
                                    </td>                            
                                    <td>
                                        <?php echo $row["pain_location"];?>
                                    </td>                            
                                            <?php
                                        }
                                    } else {
                                        ?><td colspan="4"> <?php
                                        echo "No Existing Cases";
                                        ?></td> <?php
                                    }
                                    ?>
                        </table>
                    </form>

                </div>
                <div id="right-content"><!--right content -->

                    <form name="form3" action="" method="post" enctype="multipart/form-data" >   
                        <table border="1" bgcolor="silver">                
                            <tr>
                                <td colspan="2" align="center">
                                    <b>  <font color="black" size="3.3" > <i> Update Diary of Existing Cases</i> </font></b>  
                                </td>
                            </tr>                               
                            <tr>
                                <td>
                                    Case ID       
                                </td>
                                <td>
                                    <input id="name" type="text" name="diary_pain_case_id" size="40" placeholder="case id" required >
                                </td>
                            </tr>
                            <tr>
                                <td colspan="2" align="center">
                                    <input type="submit" name="updateCaseButton"  value="update">
                                </td>
                            </tr>
                        </table>
                        <?php                                                 
                        if (array_key_exists('updateCaseButton', $_POST)) {
                            $theDiary_pain_case_id = $_POST['diary_pain_case_id'];
                            #echo 'selected case id: '.$theDiary_pain_case_id;                            
                        $tRF2 = mysqli_query($conn, "SELECT * FROM pain_record where case_id='$theDiary_pain_case_id'");
                        
                        if( mysqli_num_rows($tRF2) > 0 ){
                          ?>  <script>alert("Pain record already documented for this case id");</script>
                        <?php      
                        }else{
                            $aRF2 = mysqli_query($conn, "SELECT * FROM pain_case where case_id='$theDiary_pain_case_id'");                            
                            if( mysqli_num_rows($aRF2) > 0 ){
                                $tb = mysqli_fetch_array($aRF2);
                                if($tb['patient_id'] == $patientUsername){
                                $_SESSION['diary_pain_case_id'] = $theDiary_pain_case_id;                            
                                echo "<meta http-equiv=\"refresh\" content=\"0;URL=painRecord.php\">";                                  
                                }else{  
                                 ?>  <script>alert("Pain record does not belong to this user");</script>   
                             <?php   }
                            
                            }else{
                             ?>  <script>alert("Error! create pain case first before update");</script>   
                           <?php }
                        }                        
                        }
                        ?>
                    </form>
                    
                    <br><!-- comment -->
                    <form name="form4" action="" method="post" enctype="multipart/form-data" >   
                        <table border="1" bgcolor="grey">                
                            <b>  <font color="black" size="3.3" > <i> View Analysis/Summary of Pain Case</i> </font></b>                                 
                            <tr>
                                <td>
                                    Case ID       
                                </td>
                                <td>
                                    <input id="name" type="text" name="the_pain_case_id_for_analysis" size="40" placeholder="case id" required >
                                </td>
                            </tr>
                            <tr>
                                <td colspan="2" align="center">
                                    <input type="submit" name="viewAnalysisButton1"  value="view summary">
                                </td>
                            </tr>
                        </table>
                        <?php                                                 
                        if (array_key_exists('viewAnalysisButton1', $_POST)) {
                            
                        $p1 = $_POST['the_pain_case_id_for_analysis'];
                        $tRF21 =  mysqli_query($conn, "SELECT * FROM pain_record where case_id='$p1'");                        
                        $ta = mysqli_fetch_array($tRF21);
                        if( mysqli_num_rows($tRF21) > 0 ){                            
                                 if($ta['patient_id'] == $patientUsername){
                                    $_SESSION['the_pain_case_id_for_analysis'] = $_POST['the_pain_case_id_for_analysis'];
                                    #echo 'id = '.$_POST['the_pain_case_id_for_analysis'];
                                    echo "<meta http-equiv=\"refresh\" content=\"0;URL=viewAnalysisByPatient.php\">";                                 
                                }else{  
                                 ?>  <script>alert("Pain record does not belong to this user");</script>   
                             <?php   }
                        }else{                            
                            ?>  <script>alert("No existing records for this case id");</script>
                        <?php 
                        }                                                    
                        //    $_SESSION['the_pain_case_id_for_analysis'] = $_POST['the_pain_case_id_for_analysis'];
                        //      echo 'id = '.$_POST['the_pain_case_id_for_analysis'];
                        //    echo "<meta http-equiv=\"refresh\" content=\"0;URL=viewAnalysisByPatient.php\">";  
                        }
                        ?>
                    </form>

                </div>
                <div id="footer">Copyright &copy;  <?php echo "Munura Maihankali"; ?> MSc Dissertation| 2021 </div>
            </div>
        </body>
    </html>
    <?php
#} else {
#    echo "<meta http-equiv=\"refresh\" content=\"0;URL=index.php\">";
#}
?>
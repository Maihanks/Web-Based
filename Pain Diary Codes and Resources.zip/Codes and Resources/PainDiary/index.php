<?php
session_destroy();
session_start();
#session_start();
include_once ("classes/class.company.php");
include_once ("classes/class.login.php");
include_once ("classes/class.database.php");
include_once ("connect.php");
$databaseAccess = new Database();
$databaseAccess->connectToDatabase();
#$companyObj = new Company();
$patient_username = "";
?>
<!DOCTYPE html>
<html>
    <head>
        <meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
        <title>PAIN DIARY</title>
        <link rel="stylesheet" type="text/css" href="myCss/basic.css" />     
    </head>
    <body>
        <form name="form1" method="post" action="">
            <div id="headContainer">
                <div id="head"><div id="appName">PAIN DIARY</div><!--Links to several pages -->

                </div>
                <div id="navigation">
                    <div id="links">
                        <a href="https://www.webmd.com/pain-management/guide/pain-management-treatment-care">Learn About Pain </a>
                        <a href="contactUs.php">Contact Us</a> >>>> 
                        <font size="14" color="brown">  PAIN MANAGEMENT SYSTEM</font><<<
                        <div id="loginFields"> 
                        </div>
                        <font size="3.4" color="green"></font>
                    </div>
                </div>
            </div>
            
        </form>
        <div id="page">
            <div id="left-content"><!--left content -->                
                                <br>
                               <font color="black" size="2">
If it feels uncomfortable then it is uncomfortable. <br>
    Better rehabilitation results require adhering to a treatment plan consistently.<br><br><!-- comment -->
 <i>Signup or login to manage your pain today!.
</i>
                               </font>                               
                               <br>                               
            </div>
            <div id="middle-content">
                                <form name="form2" action="" method="post" enctype="multipart/form-data" >
                    <table border="1">                
                        <b>  <font color="black" size="3.3" >NEW PATIENT - REGISTRATION </font></b>                                 
                        <tr>
                            <td>
                                Names        
                            </td>
                            <td>
                                <input id="name" type="text" name="names" size="40" placeholder="Name" required >
                            </td>
                        </tr>
                        <tr>
                            <td>
                                Email
                            </td>
                            <td>
                                <input type="email" name="email"  placeholder="email" required>
                            </td>
                        </tr>                       
                        <tr>
                            <td>
                                Username        
                            </td>
                            <td>
                                    <?php        
                                    $sql = "SELECT * FROM patient_biodata";
                                    $r = $conn->query($sql);
                                    $n = $r->num_rows +1;
                                    $patient_username = "user".$n;
                                    echo $patient_username;
                                    ?>                                     
                            </td>
                        </tr>
                        <tr> 
                        <td>
                            Password
                        </td>
                        <td>
                            <input id="password" type="password" name="registrationPassword" size="40" placeholder="Password" required >
                        </td>
                        </tr>

                        <tr>
                            <td>
                                Gender  
                            </td>
                            <td>
                                <select name="sex" id="sex" required>
                                    <option value="">Select Sex</option>
                                    <option value="MALE">MALE</option>
                                    <option value="FEMALE">FEMALE</option>                                    
                                </select>
                            </td>
                        </tr>
                        <tr>
                            <td>
                                Age     
                            </td>
                            <td>
                                <input type="number" id="age" name="age" required>                                
                            </td>
                        </tr>

                        <tr>
                            <td>
                                Nationality        
                            </td>
                            <td>                                                                    
            <select id="country" name="country" class="form-control" required>               
                <option value="Angola">Angola</option>                
                <option value="Brazil">Brazil</option>
                <option value="France">France</option>
                <option value="Germany">Germany</option>
                <option value="Ghana">Ghana</option>
                <option value="Mexico">Mexico</option>
                <option value="Nigeria">Nigeria</option>
                <option value="Portugal">Portugal</option>
                <option value="Spain">Spain</option>
            </select>                            </td>
                        </tr>
                        <tr>
                            <td>
                                Province/State        
                            </td>
                            <td>
                                <input id="province" type="text" name="province" size="40" placeholder="Province/State" required >
                            </td>
                        </tr>

                        <tr>
                            <td>
                                Address
                            </td>
                            <td>
                                <textarea  name="address" cols="20" rows="5" required>
                                </textarea>
                            </td>
                        </tr>
                        <tr>
                        <tr>
                            <td>
                                Phone Number
                            </td>
                            <td>
                                <input type="number" name="phoneNumber" required>
                            </td>
                        </tr>
                        <tr>
                            <td colspan="2" align="center">
                                <input type="submit" name="registerCustomer"  value="register">
                            </td>
                        </tr>
                    </table>
                </form>
                    <?php
                    if (array_key_exists('registerCustomer', $_POST)) {
                        
                        $fieldNamesArray[0] = "username";                   $fieldValuesArray[0] = $patient_username; #$_POST['username']; 
                        $fieldNamesArray[1] = "email";                      $fieldValuesArray[1] = $_POST['email'];                                                
                        $fieldNamesArray[2] = "phone_number";               $fieldValuesArray[2] = $_POST['phoneNumber'];                                                                                                
                        $fieldNamesArray[3] = "gender";                     $fieldValuesArray[3]= $_POST['sex'];
                        $fieldNamesArray[4] = "country";                    $fieldValuesArray[4] = $_POST['country'];
                        $fieldNamesArray[5] = "province";                   $fieldValuesArray[5] = $_POST['province'];                        
                        $fieldNamesArray[6] = "address";                    $fieldValuesArray[6] = $_POST['address'];                        
                        $fieldNamesArray[7] = "age";                        $fieldValuesArray[7] = $_POST['age'];  
                        $fieldNamesArray[8] = "date";                       $fieldValuesArray[8] =  date('d/m/Y h:i:s a', time());                          
                        $fieldNamesArray[9] = "names";                      $fieldValuesArray[9] = $_POST['names'];

                        //to be inserted in the users table
                        $field2NamesArray[0] = "username";                   $field2ValuesArray[0] =  $patient_username; 
                        $field2NamesArray[1] = "password";                   $field2ValuesArray[1] = $_POST['registrationPassword'];                                                                                                                      
                        $field2NamesArray[2] = "category";                   $field2ValuesArray[2] = "Patient";

                        $databaseAccess->insertRecord("", "patient_biodata", $fieldNamesArray, $fieldValuesArray);
                        $databaseAccess->insertRecord("", "userslog", $field2NamesArray, $field2ValuesArray);
                        ?>
                <script>alert("Successful Registration")</script>
                <?php             
                echo "<meta http-equiv=\"refresh\" content=\"0;URL=index.php\">";
                    }//end if when submit button is clicked
                    ?>
            </div>
            <div id="right-content"><!--right content -->
                
                <form name="form1" action="" method="post" enctype="multipart/form-data" >
                    <table>
                        <tr>
                            <td colspa="2" align="center">
                                <b> <font color="blue" size="3.3"> </font></b>
                            </td>
                        </tr>
                        <tr>
                            <td colspa="2" align="center">
                                <b> <font color="blue" size="3.3"> </font></b>
                            </td>
                        </tr>
                        <tr>
                            <td colspan="2" align="center"> 
                              <font color="black"><b><i> 
                                Already Registered, Sign in 
                            </i></b></font>
                            </td>
                        </tr>

                        <tr>                            
                            <td>
                                Username
                            </td>   
 
                            <td>
                                <input name="username" type="text" required>
                            </td>    
                        </tr>
                        <tr>
                            <td>
                                Password   
                            </td>    
                            <td>
                                <input type="password" name="password" required>
                            </td>    
                        </tr>
                        <tr>
                            <td colspan="2" align="right">
                                <input type="submit" name="submitButton" value="login">
                            </td>
                        </tr>
                    </table>
                    <?php
                    if (array_key_exists('submitButton', $_POST)) {
                        
                        $username = $_POST['username'];
                        $password = $_POST['password'];
                                                                        
                        $result = mysqli_query($conn, "SELECT * FROM userslog WHERE username='$username' AND password='$password'");
                        $num_rows = mysqli_num_rows($result);
                            if ($num_rows > 0) {
                                $_SESSION['username'] = $username;
                                $firstStringCharacter = substr($username, 0, 1);
                                
                    $r1 = mysqli_query($conn, "SELECT * FROM login_log");
                    $n1 = mysqli_num_rows($r1) + 1;
                    $log_id = 'L000' . $n1;                                     
                                //id, username, date, time
                        $field2NamesArray[0] = "id";                     $field2ValuesArray[0] =  $log_id; 
                        $field2NamesArray[1] = "username";               $field2ValuesArray[1] = $username;                                                                                                                      
                        $field2NamesArray[2] = "date";                   $field2ValuesArray[2] = date('d/m/Y');
                        $field2NamesArray[3] = "time";                   $field2ValuesArray[3] = date('h:i:s a');
                        $databaseAccess->insertRecord("", "login_log", $field2NamesArray, $field2ValuesArray);
                        
                                //
                                    if ($firstStringCharacter == 'a') {//administrator
                                          echo "<meta http-equiv=\"refresh\" content=\"0;URL=adminHome.php\">";                                     
                                    } else if ($firstStringCharacter == 'u') {//patient
                                        echo "<meta http-equiv=\"refresh\" content=\"0;URL=patientHome.php\">";
                                    } else if ($firstStringCharacter == 'p') {// physician
                                echo "<meta http-equiv=\"refresh\" content=\"0;URL=physicianHome.php\">";
                                        }
                            } else {//Failed login/ invalid user
                                        ?><font color="red">invalid user</font><?php
                            }                            
            }//end if when submit button is cliicked
                    ?>
                </form>        
                <br>
                <font size="2"> source: https://i.pinimg.com/originals/bf/8d/a4/bf8da473d90005bc2215508e6711d0c9.jpg </font>
                <img src="body_parts.jpg" width="400" height="450" alt="alt"/>                               
            </div>
            <div id="footer">Copyright &copy;  <?php echo "Munura Maihankali"; ?> MSc Dissertation| 2021 </div>
        </div>
    </body>
</html>

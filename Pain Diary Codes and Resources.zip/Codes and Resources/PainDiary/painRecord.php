<?php
session_start();
include_once ("classes/class.company.php");
include_once ("classes/class.login.php");
include_once ("classes/class.database.php");
include("connect.php");
$databaseAccess = new Database();
$databaseAccess->connectToDatabase();
$companyObj = new Company();

$patientUsername = $_SESSION['username'];
$case_id_for_new_pain_record = $_SESSION['diary_pain_case_id'];   
$diary1_pain_case_id = $_SESSION['diary_pain_case_id'];
//$case_id = $theDiary_pain_case_id;
if ($patientUsername != "") {
    ?>
    <!DOCTYPE html>
    <html>
        <head>
            <meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
            <title>PAIN DIARY</title>
            <link rel="stylesheet" type="text/css" href="myCss/basic.css" />     
        </head>
        <body>
            <form name="form1" method="post" action="">
                <div id="headContainer">
                    <div id="head"><div id="appName">PAIN DIARY</div><!--Links to several pages -->

                    </div>
                    <div id="navigation">
                        <div id="links">
                            <a href = "patientHome.php">Home</a>       
                            <a href  = "chat.php">Chat</a>                              
                            <a href = "#">Complaint</a>
                            <a href = "contactUs.php">Contact Us</a> 
                            <a href = "https://www.webmd.com/pain-management/guide/pain-management-treatment-care">Learn About Pain</a> 
                            <a href = "index.php">Log-out</a>     
                            <div id="loginFields"> 
                            </div>
                            <font size="3.4" color="green"></font>
                        </div>
                    </div>
                </div>
            </form>
            <div id="page">
                <?php 

                    $r1 = mysqli_query($conn, "SELECT * FROM pain_record");
                    $n1 = mysqli_num_rows($r1) + 1;
                    $record_id = 'R000' . $n1;                    
                    ?>
                <div id="left-content"><!--left content -->

                    <form name="form2" action="" method="post" enctype="multipart/form-data" >
                        <?php
                        if (array_key_exists('createRecord', $_POST)) {
                            $fieldNamesArray[0] = "record_id";                            $fieldValuesArray[0] = $record_id;
                             //$diary1_pain_case_id = $_POST['the_new_case_id'];      
                            $fieldNamesArray[1] = "case_id";                              $fieldValuesArray[1] = $diary1_pain_case_id;
                            $fieldNamesArray[2] = "patient_id";                           $fieldValuesArray[2] = $patientUsername;
                            $fieldNamesArray[3] = "intensity";                            $fieldValuesArray[3] = $_POST['intensity'];
                            $fieldNamesArray[4] = "word_description";                     $fieldValuesArray[4] = $_POST['word_description'];
                            $fieldNamesArray[5] = "medication";                           $fieldValuesArray[5] = $_POST['medication'];                            
                            $fieldNamesArray[6] = "therapy";                              $fieldValuesArray[6] = $_POST['therapy'];
                            $fieldNamesArray[7] = "progress_rate";                        $fieldValuesArray[7] = $_POST['progress_rate'];
                            $fieldNamesArray[8] = "aggravating_factor";                   $fieldValuesArray[8] = $_POST['aggravating_factor'];
                            $fieldNamesArray[9] = "date";                                 $fieldValuesArray[9] = $_POST['thedate'];
                            $fieldNamesArray[10] = "time";                                $fieldValuesArray[10] =date('h:i:s a');
                                                        

                            $databaseAccess->insertRecord("", "pain_record", $fieldNamesArray, $fieldValuesArray);
                                        ?>
                <script>alert("Successful entry")</script>
                <?php                                                                     
                        }//end if when submit button is clicked               	                                         
                        ?>
                        <table border="2">        
                            <tr>
                                <td colspan="2" align="center">
                                    <b>  <font color="blue" size="3.3" ><i> ADD DAILY PAIN RECORD  </i></font></b>                              
                                </td>
                            </tr>                        
                            <tr>
                                <td>
                                    Patient Username:
                                </td>
                                <td>
    <?php echo $patientUsername; ?>
                                </td>
                            </tr>                       

                            <tr>
                                <td>
                                    case Id  	                                
                                </td>                            
                                <td>
                                    <?php echo $diary1_pain_case_id;?>

                                </td>
                            </tr>
                            <tr>
                                <td>
                                    Date
                                </td>
                                <td>
                                    <input type="date" id="thedate" name="thedate" value="2021-07-10" min="2018-01-01" max="2021-12-31" required>
                                </td>
                            </tr>
                            <tr>
                                <td>
                                    Pain Sensation   
                                </td>
                                <td>
                                    <select name="word_description" id="word_description" required>
                                        <option value="">Select Description</option>
                                        <option value="None">None</option>
                                        <option value="Mild">Mild</option>
                                        <option value="Dull">Dull</option>
                                        <option value="Aching">Aching</option>
                                        <option value=Burning">Burning</option>                                        
                                        <option value="Electric Shocks">Electric Shocks</option>
                                        <option value="Pins">Pins</option>
                                        <option value="Sharp">Sharp</option>
                                        <option value="Throbbing">Throbbing</option>
                                        <option value="Unknown/others">Unknown/others</option>
                                    </select>   
                                </td>
                            </tr>

                            <tr>
                                <td>
                                    Therapy    
                                </td>
                                <td>
                                    <select name="therapy" id="cause_of_pain" required>
                                        <option value="">Select Therapy</option>
                                        <option value="None">None</option>
                                        <option value="Exercise">Exercise</option>
                                        <option value="Massage">Massage</option>
                                        <option value="Rest-Ice-Compression">Rest-Ice-Compression</option>
                                        <option value="Unknown/others">Unknown/others</option>
                                    </select>   
                                </td>
                            </tr>


                            <tr>
                                <td>
                                    Intensity
                                </td>   
                                <td>
                                    <select name="intensity" id="intensity" required>
                                        <option value="">Select Intensity</option>
                                        <option value="None">None</option>
                                        <option value="Mild">Mild</option>
                                        <option value="Moderate">Moderate</option>
                                        <option value="Tolerable">Tolerable</option>
                                        <option value="Hurts a bit">Hurts a bit</option>
                                        <option value="Uncomfortable">Uncomfortable</option>
                                        <option value="Painful">Painful</option>
                                        <option value="Severe">Severe</option>
                                        <option value="Very Severe">Very Severe</option>
                                        <option value="Acute">Acute</option>
                                        <option value="Unbearable">Unbearable</option>
                                    </select>                                                                                                                                                   
                                </td>
                            </tr>

                            <tr>
                                <td>
                                    Medication      
                                </td>
                                <td>
                                    <input id="medication" type="text" name="medication" size="40" value="none" required >
                                </td>
                            </tr>

                            <tr>
                                <td>
                                    Aggravating factor
                                </td>
                                <td>
                                    <select name="aggravating_factor" id="aggravating_factor" required>
                                        <option value="">Select factor</option>
                                        <option value="clothing">clothing</option>
                                        <option value="Mood swings">Mood swings</option>                                    
                                        <option value="Sitting">Sitting </option>
                                        <option value="Inactive/Sedentary">Inactive/Sedentary</option>                                    
                                        <option value="Standing">Standing</option>                                    
                                        <option value="Stress">Stress</option>
                                        <option value="Walking">Walking</option>
                                        <option value="cold">cold</option>                                        
                                        <option value="heat">heat</option>   
                                        <option value="Others">Others</option>|
                                    </select>  
                                </td>
                            </tr>                        

                            <tr>
                                <td>
                                    Progress/Recovery Rate today
                                </td>
                                <td>
                                    <select name="progress_rate" id="progress_rate" required>
                                        <option value="">Select rate</option>
                                        <option value="Aggravating(-1)">Aggravating(-1)</option>
                                        <option value="Stagnant(0)">Stagnant(0)</option>
                                        <option value="Slow(1)">Slow(1)</option>
                                        <option value="Regular(2)">Regular(2)</option>                                    
                                        <option value="Notable Relief(3)">Notable Relief(3) </option>
                                        <option value="Speedy(4)">Speedy(4)</option>                                                                            
                                        <option value="Complete(5)">Complete(5)</option>
                                        <option value="Others(6)">Others(6)</option>
                                    </select>  
                                </td>
                            </tr>     
                            
                            <tr>                            
                                <td colspan="2" align="center">
                                    <input type="submit" name="createRecord"  value="submit">
                                </td>
                            </tr>
                        </table>
                    </form>

                </div>
                <div id="middle-content">
                    <form name="form1" action="" method="post" enctype="multipart/form-data" >

                        <table border="0" bgcolor="white">
                            <tr>
                                <td colspan="4" align="center">                                                            
                                    EXISTING CASES                                                           
                                </td>
                                <?php
                                $sql = "SELECT * FROM pain_case where patient_id ='$patientUsername' ";
                                    $result = $conn->query($sql);
                                    if ($result->num_rows > 0) {
                                        ?>
                            <tr>
                                <td>
                                    Date Entered
                                </td>
                                     <td>
                                        Case ID:
                                    </td>
                                    <td>
                                        Type of Pain
                                    </td>
                                    <td>
                                        Intensity
                                    </td>
                            </tr>
                                <?php
                                        while ($row = $result->fetch_assoc()) {                                     
                                    ?>
                            <tr>                                
                                <td>  
                                    <?php echo $row["date"];?>
                                </td>
                            
                                    <td>
                                        <?php echo $row["case_id"];?>
                                    </td>
                                    <td>
                                        <?php echo $row["type_of_pain"];?>
                                    </td>                            
                                    <td>
                                        <?php echo $row["intensity"];?>
                                    </td>                            
                                            <?php
                                        }
                                    } else {
                                        ?><td colspan="4"> <?php
                                        echo "No Existing Cases";
                                        ?></td> <?php
                                    }
                                    ?>
                        </table>
                    </form>

                </div>
                <div id="right-content"><!--right content -->

                    <form name="form3" action="" method="post" enctype="multipart/form-data" >   
                        <table border="1" bgcolor="grey">                
                            <b>  <font color="black" size="3.3" > <i> View Analysis/Summary of Pain Case</i> </font></b>                                 
                            <tr>
                                <td>
                                    Case ID       
                                </td>
                                <td>
                                    <input id="name" type="text" name="the_pain_case_id_for_analysis" size="40" placeholder="case id" required >
                                </td>
                            </tr>
                            <tr>
                                <td colspan="2" align="center">
                                    <input type="submit" name="viewAnalysisButton"  value="view summary">
                                </td>
                            </tr>
                        </table>
                        <?php                                                 
                        if (array_key_exists('viewAnalysisButton', $_POST)) {  
                  
                        $p1 = $_POST['the_pain_case_id_for_analysis'];
                        $tRF21 =  mysqli_query($conn, "SELECT * FROM pain_record where case_id='$p1'");                        
                        $ta = mysqli_fetch_array($tRF21);
                        if( mysqli_num_rows($tRF21) > 0 ){                            
                                 if($ta['patient_id'] == $patientUsername){
                                    $_SESSION['the_pain_case_id_for_analysis'] = $_POST['the_pain_case_id_for_analysis'];
                                    #echo 'id = '.$_POST['the_pain_case_id_for_analysis'];
                                    echo "<meta http-equiv=\"refresh\" content=\"0;URL=viewAnalysisByPatient.php\">";                                 
                                }else{  
                                 ?>  <script>alert("Pain record does not belong to this user");</script>   
                             <?php   }
                        }else{                            
                            ?>  <script>alert("No existing records for this case id");</script>
                        <?php 
                        }                                                    

                        }
                        ?>
                    </form>
                </div>
                <div id="footer">Copyright &copy;  <?php echo "Munura Maihankali"; ?> MSc Dissertation| 2021 </div>
            </div>
        </body>
    </html>
    <?php
} else {
    echo "<meta http-equiv=\"refresh\" content=\"0;URL=index.php\">";
}
?>
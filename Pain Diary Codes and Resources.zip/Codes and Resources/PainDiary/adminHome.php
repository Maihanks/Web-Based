<?php
#session_start();
#session_destroy();
#session_start();
include_once ("classes/class.company.php");
include_once ("classes/class.login.php");
include_once ("classes/class.database.php");
$databaseAccess = new Database();
$databaseAccess->connectToDatabase();
$companyObj = new Company();
$physician_username = ""
?>
<!DOCTYPE html>
<html>
    <head>
        <meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
        <title>PAIN DIARY</title>
        <link rel="stylesheet" type="text/css" href="myCss/basic.css" />     
    </head>
    <body>
        <form name="form1" method="post" action="">
            <div id="headContainer">
                <div id="head"><div id="appName">PAIN DIARY</div><!--Links to several pages -->

                </div>
                <div id="navigation">
                    <div id="links">
                        
                        <a href="viewOverallAnalysisByAdmin.php">Pain Analysis </a> 
                        <a href="login_log.php">Logs </a> 
                        <a href="login_log.php">Logs </a>                            
                        <a href = "index.php">Log-out</a>     
                        <div id="loginFields"> 
                        </div>
                        <font size="3.4" color="green"></font>
                    </div>
                </div>
            </div>
        </form>
        <div id="page">
            <div id="left-content"><!--left content -->
            </div>
            <div id="middle-content">
                                <form name="form2" action="" method="post" enctype="multipart/form-data" >
                    <table border="1">                
                        <b>  <font color="black" size="3.3" > REGISTER NEW PHYSICIAN </font></b>                                 
                        <tr>
                            <td>
                                Names        
                            </td>
                            <td>
                                <input id="name" type="text" name="names" size="40" placeholder="Name" required >
                            </td>
                        </tr>
                        <tr>
                            <td>
                                Email
                            </td>
                            <td>
                                <input type="email" name="email"  placeholder="email" required>
                            </td>
                        </tr>                       
                        <tr>
                            <td>
                                Username        
                            </td>
                            <td>
                                 <?php
                                $sql = "SELECT * FROM physician_biodata";
                                    $r = $conn->query($sql);
                                    $n = $r->num_rows +1;
                                    $physician_username = "phy".$n;
                                    echo $physician_username;
                                        ?>                                
                            </td>
                        </tr>
                        <tr> 
                        <td>
                            Password
                        </td>
                        <td>
                            <input id="name" type="password" name="registrationPassword" size="40" placeholder="Password" required >
                        </td>
                        </tr>

                        <tr>
                            <td>
                                Gender  
                            </td>
                            <td>
                                <select name="gender" id="gender" required>
                                    <option value="">Select Gender</option>
                                    <option value="MALE">MALE</option>
                                    <option value="FEMALE">FEMALE</option>
                                    <option value="OTHERS">OTHERS</option>
                                </select>
                            </td>
                        </tr>

                        <tr>
                            <td>
                         Health Center        
                            </td>
                            <td>                                                            
            <select id="health_center_id" name="health_center_id" class="form-control">
                <option value="">Select Health Center</option>
                                      <?php
                                $sql = "SELECT * FROM health_center";
                                    $result = $conn->query($sql);
                                    if ($result->num_rows > 0) {
                                        while ($row = $result->fetch_assoc()) {                                     
                                    ?>
                <option value="<?php echo $row["center_id"];?>"><?php echo $row["center_name"];?></option>                
                                    <?php                                     
                                        }//end while
                                    }//end if                                    
                                    ?>
            </select>                            
                            </td>
                        </tr>
                        <tr>
                            <td>
                                Physician Address
                            </td>
                            <td>
                                <textarea  name="address" cols="20" rows="5" required>
                                </textarea>
                            </td>
                        </tr>
                        
                        <tr> 	 	
                            <td>
                                Phone Number: 	        
                            </td>
                            <td>
                                <input id="phone_number" type="number" name="phone_number" size="40" placeholder="Phone number" required >
                            </td>
                        </tr>

                        <tr>
                        <tr>
                            <td colspan="2" align="center">
                                <input type="submit" name="registerPhysician"  value="register">
                            </td>
                        </tr>
                    </table>
                </form>
                                    <?php
                    if (array_key_exists('registerPhysician', $_POST)) {                        
                        #username 	email 	name 	address 	gender 	health_center_id 	date_registered 	phone_number 
                        $fieldNamesArray[0] = "username";                   $fieldValuesArray[0] =  $physician_username; 
                        $fieldNamesArray[1] = "email";                      $fieldValuesArray[1] = $_POST['email'];                                                
                        $fieldNamesArray[2] = "name";                       $fieldValuesArray[2] = $_POST['names'];
                        $fieldNamesArray[3] = "address";                    $fieldValuesArray[3] = $_POST['address'];                        
                        $fieldNamesArray[4] = "gender";                     $fieldValuesArray[4]= $_POST['gender'];
                        $fieldNamesArray[5] = "health_center_id";           $fieldValuesArray[5] = $_POST['health_center_id'];
                        $fieldNamesArray[6] = "phone_number";               $fieldValuesArray[6] = $_POST['phone_number'];                                                                                                                                                
                        $fieldNamesArray[7] = "date";                       $fieldValuesArray[7] =  date('d/m/Y h:i:s a', time());                          
                        

                        //to be inserted in the users table
                        $field2NamesArray[0] = "username";                   $field2ValuesArray[0] =  $physician_username; 
                        $field2NamesArray[1] = "password";                   $field2ValuesArray[1] = $_POST['registrationPassword'];                                                                                                                      
                        $field2NamesArray[2] = "category";                   $field2ValuesArray[2] = "Physician";
                        
                        #$databaseAccess->insertRecord("", "physician_biodata", $fieldNamesArray, $fieldValuesArray);
                        #$databaseAccess->insertRecord("", "userslog", $field2NamesArray, $field2ValuesArray);
                        echo '<font color="green">Successful Registration</fonts>';
                        
#                        echo 'Username : '.$fieldValuesArray[0]."<br>";
#                        echo 'Password :'.$fieldValuesArray[6];
                    }//end if when submit button is clicked
                    ?>
            </div>
            <div id="middle-content">
            
            
            </div>
            <div id="right-content"><!--right content -->
                
          </div>
            <div id="footer">Copyright &copy;  <?php echo "Munura Maihankali"; ?> MSc Dissertation| 2021 </div>
        </div>
    </body>
</html>

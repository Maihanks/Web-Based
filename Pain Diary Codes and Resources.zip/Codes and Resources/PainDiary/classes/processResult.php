<?php

/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
class ProcessResult {
     function  ProcessResult(){ 
    }

    /** This method returns the grade that corresponds to a range of scores say
     * 70-100= A, 60-69=B,50-59=C,45-49=D,40-44=E,0-39=F
     * @param type $score
     */
    public function  getGrade($score){
        $grade = "";
        if( ($score>=70) && ($score<=100) ){
            $grade = "A";
        }else  if( $score>=60){
            $grade = "B";
        }else  if( $score>=50){
            $grade = "C";
        }else  if( $score>=45){
            $grade = "D";
        }else  if( $score>=40){
            $grade = "E";
        }else  if( $score>=0){
            $grade = "A";
        }else {
            $grade = "?";
        }
        return $grade;
    }
    /**
     * This method returns the points denoting a particular grade
     * @param type $score
     * @return int
     */
    public function getPoints($score) {
        $grade = $this->getGrade($score);
        $points = 0;
        if($grade=="A"){
            $points = 5;
        }else if($grade=="B"){
            $points= 4;
        }else if($grade=="C"){
            $points= 3;
        }else if($grade=="D"){
            $points= 2;
        }else if($grade=="E"){
            $points= 1;
        }else if($grade=="F"){
            $points= 0;
        }
        return $points
        ;
    }
    
    /*     * This method returns the grade point i.e grade point = points * creditunit
     * 
     * @param type $creditUnits
     * @param type $score
     * @return type
     */

    public function getPW($creditUnits, $score) {
        $points  = $this->getPoints($score);
        echo $creditUnits.'<br>';
        $pw = $creditUnits * $points;
        return $pw;
    }
}//end class ProcessResult
?>

<?php
include_once ("classes/class.database.php");
class Student{
    private $regNumber;
    private $firstName;
    private $lastName;
    private $sex;
    private $dob;
    private $address;
    private $class;
    private $dbObj;
    private $loginObj;
    function Student($theLogin){
        $this->loginObj = new Login("","");
        $this->loginObj = $theLogin;
        $this->regNumber = $this->loginObj->getUsername();
        $this->dbObj = new Database();
        $this->dbObj->connectToDatabase();
        $this->dbObj->setDatabasename("secschool");
    }
    
    public function getRegNumber(){
        return $this->regNumber;
    }
    
    private function setFirstName($theFirstName) {
        $this->firstName = $theFirstName;
    }
    public function getFirstName() {
        return $this->firstName;
    }
    
    public function getLastName() {
        return $this->lastName;
    }
    
    public function getSex() {
        return $this->sex;
    }
    
    public function getDOB() {
        return $this->address;
    }
    public function getAddress() {
        return $this->address;
    }
    public function getClass() {
        return $this->class;
    }
    public function getProfile() {
//$this->loginObj = new Login();
$class = $this->loginObj->getClass();
$table = "";
switch ($class) {//assigns table for search
                case "js1": $table = "js1info";
                    break;
                case "js2":$table  = "js2info";
                    break;
                case "js3":$table  = "js3info";
                    break;
                case "ss1":$table  = "ss1info";
                    break;
                case "ss2":$table  = "ss2info";
                    break;
                case "ss3":$table  = "ss3info";
                    break;
                default:$table  = "nil";
                    break;
            }//end switch
        $query = $this->dbObj->findBySingleAttribute("", $table, "regNumberDb", $this->getRegNumber());
        $fetch = mysql_fetch_array($query);
        $this->firstName = $fetch['firstNameDb'];
        $this->lastName = $fetch['lastNameDb'];
        $this->sex = $fetch['sexDb'];
        $this->address = $fetch['addressDb'];
    }
}
?>
<?php

class Company {

    /**
     * the school name
     * @var type 
     */
    private $companyName;
    private $companyAddress;
    private $companyMotor;
    private $copyrightName;

    /**
     * constructor 
     */
    function Company() {
        $this->companyName = "PAIN DIARY"; //"School";
        $this->companyAddress = "Aberdeen, Scotland";
        $this->companyMotor = "Pain rehabilitation";
        $this->copyrightName = "Maihanks";
    }

    /*     * returns the name of the institution
     * 
     * @return type
     */

    public function getCompanyName() {
        return $this->companyName;
    }

    public  function getCopyrightName(){
        return $this->copyrightName; 
    }


    /**
     * returns the address of the school
     * @return type
     */
    public function getSchoolAddress() {
        return $this->companyAddress;
    }

    /**
     * returns the motor of the school
     * @return type
     */
    public function getSchoolMotor() {
        return $this->companyMotor;
    }

}

?>

<?php

class Utilities {

    function Utilities() {
        
    }

    function bubbleSort($unsortedArray) {
        $sortedArray = $unsortedArray;
        $temp;
        $counterSize = 0;
        $arraySize = 0;
        foreach ($unsortedArray as $value) {
            $arraySize++;
        }
        for ($pass = 0; $pass < ($arraySize - 1); $pass++) {
            for ($counter = 0; $counter < ($arraySize - 1); $counter++) {
                if ($sortedArray[$counter] > $sortedArray[$counter + 1]) {
                    $temp = $sortedArray[$counter];
                    $sortedArray[$counter] = $sortedArray[$counter + 1];
                    $sortedArray[$counter + 1] = $temp;
                }//end if
            }//end for
        }//end for
        return $sortedArray;
    }

    function eliminateRepetitionInArray($theArray) {
     $arraySize = 0;
        $finalArray = array();
        $finalArrayCounter = 0;
        foreach ($theArray as $value) {
            $arraySize++;
        }//end foreach
        for ($pass = 0; $pass < ($arraySize - 1); $pass++) {
            $p = $pass + 1;
            for ($counter = $pass + 1; $counter <= ($arraySize - 1); $counter++) {
                if ($theArray[$pass] == $theArray[$counter]) {
                    $theArray[$counter] = -1;
                }//end if
            }//end for
        }//end for

        foreach ($theArray as $value) {
            if ($value != -1) {
                $finalArray[$finalArrayCounter] = $value;
                $finalArrayCounter++;
            }
        }//end foreach
        return $finalArray;
    }//end 
    
    function isSuppliedMonthGreaterThanTodaysMonth($suppliedMonth){        
       $todaysMonth =  date("m");
        $status = 0;
        if($suppliedMonth>$todaysMonth){ 
            $status = 1;
        }
        return $status;
    }
    
    function isSuppliedYearGreaterThanTodaysYear($suppliedYear){
       $todaysYear =  date("Y"); 
        $status = 0;
        if($suppliedYear>$todaysYear){
            $status = 1;
        }
        return $status;
    }
}
?>
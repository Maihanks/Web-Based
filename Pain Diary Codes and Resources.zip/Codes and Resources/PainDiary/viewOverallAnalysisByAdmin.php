<?php
#session_start();
#session_destroy();
#session_start();
include_once ("classes/class.company.php");
include_once ("classes/class.login.php");
include_once ("classes/class.database.php");
$databaseAccess = new Database();
$databaseAccess->connectToDatabase();
$companyObj = new Company();
?>
<!DOCTYPE html>
<html>
    <head>
        <meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
        <title>PAIN DIARY</title>
        <link rel="stylesheet" type="text/css" href="myCss/basic.css" />         
<script type="text/javascript" src="https://www.gstatic.com/charts/loader.js"></script>

    <script type="text/javascript" src="https://www.gstatic.com/charts/loader.js"></script>
    <script type="text/javascript">
      google.charts.load('current', {'packages':['bar']});
      google.charts.setOnLoadCallback(drawChart);

      function drawChart() {
          
<?php
$male = "MALE";
$female = "FEMALE";
$theresultMale = mysqli_query($conn, "SELECT therapy FROM pain_record where gender='$male'");
$theresultFemale = mysqli_query($conn, "SELECT therapy FROM pain_record where gender='$female'"); 

?>
        var data = google.visualization.arrayToDataTable([
            <?php
            $theresultPdata = mysqli_query($conn, "SELECT gender,country FROM patient_biodata"); 
$a = 0; $a1 = 0; $b = 0; $b1 = 0; $c = 0;$c1 = 0;
$d = 0;$d1 = 0; $e = 0;$e1 = 0; $f = 0;$f1 = 0; $g = 0;$g1 = 0;
$h = 0;$h1 = 0; $i = 0; $i1 = 0;
 while ($rowG1 = mysqli_fetch_array($theresultPdata)) {                            
               if( $rowG1['country']=='Angola'){                      
                   if($rowG1['gender']=='MALE'){
                       $a = $a + 1 ;
                   }else if($rowG1['gender']=='FEMALE'){                                          
                       $a1 = $a1 + 1 ;
                   }
               }else if( $rowG1['country']=='Brazil'){  
                  
                  if($rowG1['gender']=='MALE'){
                       $b = $b + 1 ;
                   }else if($rowG1['gender']=='FEMALE'){                                          
                       $b1 = $b1 + 1 ;
                   }
               }else if( $rowG1['country']=='France'){                   
                  if($rowG1['gender']=='MALE'){
                       $c = $c + 1 ;
                   }else if($rowG1['gender']=='FEMALE'){                                          
                       $c1 = $c1 + 1 ;
                   }
               }else if( $rowG1['country']=='Germany'){  
                  if($rowG1['gender']=='MALE'){
                       $d = $d + 1 ;
                   }else if($rowG1['gender']=='FEMALE'){                                          
                       $d1 = $d1 + 1 ;
                   }
               }else if( $rowG1['country']=='Ghana'){                   
                      if($rowG1['gender']=='MALE'){
                       $e = $e + 1 ;
                   }else if($rowG1['gender']=='FEMALE'){                                          
                       $e1 = $e1 + 1 ;
                   }
               }else if( $rowG1['country']=='Mexico'){                   
                  if($rowG1['gender']=='MALE'){
                       $f = $f + 1 ;
                   }else if($rowG1['gender']=='FEMALE'){                                          
                       $f1 = $f1 + 1 ;
                   }
               }else if( $rowG1['country']=='Nigeria'){
                  if($rowG1['gender']=='MALE'){
                       $g = $g + 1 ;
                   }else if($rowG1['gender']=='FEMALE'){                                          
                       $g1 = $g1 + 1 ;
                   }                                
               }else if( $rowG1['country']=='Portugal'){                     
                  if($rowG1['gender']=='MALE'){
                       $h = $h + 1 ;
                   }else if($rowG1['gender']=='FEMALE'){                                          
                      $h1 = $h1 + 1 ; 
                   }
               }else if( $rowG1['country']=='Spain'){                    
                  if($rowG1['gender']=='MALE'){
                       $i = $i + 1 ;
                   }else if($rowG1['gender']=='FEMALE'){                                          
                       $i1 = $i1 + 1 ;
                   }
               }
            //  echo "['".$row["intensity"]."', ".$row["number"]."],";            
            }
            ?>
          ['Nationality', 'MALE', 'FEMALE'],                    
           <?php echo "['"."ANG"."', '".$a."', ".$a1."], ";             ?>       
           <?php echo "['"."BRA"."', '".$b."', ".$b1."], ";             ?>  
           <?php echo "['"."FRA"."', '".$c."', ".$c1."], ";             ?>  
           <?php echo "['"."GER"."', '".$d."', ".$d1."], ";             ?>  
           <?php echo "['"."GHN"."', '".$e."', ".$e1."], ";             ?>  
           <?php echo "['"."MEX"."', '".$f."', ".$f1."], ";             ?>  
           <?php echo "['"."NIG"."', '".$g."', ".$g1."], ";             ?>  
           <?php echo "['"."POR"."', '".$h."', ".$h1."], ";             ?>  
           <?php echo "['"."SPN"."', '".$i."', ".$i1."], ";             ?>  
        ]);


        var options = {
            
          chart: {
            title: '.',
            subtitle: 'y-axis = lifestyle: 1-Inactive/Sedentary, 2-Regular, 3-Active(Weekly Exercises), 4-Super-Active(Sports Person)',
          }
        };

        var chart = new google.charts.Bar(document.getElementById('columnchart_material'));

        chart.draw(data, google.charts.Bar.convertOptions(options));        
      }
            
    </script>

        <script type="text/javascript">
      google.charts.load('current', {'packages':['bar']});
      google.charts.setOnLoadCallback(drawChart);

      function drawChart() {
          
<?php
$male = "MALE";
$female = "FEMALE";
$theresultMale = mysqli_query($conn, "SELECT therapy FROM pain_record where gender='$male'");
$theresultFemale = mysqli_query($conn, "SELECT therapy FROM pain_record where gender='$female'"); 

//$number_of_patients_per_country = [];

           //while ($rowG1 = mysqli_fetch_array($theresultMale)) {
            //  echo "['".$row["intensity"]."', ".$row["number"]."],";
            //}  
?>
        var data = google.visualization.arrayToDataTable([
          ['BMI', 'MALE', 'FEMALE'],                    
          ['BMI(Healthy)', 1, .8],
          ['BMI(Unhealthy)', -1, -1]
        ]);

        var options = {
            
          chart: {
            title: '.',
            subtitle: 'Age-group = 20-30, Lifestyle,Medication,Therapy at extreme (i.e)',
          }
          
        };

        var chart = new google.charts.Bar(document.getElementById('bmi_columnchart_material'));

        chart.draw(data, google.charts.Bar.convertOptions(options));        
      }
            
    </script>    
    
    <script type="text/javascript">
    //PIE CHART  
    google.charts.load('current', {'packages':['corechart']});
      google.charts.setOnLoadCallback(drawChart);

      function drawChart() {

        var data = google.visualization.arrayToDataTable([
          ['Therapy', 'Occurences'],          
          <?php          
          
          $theresult = mysqli_query($conn, "SELECT therapy, count(*) as number FROM pain_record  group by therapy");
           while ($row = mysqli_fetch_array($theresult)) {
                            echo "['".$row["therapy"]."', ".$row["number"]."],";
                        }                         
?>
        ]);

        var options = {
          title: 'All patients therapy stats'
        };

        var chart = new google.visualization.PieChart(document.getElementById('therapy_piechart'));

        chart.draw(data, options);
      }
    </script>   

    <script type="text/javascript">
    //PIE CHART  
    google.charts.load('current', {'packages':['corechart']});
      google.charts.setOnLoadCallback(drawChart);

      function drawChart() {

        var data = google.visualization.arrayToDataTable([
          ['Therapy', 'Occurences'],          
          <?php          
          
          $theresult = mysqli_query($conn, "SELECT type_of_pain,cause_of_pain, count(*) as number FROM pain_case  group by cause_of_pain");
           while ($row = mysqli_fetch_array($theresult)) {
                            echo "['".$row["cause_of_pain"]."', ".$row["number"]."],";
                        }                         
?>
        ]);

        var options = {
          title: 'Causes of pain stats'
        };

        var chart = new google.visualization.PieChart(document.getElementById('cause_of_pain_piechart'));

        chart.draw(data, options);
      }
    </script>   
    

    <script type="text/javascript">
    //PIE CHART-- Types of Pain  
    google.charts.load('current', {'packages':['corechart']});
      google.charts.setOnLoadCallback(drawChart);

      function drawChart() {

        var data = google.visualization.arrayToDataTable([
          ['Therapy', 'Occurences'],          
          <?php          
          
          $theresult = mysqli_query($conn, "SELECT type_of_pain,cause_of_pain, count(*) as number FROM pain_case  group by type_of_pain");
           while ($row = mysqli_fetch_array($theresult)) {
                            echo "['".$row["type_of_pain"]."', ".$row["number"]."],";
                        }                         
?>
        ]);

        var options = {
          title: 'Types of Pains Stats'
        };

        var chart = new google.visualization.PieChart(document.getElementById('types_of_pain_piechart'));

        chart.draw(data, options);
      }
    </script>   
       
    <script type="text/javascript">
      google.charts.load('current', {'packages':['corechart']});
      google.charts.setOnLoadCallback(drawChart);

      function drawChart() {
        var data = google.visualization.arrayToDataTable ([
          ['Time', 'Therapy', 'Intensity'],  //time---weight, 
            <?php            
            $dse_id = 'P00015';
         $theRF1 =mysqli_query($conn, "SELECT * FROM pain_record where case_id='$dse_id' order by date");               
        $d = "30"; $therapyNumericValue = 5; $intensityNumericValue = 8;
         while ($rowBC1 = mysqli_fetch_array($theRF1)) {             
         //echo "['".$rowBC["medication"]."', ".$rowBC["freq"]."],";
             if($rowBC1["therapy"]=='Unknown/others'){
                $therapyNumericValue = 0;  
             }else if($rowBC1["therapy"]=='Rest-Ice-Compression'){
                $therapyNumericValue = 1;  
             }else if($rowBC1["therapy"]=='Massage'){
                $therapyNumericValue = 2;  
             }else if($rowBC1["therapy"]=='Exercise'){
                $therapyNumericValue = 3;  
             }else if($rowBC1["therapy"]=='None'){
                $therapyNumericValue = 4;  
             }
             
             // intensity
              if($rowBC1["intensity"]=='Mild'){
                $intensityNumericValue = 0;  
             }else if($rowBC1["intensity"]=='Moderate'){
                $intensityNumericValue = 1;  
             }else if($rowBC1["intensity"]=='Tolerable'){
                $intensityNumericValue = 2;  
             }else if($rowBC1["intensity"]=='Hurts a bit'){
                $intensityNumericValue = 3;  
             }else if($rowBC1["intensity"]=='Uncomfortable'){
                $intensityNumericValue = 4;  
             }else if($rowBC1["intensity"]=='Painful'){
                $intensityNumericValue = 5;  
             }else if($rowBC1["intensity"]=='Severe'){
                $intensityNumericValue = 6;  
             }else if($rowBC1["intensity"]=='Very Severe'){
                $intensityNumericValue = 7;  
             }else if($rowBC1["intensity"]=='Acute'){
                $intensityNumericValue = 8;  
             }else if($rowBC1["intensity"]=='Unbearable'){
                $intensityNumericValue = 9;  
             }           
         echo "['".$rowBC1["date"]."', ".$therapyNumericValue.", ".$intensityNumericValue."],";        
         //echo "['".$rowBC["medication"]."', ".$rowBC["freq"]."],";
         }
         ?>        
          
/*        ['2004',  1000,      400],
          ['2005',  1170,      460],
          ['2006',  660,       1120],
          ['2007',  1030,      540]
  */          
        ]);

        var options = {
          title: 'Distribution of Therapy, Time and Pain Intensity relationship',
          curveType: 'function',
          legend: { position: 'bottom' }
        };

        var chart = new google.visualization.LineChart(document.getElementById('curve_chart'));
        chart.draw(data, options);               
      }
    </script>
    
<script type="text/javascript">
 google.charts.load('current', {'packages':['corechart', 'scatter']});
      google.charts.setOnLoadCallback(drawStuff);

      function drawStuff() {

        var button = document.getElementById('change-chart');
        var chartDiv = document.getElementById('the_chart_div');

        var data = new google.visualization.DataTable();
        data.addColumn('number', 'Student ID'); //aggravating_factor
        data.addColumn('number', 'Hours Studied');//age
        data.addColumn('number', 'Final');//sex

        data.addRows([
          [0, 0, 67],  [1, 1, 88],   [2, 2, 77],
          [3, 3, 93],  [4, 4, 85],   [5, 5, 91],
          [6, 6, 71],  [7, 7, 78],   [8, 8, 93],
          [9, 9, 80],  [10, 10, 82], [11, 0, 75],
          [12, 5, 80], [13, 3, 90],  [14, 1, 72],
          [15, 5, 75], [16, 6, 68],  [17, 7, 98],
          [18, 3, 82], [19, 9, 94],  [20, 2, 79],
          [21, 2, 95], [22, 2, 86],  [23, 3, 67],
          [24, 4, 60], [25, 2, 80],  [26, 6, 92],
          [27, 2, 81], [28, 8, 79],  [29, 9, 83]
        ]);

        var materialOptions = {
          chart: {
            title: 'Distribution of aggravating_factors with respect to age and sex',
            subtitle: 'scatter plot'
          },
          width: 400,
          height: 500,
          series: {
            0: {axis: 'age'},
            1: {axis: 'aggravating_factor'}
          },
          axes: {
            y: {
              'hours studied': {label: 'Hours Studied'},
              'final grade': {label: 'Final Exam Grade'}
            }
          }
        };

        var classicOptions = {
          width: 800,
          series: {
            0: {targetAxisIndex: 0},
            1: {targetAxisIndex: 1}
          },
          title: 'Students\' Final Grades - based on hours studied',

          vAxes: {
            // Adds titles to each axis.
            0: {title: 'Hours Studied'},
            1: {title: 'Final Exam Grade'}
          }
        };

        function drawMaterialChart() {
          var materialChart = new google.charts.Scatter(chartDiv);
          materialChart.draw(data, google.charts.Scatter.convertOptions(materialOptions));
          button.innerText = 'Change to Classic';
          button.onclick = drawClassicChart;
        }

        function drawClassicChart() {
          var classicChart = new google.visualization.ScatterChart(chartDiv);
          classicChart.draw(data, classicOptions);
          button.innerText = 'Change to Material';
          button.onclick = drawMaterialChart;
        }

        drawMaterialChart();
    };
    
</script>   

  <script type="text/javascript">
    google.charts.load('current', {'packages':['gantt']});
    google.charts.setOnLoadCallback(drawChart);

    function daysToMilliseconds(days) {
      return days * 24 * 60 * 60 * 1000;
    }

    function drawChart() {

      var data = new google.visualization.DataTable();
      data.addColumn('string', 'Task ID');
      data.addColumn('string', 'Task Name');
      data.addColumn('string', 'Resource');
      data.addColumn('date', 'Start Date');
      data.addColumn('date', 'End Date');
      data.addColumn('number', 'Duration');
      data.addColumn('number', 'Percent Complete');
      data.addColumn('string', 'Dependencies');

      data.addRows([
        ['Research', 'BMI', null,
         new Date(2015, 0, 1), new Date(2015, 0, 5), null,  100,  null],
        ['Write', 'Lifestyle', 'write',
         null, new Date(2015, 0, 9), daysToMilliseconds(3), 25, 'Research,Outline'],
        ['Cite', 'Diet', 'write',
         null, new Date(2015, 0, 7), daysToMilliseconds(1), 20, 'Research'],
        ['Complete', 'Therapy/Medication', 'complete',
         null, new Date(2015, 0, 10), daysToMilliseconds(1), 0, 'Cite,Write'],
        ['Outline', 'Age', 'write',
         null, new Date(2015, 0, 6), daysToMilliseconds(1), 100, 'Research']
      ]);

      var options = {
        height: 275
      };

      var chart = new google.visualization.Gantt(document.getElementById('variable_hierachy_chart'));

      chart.draw(data, options);
    }
  </script>
      
    <script type="text/javascript">
      google.charts.load('current', {'packages':['corechart']});
      google.charts.setOnLoadCallback(drawSeriesChart);

    function drawSeriesChart() {

      var data = google.visualization.arrayToDataTable([
        ['height', 'lifestyle', 'duration', 'diet',     'weight'],
//id=height, life_expetancy=lifestyle,fertility_rate=duration_of_pain..,region=diet,population=weight

<?php
$ARF1 =mysqli_query($conn, "SELECT * FROM pain_case");               
$d = "30"; $lifestyleNumericValue = 5; 

while ($ArowBC1 = mysqli_fetch_array($ARF1)) { 
    if($ArowBC1["lifestyle"]== 'Super-Active'){
        $lifestyleNumericValue = 1; 
    }else if($ArowBC1["lifestyle"]== 'Active'){
        $lifestyleNumericValue = 2; 
    }else if($ArowBC1["lifestyle"]== 'Regular'){
        $lifestyleNumericValue = 3; 
    }else if($ArowBC1["lifestyle"]== 'Sedentary'){
        $lifestyleNumericValue = 4; 
    }else if($ArowBC1["lifestyle"]== 'Handicapped'){
        $lifestyleNumericValue = 5; 
    }else if($ArowBC1["lifestyle"]== 'Others'){
        $lifestyleNumericValue = 6; 
    }
echo "['".$ArowBC1["height"]."', ".$lifestyleNumericValue.", ".$ArowBC1["duration"].",'".$ArowBC1["diet"]."'," .$ArowBC1["weight"] ."],";            

 } 
?>
      ]);

      var options = {
        title: 'Relationship between patient\'s diet,lifestyle,weight,duration & height .' +
          ' X=lifestyle, Y=duration_of_pain, Bubble size=Weight, Bubble color=Diet',
        hAxis: {title: 'lifestyle'},
        vAxis: {title: 'duration_of_pain'},
        bubble: {textStyle: {fontSize: 11}}
      };

      var chart = new google.visualization.BubbleChart(document.getElementById('series_chart_div'));
      chart.draw(data, options);
    }
    </script>
    
    </head>
    <body>
        <form name="form1" method="post" action="">
            <div id="headContainer">
                <div id="head"><div id="appName">PAIN DIARY</div><!--Links to several pages -->
                </div>
                <div id="navigation">
                    <div id="links">
                        <a href="viewAnalysisByAdmin.php">Patient Analysis </a>
                        <a href="adminHome.php.php">Home</a>  
                        <a href = "index.php">Log-out</a>     
                        <div id="loginFields"> 
                        </div>
                        <font size="3.4" color="green"></font>
                    </div>
                </div>
            </div>
        </form>
        <div id="page">
            <div id="left-content"><!--left content -->
                <div id="columnchart_material" style="width: 430px; height: 300px;"></div>                
<br><br>                
<div id="the_chart_div" style="width: 417px; height: 300px;"> </div>   
<br><!-- comment -->
<br><br><br><br><br><br><br><br>
<br><br><br><br><br><br><br><br>
<div id="therapy_piechart" style="width: 417px; height: 300px;"> </div>
                           </div>
            <div id="middle-content">
                <div id="series_chart_div" style="width: 400px; height: 400px;"></div>                  
                <br>
                <div id="types_of_pain_piechart" style="width: 417px; height: 300px;"></div> 
<div id="curve_chart" style="width: 400px; height: 500px"></div>

            </div>
            <div id="right-content"><!--right content -->    
<font color="blue" size="2.1"> --Hierrachy of importance of variables to pain recovery </font>
<div id="variable_hierachy_chart" style="width: 417px; height: 300px;"></div>                 
<br>
<div id="cause_of_pain_piechart" style="width: 417px; height: 300px;"></div>                  
<div id="bmi_columnchart_material" style="width: 430px; height: 300px;"></div>                
            </div>
            <div id="footer">Copyright &copy;  <?php echo "Munura Maihankali"; ?> MSc Dissertation| 2021 </div>
        </div>
    </body>
</html>

<?php
session_start();
include_once ("classes/class.company.php");
include_once ("classes/class.login.php");
include_once ("classes/class.database.php");
include("connect.php");
$databaseAccess = new Database();
$databaseAccess->connectToDatabase();
$companyObj = new Company();

$patientUsername = $_SESSION['username'];
#$_SESSION['diary_pain_case_id'] = ;   
$diary1_pain_case_id = $_SESSION['diary_pain_case_id'];
#$case_id = $theDiary_pain_case_id;
#if ($patientUsername != "") {
    ?>
    <!DOCTYPE html>
    <html>
        <head>
            <meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
            <title>PAIN DIARY</title>
            <link rel="stylesheet" type="text/css" href="myCss/basic.css" />     
        </head>
        <body>
            <form name="form1" method="post" action="">
                <div id="headContainer">
                    <div id="head"><div id="appName">PAIN DIARY</div><!--Links to several pages -->

                    </div>
                    <div id="navigation">
                        <div id="links">
                            <a href = "patientHome.php">Home</a>                                                                                                                                                    
                            <a href = "https://www.webmd.com/pain-management/guide/pain-management-treatment-care">Learn About Pain</a>  
                            <a href = "index.php">Log-out</a>     
    
                            <div id="loginFields">                             
                            </div>
                            <font size="3.4" color="green"></font>
                        </div>
                    </div>
                </div>
            </form>
            <div id="page">
                <div id="left-content"><!--left content -->
                    <b> .......COMPLAINT INBOX............</b> <br>
                        <table border="1" bgcolor="silver">   
                            <tr>
                                <td>
                                    <b>Sender</b>    
                                </td>                                
                                <td>
                                    <b>Message</b>
                                </td>
                                <td>
                                    <b>Date & Time</b>
                                </td>
                            </tr>
                            <?php 
                            
                            
                            $theresult = mysqli_query($conn, "SELECT * FROM complaint_response where complaint_patient_id='$patientUsername' order by date");                            
                            
                            if( mysqli_num_rows($theresult)==0 ){
                                ?><tr><td colspan="3"> <?php echo '<font color="red">No response messages to complaints available</font>'; ?> </td></tr> <?php 
                            }else
                            {
                            while ($rowA = mysqli_fetch_array($theresult)){    
                                ?>
                            <tr>
                                <td><?php echo $rowA['response']; ?>   </td>
                                <td><?php echo $rowA['date'].' '.$rowA['time'];; ?>  </td>                                
                            </tr>
                                <?php
                            }     
                            
                            }
                            ?>                            
                        </table>                    
                    
                </div>
                <div id="middle-content">
                
                <form name="form3" action="" method="post" enctype="multipart/form-data" >   
                        <table border="1" bgcolor="grey">                
                            <b>  <font color="black" size="3.3" > <i> Drop your complaint</i> </font></b>                                 
                            <tr>
                                <td>
                                 Complaint  Message
                                </td>                                
                            </tr>
                            <tr>                                 
                                <td>
                                <textarea  name="message" id="message" cols="20" rows="10" required>
                                </textarea>
                                </td>
                            </tr>
                            
                            <tr>
                                <td colspan="2" align="right">
                                    <input type="submit" name="sendMessageButton"  value="send message">
                                </td>
                            </tr>
                        </table>
                        <?php                                                 
                        if (array_key_exists('sendMessageButton', $_POST)) {                                                         
                            $message = $_POST['message'];
                                                      
                            $ar = mysqli_query($conn, "SELECT * FROM complaint");
                            $nr = mysqli_num_rows($ar) + 1;
                            $complaint_id = 'C000' . $nr;
                            $sender_id = $patientUsername;
                            
                            //message_id 	sender_id 	recepient_id 	message 	date 	time 	                            
                            $fieldNamesArray[0] = "id";                             $fieldValuesArray[0] = $complaint_id;
                            $fieldNamesArray[1] = "user_id";                        $fieldValuesArray[1] = $sender_id;
                            $fieldNamesArray[2] = "complaint";                      $fieldValuesArray[2] = $message;
                            $fieldNamesArray[3] = "date";                           $fieldValuesArray[3] = date('d/m/Y');                                                        
                            $fieldNamesArray[4] = "time";                           $fieldValuesArray[4] = date('h:i:s a');
                            
                            $currentDate = date('d/m/Y');
                            $currentTime = date('h:i:s a');
                           //echo 'recepientId='.$recipientId;
                            $databaseAccess->insertRecord("", "complaint", $fieldNamesArray, $fieldValuesArray);                                                        
                 ?>
                <script>alert("Complaint sent")</script> 
                <?php  
                echo "<meta http-equiv=\"refresh\" content=\"0;URL=complaint.php\">";
                        }
                        ?>
                    </form>
                </div>
                
                <div id="right-content"><!--right content -->
                    <b> ......SENT COMPLAINT MESSAGES......</b> <br>
                        <table border="1" bgcolor="#9FE2BF">   
                            <tr>                             
                                <td>
                                    <b>Message</b>
                                </td>
                                <td>
                                    <b>Date & Time</b>
                                </td>
                            </tr>
                            <?php 
                            //$theresult = mysqli_query($conn, "SELECT * FROM pain_record where recipient_id='$patientUsername' group by sender_id");
                            $thers = mysqli_query($conn, "SELECT * FROM complaint where user_id='$patientUsername' order by date");                            
                            
                            if( mysqli_num_rows($thers)==0 ){
                                ?><tr><td colspan="3"> <?php echo 'No Sent messages available'; ?> </td></tr> <?php 
                            } else{
                            while ($rowA2 = mysqli_fetch_array($thers)) {    
                                ?>
                            <tr>
                                <td><?php echo $rowA2['complaint']; ?>   </td>
                                <td><?php echo $rowA2['date'].' '.$rowA2['time'];; ?>  </td>                                
                            </tr>
                                <?php
                            }                                 }
                            ?>                            
                        </table>
                    <br><br><br>
                    
                </div>                
                <div id="footer">Copyright &copy;  <?php echo "Munura Maihankali"; ?> MSc Dissertation| 2021 </div>
            </div>
        </body>
    </html>
    <?php
?>
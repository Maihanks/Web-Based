/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package com.maihanks.enhancedCaesarCipher;

import java.awt.Color;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.MouseEvent;
import java.awt.event.MouseListener;
import java.awt.event.MouseMotionListener;
import javax.swing.*;

/**
 *
 * @author MAIHANKS
 */
public class InterfaceDesign extends JFrame{
    private JTextField keyTextField;
    private JButton encryptButton,decryptButton;
    private JTextArea inputTextArea, outputTextArea;
    private JLabel inputTextAreaHeader, outputTextAreaHeader,keyHeader;
    private JPanel parentPanel;
    private String input,output, key;
    public InterfaceDesign(){
         super("CEASAR CIPHER");
         keyTextField = new JTextField();
         encryptButton = new JButton("Encrypt");
         decryptButton = new JButton("Decrypt");
         inputTextArea = new JTextArea("");
         outputTextArea = new JTextArea("");
         parentPanel = new JPanel();
         inputTextAreaHeader = new JLabel("Input");
         outputTextAreaHeader = new JLabel("output");
         keyHeader = new JLabel("Key");
    }
    /**sets up the parent components
     */
    private void setUpParentComponents(){
        this.setBounds(100, 30, 900, 500);
        this.setDefaultCloseOperation(InterfaceDesign.EXIT_ON_CLOSE);
        parentPanel.setSize(this.getWidth(), this.getHeight());
        parentPanel.setBackground(Color.gray.brighter());
        setUpParentPanelComponents();
        parentPanel.setLayout(null);
        parentPanel.add(inputTextArea);
        parentPanel.add(outputTextArea);
        parentPanel.add(encryptButton);
        parentPanel.add(decryptButton);
        parentPanel.add(inputTextAreaHeader);
        parentPanel.add(outputTextAreaHeader);
       
        parentPanel.add(keyHeader);
        parentPanel.add(keyTextField);
        this.add(parentPanel);
        setUpEventHandlers();
    }
    
    /**
     * sets up parent panel components
     */
    private void setUpParentPanelComponents(){
        inputTextAreaHeader.setBounds(100, 50, 100, 40);
        inputTextArea.setBounds(10, 90, 370, 200);
        
        outputTextAreaHeader.setBounds(600, 50, 100, 40);
        outputTextArea.setBounds(500, 90, 370, 200);
        
        keyHeader.setBounds(400, 100, 50, 50);
        keyTextField.setBounds(400, 150, 50, 50);
 
        encryptButton.setBounds(400, 350, 90, 70);
        decryptButton.setBounds(520, 350, 90, 70);        
    }
    /**displays the frame
     * 
     */
    private void displayFrame(){
     setUpParentComponents();
    this.setVisible(true);
    }
    private static boolean  isKeyValid(String theKey){
        boolean status = false;
        try{
            int intKey = Integer.parseInt(theKey);
            if( (intKey > 0 ) && (intKey < CaesarCipher.alphabets.length)   ){
                status = true;
            }else {
            status = false;
            }
        }catch(Exception e){
        status = false;
        }
        return status;
    }
    private void setUpEventHandlers() {
        /**
         * keyTextField;
    private JButton encryptButton,decryptButton;
    private JTextArea inputTextArea, outputTextArea;
         */
        
        this.encryptButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                key = keyTextField.getText();
                input = inputTextArea.getText();
                output = outputTextArea.getText();
                if(isKeyValid(key) == true){
                    output = CaesarCipher.encryptMessage(input,Integer.parseInt(key));
                    outputTextArea.setText(output);
                }else{
                    int p = CaesarCipher.alphabets.length-1;
                JOptionPane.showMessageDialog(null, "Supplied key is invalid!\nenter a key within the range of 1 -"+p);
                }
                
            }
        });
        this.decryptButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                key = keyTextField.getText();
                input = inputTextArea.getText();
                output = outputTextArea.getText();
                if(isKeyValid(key) == true){
                    output = CaesarCipher.decryptMessage(input,Integer.parseInt(key));
                    outputTextArea.setText(output);
                }
            }
        });
        
//            MouseHandler handler = new MouseHandler();                       
//        keyTextField.addMouseListener( handler );                          
//        keyTextField.addMouseMotionListener( handler );  
        keyTextField.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
     //JOptionPane.showMessageDialog(null, "Enter a key within the range of 1 - "+CaesarCipher.alphabets.length);
            }
        });
        keyTextField.addMouseListener(new MouseListener() {

            @Override
            public void mouseClicked(MouseEvent e) {
        JOptionPane.showMessageDialog(null, "Enter a key within the range of 1 - "+CaesarCipher.alphabets.length);         
            }

            @Override
            public void mousePressed(MouseEvent e) {
             
            }

            @Override
            public void mouseReleased(MouseEvent e) {
             
            }

            @Override
            public void mouseEntered(MouseEvent e) {
             
            }

            @Override
            public void mouseExited(MouseEvent e) {
             
            }
        });
    }//end setEventHandlers()
    
    
    private class MouseHandler implements MouseListener,
        MouseMotionListener                              
     {
        // MouseListener event handlers
        // handle event when mouse released immediately after press
        @Override
        public void mouseClicked(MouseEvent event) {
            if(event.getSource().equals(keyTextField)){
            JOptionPane.showMessageDialog(null, "Enter a key within the range of 1-96");
            }
        }

        @Override
        public void mousePressed(MouseEvent e) {
            throw new UnsupportedOperationException("Not supported yet.");
        }

        @Override
        public void mouseReleased(MouseEvent e) {
            throw new UnsupportedOperationException("Not supported yet.");
        }

        @Override
        public void mouseEntered(MouseEvent e) {
            throw new UnsupportedOperationException("Not supported yet.");
        }

        @Override
        public void mouseExited(MouseEvent e) {
            throw new UnsupportedOperationException("Not supported yet.");
        }

        @Override
        public void mouseDragged(MouseEvent e) {
            throw new UnsupportedOperationException("Not supported yet.");
        }

        @Override
        public void mouseMoved(MouseEvent e) {
            throw new UnsupportedOperationException("Not supported yet.");
        }
    }
    
    public static void main(String[] args){
    new InterfaceDesign().displayFrame();
    }
}

/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package com.maihanks.enhancedCaesarCipher;

/**
 *
 * @author MAIHANKS
 */
public class CaesarCipher {
    
    private static String plainText, cipherText;
    private static String keyStringValue;
    private static int keyIntValue;
    public static char[] alphabets = {' ', '^', 'B', '8', 'D', '-', 'F', '4', 'H', '`', 'J', ')', 'L', 'a', 'N', '$', 'P', 'j', 'R', '<', 'T', '+', 'V', 'n', 'X', '=', 'Z',
        'M', 'b', 'c', 'd', 'e', 'f', 'g', 'h', 'i', 'Q', 'k', 'l', 'm', 'W', 'o', 'p', 'q', 'r', 's', 't', 'u', 'v', 'w', 'x', 'y', 'z',
        '0', '1', '2', '3', 'G', '5', '6', '7', 'C', '9',
        'I', '~', '!', '@', '#', 'O', '%', 'A', '&', '*', '(', 'K', 'E', '_', 'Y', 'U',
        '[', '{', ']', '}', ';', ':', '\'', '\"', ',', 'S', '.', '>', '/', '?'};

    public CaesarCipher() {
    }

    public static String getPlainText() {
        return plainText;
    }

    public static String getCipherText() {
        return cipherText;
    }

    /**
     * returns true if value is numeric and falls within the range of 1 - 25
     */
    public static boolean isValueValid(String value) {//
        boolean status = false;
        try {
            if ((Integer.parseInt(value) >= 1) && (Integer.parseInt(value) < (alphabets.length - 1))) {
                status = true;//value is a numeral
            }//en dif
        } catch (Exception e) {//value is not a numeral
            status = false;
        }//end catch
        return status;
    }//end isValueNumeric()

    /**
     * encrypts the plain message
     */
    public static String encryptMessage(String thePlainText, int theKey) {
        thePlainText = permutateFirstByLast(thePlainText);
        String theCipherText = "";
        char cipherChar;
        int index,nextIndex;
        for (int a = 0; a < thePlainText.length(); a++) {
            cipherChar = executeStreamCipher(thePlainText.charAt(a), theKey);
            index = getCharacterPositionInAlphabetsScheme(cipherChar);
         if (index ==(alphabets.length - 1) ) {
              nextIndex = 0;
           } else {
            nextIndex = index + 1;
         }//end else
            //System.out.println("index:"+index);
            theCipherText = theCipherText + cipherChar +  alphabets[nextIndex];
           // System.out.println("index = " + index);
            /*+executeStreamCipher(,theKey) */
        }//end for
        return theCipherText;
    }//end encryptMessage()

    /**
     * deciphers the cipher text
     */
    public static String decryptMessage(String theCipherText, int theKey) {
        theCipherText = permutateFirstByLast(theCipherText);
        //System.out.println("permutated text :"+theCipherText);
        String thePlainText = "";
        char cipherChar;
        int index,nextIndex;
        try {
            //thePlainText = thePlainText + executeStreamDeCipher(theCipherText.charAt(0), theKey);
            for (int a = 1; a < theCipherText.length(); a+=2) {//loops through cahracters of the cipher text
               //cipherChar = executeStreamDeCipher(theCipherText.charAt(a), theKey);
               //index = getCharacterPositionInAlphabetsScheme(cipherChar);
                thePlainText = thePlainText + executeStreamDeCipher(theCipherText.charAt(a), theKey);
            }//end for
        } catch (Exception e) {
        }
        return thePlainText;
    }//end decryptMessage()

    /**
     * translate each character with respect to the key,
     */
    public static char executeStreamCipher(char c, int key) {
        char cipherChar = ' ';
        int size = alphabets.length - 1;
        int cycleStatus;
        for (int a = 0; a < alphabets.length; a++) {//loops through character set, excluding alphabets[0]         
            if (c == alphabets[a]) {//match found             
                cycleStatus = a + key;//evaluates the cycle status
                if (cycleStatus <= size) {//normal case - does not warrant cycling
                    cipherChar = alphabets[ cycleStatus];//appropriate cipher character
                    break;
                }//end if
                else {//this case warrants cycling
                    cipherChar = alphabets[ cycleStatus - size];//appropriate cipher character
                    break;
                }//end else 
            }//end if
        }//end for
        return cipherChar;
    }//end executeStreamCipher()

    /**
     * translate each character with respect to the key,
     */
    public static char executeStreamDeCipher(char c, int key) {
        char deCipherChar = ' ';
        int size = alphabets.length - 1;
        int cycleStatus;
        for (int a = 0; a < alphabets.length; a++) {//loops through character set, excluding alphabets[0]  
            if (c == alphabets[a]) {//match found    
                cycleStatus = a - key;//evaluates cycle status
                if (cycleStatus >= 0) {//normal case - does not warrant cycling
                    deCipherChar = alphabets[cycleStatus];//appropriate cipher character
                    break;//exits loop
                }//end if
                else {//case warrants cycling
                    deCipherChar = alphabets[ size + cycleStatus];//appropriate cipher character
                    break;//exits loop
                }//end else
            } //end if 
        }//end for loop
        return deCipherChar;
    }//end executeStreamDeCipher()

    /**
     * returns the character position of the character value as predefined in
     * the alphabetical scheme
     */
    private static int getCharacterPositionInAlphabetsScheme(char character) {
        int charPosition = 0;
        for (char a :alphabets) {
            if (character == a) {
                break;//exits loop
            }//end if
            charPosition++;
        }//end for loop

        return charPosition;
    }//end getCharacterPositionInAlphabetsScheme()

    private static String permutateFirstByLast(String thePlainText) {
        char[] textArray = thePlainText.toCharArray();
        String permutatedText = "";
        char temp;
        for (int a = 0; a < textArray.length / 2; a++) {
            temp = textArray[a];
            textArray[a] = textArray[textArray.length - 1 - a];
            textArray[textArray.length - 1 - a] = temp;
        }//end for
        for (int b = 0; b < textArray.length; b++) {
            permutatedText = permutatedText + textArray[b];
        }
        return permutatedText;
    }
    
    public static void main(String[] args){

        System.out.println(alphabets.length);
    }//end main()
}

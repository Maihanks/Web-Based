/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package com.maihanks.enhancedCaesarCipher;

/**
 *
 * @author MAIHANKS
 */
public class MainClass {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        CaesarCipher caesarCipher = new CaesarCipher();
        String plainText = " ",cipherText,decryptedText;
        int key = 1;
        cipherText = CaesarCipher.encryptMessage(plainText, key);
        decryptedText = CaesarCipher.decryptMessage(cipherText, key);
        //System.out.println("plain Text ="+plainText);
        //System.out.println("cipher text ="+cipherText);
        //System.out.println("decrypted Text ="+decryptedText);
        //String p = CaesarCipher.permutateFirstByLast(plainText);
       // System.out.println(p);
       //-biil.clihp.lrq.qebob
       //bobeq.qrl.philc.liib-
    }
}

/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package elevatorcontrolsystem;

import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import javax.swing.*;
import trash.LogoAnimatorJPanel;

/**
 *
 * @author MAIHANKS
 */
public class OutputInterface extends JFrame{

    JFrame parentFrame = new JFrame("Elevator output Analysis");
    JPanel parentPanel = new JPanel();
    private JLabel elevatorDescriptionLabel = new JLabel("Elevator");
    private JLabel elevatorsStatusLabelDescription = new JLabel("Status");
    private JLabel priorityLevelLabel = new JLabel("Priority Value");
    private JLabel[] elevators = {new JLabel("Elevator 1"), new JLabel("Elevator 2"), new JLabel("Elevator 3"), new JLabel("Elevator 4"), new JLabel("Elevator 5")};
    private JLabel[] elevatorsStatusLabel = {new JLabel(""), new JLabel(""), new JLabel(""), new JLabel(""), new JLabel("")};
    private JLabel[] elevatorPriorityValuesLabels = {new JLabel(""), new JLabel(""), new JLabel(""), new JLabel(""), new JLabel("")};
    private JLabel recommendedElevatorDescriptionLabel = new JLabel("Most Appropriate Elevator for usage :");
    private JLabel recommendedElevatorLabel = new JLabel();
    private String[] status = {"Busy", "Idle"};
    ElevatorDecisionManager elevatorDecisionManager;
    private double[] elevatorPriorityValues = new double[elevators.length];
    private Timer animationTimer; // Timer drives animation
    private final int ANIMATION_DELAY = 1000; // millisecond delay
    private String currentText = ""; // current image index
    private String emptyString = "";
    private String elevatorOutput = "";

    public OutputInterface(ElevatorDecisionManager theElevatorDecisionManager) {
        elevatorDecisionManager = theElevatorDecisionManager;
        this.setBounds(200, 50, 1000, 500);
        this.setResizable(false);
        //parentFrame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        elevatorPriorityValues = elevatorDecisionManager.getAllElevatorsPriorityValues();
        setUpParentPanel();
    }

    private void setUpParentPanel() {
        parentPanel.setSize(this.getWidth(), this.getHeight());
        parentPanel.setBackground(Color.LIGHT_GRAY);
        parentPanel.setLayout(new GridLayout(7, 3));

        parentPanel.add(elevatorDescriptionLabel);
        parentPanel.add(elevatorsStatusLabelDescription);
        parentPanel.add(priorityLevelLabel);
        for (int a = 0; a < elevators.length; a++) {
            parentPanel.add(elevators[a]);
            double st = elevatorDecisionManager.getAllElevatorsPriorityValues()[a];
            if (st == 0) {
                elevatorsStatusLabel[a].setText(status[1]);
            } else {
                elevatorsStatusLabel[a].setText(status[0]);
            }
            parentPanel.add(elevatorsStatusLabel[a]);
            elevatorPriorityValuesLabels[a].setText(elevatorPriorityValues[a] + "");
            parentPanel.add(elevatorPriorityValuesLabels[a]);
        }
        parentPanel.add(recommendedElevatorDescriptionLabel);
        elevatorOutput  = elevatorDecisionManager.getElevatorWithHighestPriority();
        recommendedElevatorLabel.setText(elevatorDecisionManager.getElevatorWithHighestPriority());
        parentPanel.add(recommendedElevatorLabel);
        parentPanel.add(new JLabel(""));


        this.add(parentPanel);
    }

    public void displayOutput() {
        this.setVisible(true);
    }


    // display current image
    @Override
    public void paintComponents(Graphics g) {
        super.paintComponents(g);
        recommendedElevatorLabel.paint(g);
        // set next image to be drawn only if timer is running
        if (animationTimer.isRunning()) {
        //currentImage = (currentImage + 1) % TOTAL_IMAGES;
        currentText =  emptyString;
        currentText =  elevatorOutput;
        }
    }

    

    // start animation, or restart if window is redisplayed
    public void startAnimation() {
        if (animationTimer == null) {
             currentText = ""; // display first image
            // create timer                                     
            animationTimer = new Timer(ANIMATION_DELAY, new OutputInterface.TimerHandler());
            animationTimer.start(); // start timer
        } // end if
        else // animationTimer already exists, restart animation
        {
            if (!animationTimer.isRunning()) {
                animationTimer.restart();
            }
        } // end else
    } // end method startAnimation

    // stop animation timer
    public void stopAnimation() {
        animationTimer.stop();
    } // end method stopAnimation

  
      // inner class to handle action events from Timer
    private class TimerHandler implements ActionListener {
        // respond to Timer's event
        public void actionPerformed(ActionEvent actionEvent) {
            repaint(); // repaint animator
        } // end method actionPerformed
    } // end class TimerHandler  
    
    public static void main(String[] args) {
        OutputInterface OutputInterface = new OutputInterface(null);
        OutputInterface.displayOutput();
    }
}

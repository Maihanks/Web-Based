/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package elevatorcontrolsystem;

/**
 *
 * @author MAIHANKS
 */
public class ElevatorDecisionManager {

    private String[] elevators;
    private String[] elevatorsCurrentFloors;
    private int[] numberOfPersons;
    private String clientdestinationFloor;
    private String clientCurrentFloor;
    private final int MAX_NUM_OF_CLIENTS_PER_ELEVATOR;
    private int[] elevatorsDistancesFromCurrentFloor = new int[5];
    private double[] averagePriorty = new double[5];
    public ElevatorDecisionManager(String[] theElevators, int[] theNumberOfPersons, String[] theElevatorsCurrentFloors, String theClientCurrentFloor, String theClientDestinationFloor, int theMAX_NUM_OF_CLIENTS_PER_ELEVATOR) {
        elevators = theElevators;
        elevatorsCurrentFloors = theElevatorsCurrentFloors;
        numberOfPersons = theNumberOfPersons;
        clientdestinationFloor = theClientDestinationFloor;
        clientCurrentFloor = theClientCurrentFloor;
        MAX_NUM_OF_CLIENTS_PER_ELEVATOR = theMAX_NUM_OF_CLIENTS_PER_ELEVATOR;
        evaluateElevatorDistancesFromCurrentFloor();
    }

    public double getPriorityWrt2numOfPersons(int numOfPersons) {
        double thePriority = 0.0;
        if (MAX_NUM_OF_CLIENTS_PER_ELEVATOR == numOfPersons) {//number of persons currently in the elevator is equal to the maximum number of reuired persosns
            thePriority = 0.0;
        } else if ((MAX_NUM_OF_CLIENTS_PER_ELEVATOR - 1) == numOfPersons) {//number of persons currently in the elevator is one less than the required maximum number
            thePriority = 2;
        } else if ((MAX_NUM_OF_CLIENTS_PER_ELEVATOR / 2) == numOfPersons) {//number of persons in the elevator are equal to half the required maximum size
            thePriority = 5;
        }
        return thePriority;
    }//end 

    private void evaluateElevatorDistancesFromCurrentFloor() {
        for (int a = 0; a < elevatorsDistancesFromCurrentFloor.length; a++) {
            if(a!=5){
            elevatorsDistancesFromCurrentFloor[a] = Math.abs((Integer.parseInt(elevatorsCurrentFloors[a].substring(elevatorsCurrentFloors[a].length() - 1)) - Integer.parseInt(clientCurrentFloor.substring(clientCurrentFloor.length() - 1))));
            }else{//elevator is either ascending or descending from a particular floor            
                if(elevatorsCurrentFloors[a].substring(0).equals("a")){//elevator is currently ascending
                elevatorsDistancesFromCurrentFloor[a] = Integer.parseInt(Math.abs((Integer.parseInt(elevatorsCurrentFloors[a].substring(elevatorsCurrentFloors[a].length() - 1)) - Integer.parseInt(clientCurrentFloor.substring(clientCurrentFloor.length() - 1)))-0.5)+"");    
                }else{//elevator is currently descending
                elevatorsDistancesFromCurrentFloor[a] = Integer.parseInt(Math.abs((Integer.parseInt(elevatorsCurrentFloors[a].substring(elevatorsCurrentFloors[a].length() - 1)) - Integer.parseInt(clientCurrentFloor.substring(clientCurrentFloor.length() - 1)))+0.5)+"");    
                }
            }
        }
    }

    public double getPriorityWrt2DistanceFromCallingFloor(int distanceFromCallingFloor) {
        double thePriority = 0.0;
        if (distanceFromCallingFloor == 1) {
            thePriority = 5.0;
        } else if (distanceFromCallingFloor == 2) {
            thePriority = 4.0;
        } else if (distanceFromCallingFloor == 3) {
            thePriority = 3.0;
        } else if (distanceFromCallingFloor == 4) {
            thePriority = 2.0;
        } else if (distanceFromCallingFloor == 5) {
            thePriority = 1.0;
        }
        return thePriority;
    }

    public double evaluateElevatorPriority() {
        double thePriority = 0.0;
        return thePriority;
    }

    public String getElevatorWithHighestPriority() {
        String elevator = "";
        double priority1 = 0, priority2 = 0, maximumPriority = 0;

        for (int a = 0; a < elevators.length; a++) {
            priority1 = getPriorityWrt2numOfPersons(elevatorsDistancesFromCurrentFloor[a]);
            priority2 = getPriorityWrt2DistanceFromCallingFloor(elevatorsDistancesFromCurrentFloor[a]);
            averagePriorty[a] = (priority1 + priority2) / 2;
        }
        for (int b = 0; b < averagePriorty.length; b++) {
            if (averagePriorty[b] > maximumPriority) {
                maximumPriority = averagePriorty[b];
            }
        }

        for (int b = 0; b < averagePriorty.length; b++) {
            if (averagePriorty[b] == maximumPriority) {
                elevator = elevators[b];
            }
        }
        return elevator;
    }
public double[] getAllElevatorsPriorityValues(){
getElevatorWithHighestPriority();
return averagePriorty;
}
    public void main(String[] args) {
    }
}

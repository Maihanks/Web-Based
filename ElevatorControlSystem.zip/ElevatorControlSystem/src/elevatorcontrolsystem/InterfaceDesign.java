/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package elevatorcontrolsystem;

import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import javax.swing.*;

/**
 *
 * @author MAIHANKS
 */
public class InterfaceDesign {
    private final int MAX_NUM_OF_CLIENTS_PER_ELEVATOR = 10;
    private final int NUMBER_OF_ELEVATORS = 5;
    private JFrame parentFrame = new JFrame("Elevator Control System");
    private String[] theFloorNames = {"Floor1", "Floor2", "Floor3", "Floor4", "Floor5"};
    private JLabel[] theFloorLabels = new JLabel[NUMBER_OF_ELEVATORS];
    private JTextField[] theFloorStatus = new JTextField[NUMBER_OF_ELEVATORS];
    private JComboBox floors = new JComboBox(theFloorNames);
    private JPanel parentPanel = new JPanel(), leftTopPanel = new JPanel(), leftBottomPanel = new JPanel(), rightTopPanel = new JPanel(), rightBottomPanel = new JPanel();
    private JLabel generalElevatorDescriptor = new JLabel("Elevators");
    private JLabel[] elevatorDescriptor = new JLabel[NUMBER_OF_ELEVATORS];
    private JLabel numberOfPersonsDescriptor = new JLabel("Number Of Persons");
    private JTextField[] numberOfPersonsTextFields = new JTextField[NUMBER_OF_ELEVATORS];
    private JLabel generalCurrentFloorDescriptor = new JLabel("Current Floor :");
    private JComboBox[] currentFloorComboBox = new JComboBox[NUMBER_OF_ELEVATORS];
    private JLabel clientFloorDescriptor = new JLabel("Client Current Floor : ");
    private JComboBox clientCurrentFloorComboBox = new JComboBox(theFloorNames); 
    private JLabel clientDestinationFloorDescriptor = new JLabel("Client Destination Floor : ");
    private JComboBox clientDestinationFloorComboBox = new JComboBox(theFloorNames);
    private JButton elevatorRequestButton = new JButton("Request for Elevator");
    String output = "";
    private String[] elevators = {"Elevator 1", "Elevator 2", "Elevator 3", "Elevator 4", "Elevator 5"};
    private String[] elevatorsCurrentFloors = new String[NUMBER_OF_ELEVATORS];
    private int[] numberOfPersons = new int[NUMBER_OF_ELEVATORS];
    private String clientdestinationFloor;
    private String clientCurrentFloor;
    OutputInterface outputInterface;
    static String[] elevatorPosition =  new String[]{"Floor1", "Floor2", "Floor3", "Floor4", "Floor5","ascending Floor2","ascending Floor3","ascending Floor4","ascending Floor5"
            ,"desscending Floor4" ,"desscending Floor3","desscending Floor2","desscending Floor1"};
ElevatorDecisionManager elevatorDecisionManager;
    public InterfaceDesign() {
        parentFrame.setBounds(200, 50, 1000, 550);
        parentFrame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        parentFrame.setResizable(false);
        setUpParentFrameCoponents();
        setUpEventHandlers();
    }

    private boolean areInputsValid() {
        boolean status = true;
        for (int a = 0; a < numberOfPersonsTextFields.length; a++) {
            if ((numberOfPersonsTextFields[a].getText().equals(null)) && (numberOfPersonsTextFields[a].equals(""))) {
                status = false;
                break;
            }
            try {
                Integer.parseInt(numberOfPersonsTextFields[a].getText());
                if(Integer.parseInt(numberOfPersonsTextFields[a].getText()) > this.MAX_NUM_OF_CLIENTS_PER_ELEVATOR ){
                    status = false;
                break;
                }
                    
            } catch (Exception ex) {
                status = false;
                break;
            }
        }
        
//         clientCurrentFloor = clientCurrentFloorComboBox.getSelectedItem().toString();
//         clientdestinationFloor=clientDestinationFloorComboBox.getSelectedItem().toString();
        
        if(clientCurrentFloor.equals(clientdestinationFloor)){
        status =false;
        }else{
        status = true;
        }
        return status;
        
    }

    private void collectInputs() {
        for(int a = 0; a<elevatorsCurrentFloors.length; a++){
            elevatorsCurrentFloors[a] = currentFloorComboBox[a].getSelectedItem().toString();
            numberOfPersons[a] = Integer.parseInt(numberOfPersonsTextFields[a].getText());
        }
         clientCurrentFloor = clientCurrentFloorComboBox.getSelectedItem().toString();
         clientdestinationFloor=clientDestinationFloorComboBox.getSelectedItem().toString();
    }

    private void setUpParentFrameCoponents() {
        parentPanel.setLayout(new GridLayout(2, 2));
        leftTopPanel.setBackground(Color.GRAY);
        rightTopPanel.setBackground(Color.GRAY);
        leftBottomPanel.setBackground(Color.GRAY);
        rightBottomPanel.setBackground(Color.GRAY);

        setUpLeftPanel();
        setUpRightPanel();

        parentPanel.add(leftTopPanel);
        parentPanel.add(rightTopPanel);
        parentPanel.add(leftBottomPanel);
        parentPanel.add(rightBottomPanel);


        parentPanel.setBackground(Color.red);
        parentFrame.add(parentPanel);
    }

    private void setUpLeftPanel() {
        leftTopPanel.setLayout(new GridLayout(6, 3));
        int c = 0;
        for (int a = 0; a < elevatorDescriptor.length; a++) {
            c = a + 1;
            elevatorDescriptor[a] = new JLabel("Elevator " + c);
            numberOfPersonsTextFields[a] = new JTextField();
        }
        currentFloorComboBox[0] = new JComboBox(elevatorPosition);
        currentFloorComboBox[1] = new JComboBox(elevatorPosition);
        currentFloorComboBox[2] = new JComboBox(elevatorPosition);
        currentFloorComboBox[3] = new JComboBox(elevatorPosition);
        currentFloorComboBox[4] = new JComboBox(elevatorPosition);

        clientDestinationFloorComboBox = new JComboBox(new String[]{"Floor5", "Floor2", "Floor3", "Floor4", "Floor1"});

        leftTopPanel.add(generalElevatorDescriptor);
        leftTopPanel.add(numberOfPersonsDescriptor);
        leftTopPanel.add(generalCurrentFloorDescriptor);

        leftTopPanel.add(elevatorDescriptor[0]);
        leftTopPanel.add(numberOfPersonsTextFields[0]);
        leftTopPanel.add(currentFloorComboBox[0]);

        leftTopPanel.add(elevatorDescriptor[1]);
        leftTopPanel.add(numberOfPersonsTextFields[1]);
        leftTopPanel.add(currentFloorComboBox[1]);

        leftTopPanel.add(elevatorDescriptor[2]);
        leftTopPanel.add(numberOfPersonsTextFields[2]);
        leftTopPanel.add(currentFloorComboBox[2]);

        leftTopPanel.add(elevatorDescriptor[3]);
        leftTopPanel.add(numberOfPersonsTextFields[3]);
        leftTopPanel.add(currentFloorComboBox[3]);

        leftTopPanel.add(elevatorDescriptor[4]);
        leftTopPanel.add(numberOfPersonsTextFields[4]);
        leftTopPanel.add(currentFloorComboBox[4]);
    }

    private void setUpRightPanel() {
        rightTopPanel.setLayout(null);
        clientFloorDescriptor.setBounds(20, 30, 150, 50);
        clientCurrentFloorComboBox.setBounds(180, 30, 150, 50);

        clientDestinationFloorDescriptor.setBounds(20, 100, 150, 50);
        clientDestinationFloorComboBox.setBounds(200, 100, 150, 50);

        elevatorRequestButton.setBounds(70, 200, 150, 50);


        rightTopPanel.add(clientFloorDescriptor);
        rightTopPanel.add(clientCurrentFloorComboBox);

        rightTopPanel.add(clientDestinationFloorDescriptor);
        rightTopPanel.add(clientDestinationFloorComboBox);

        rightTopPanel.add(elevatorRequestButton);
    }

    private void setUpEventHandlers() {
        this.elevatorRequestButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                 collectInputs();
                if (areInputsValid() == true) {
                   
                    elevatorDecisionManager = new ElevatorDecisionManager(elevators,numberOfPersons,elevatorsCurrentFloors,clientCurrentFloor,clientdestinationFloor,MAX_NUM_OF_CLIENTS_PER_ELEVATOR);
//                    output = "The Most Appropriate elevator for usage is : "+elevatorDecisionManager.getElevatorWithHighestPriority();
//                    JOptionPane.showMessageDialog(null, output);
                    outputInterface = new OutputInterface(elevatorDecisionManager);
                    outputInterface.displayOutput();
                } else {
                    JOptionPane.showMessageDialog(null, "One or more inputs are invalid!\nEnsure that number of clients per elevator does not exceed "+MAX_NUM_OF_CLIENTS_PER_ELEVATOR);
                }
            }
        });
    }

    public void display() {
        parentFrame.setVisible(true);
    }

    public static void main(String[] args) {
        InterfaceDesign InterfaceDesign = new InterfaceDesign();
        InterfaceDesign.display();
    }
}

/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package trash;

import java.awt.*;
import java.awt.event.*;
import javax.swing.*;

/**
 *
 * @author MAIHANKS
 */
public class LogoAnimatorJPanel extends JPanel {

    private final static String IMAGE_NAME = "C:\\Users\\MAIHANKS\\Desktop\\Gallery\\pictures\\football\\"; // base image name
    protected ImageIcon images[]; // array of images
    private final int TOTAL_IMAGES = 10; // number of images
    private int currentImage = 0; // current image index
    private final int ANIMATION_DELAY = 1000; // millisecond delay
    private int width; // image width
    private int height; // image height
    private Timer animationTimer; // Timer drives animation
    // constructor initializes LogoAnimatorJPanel by loading images
    public LogoAnimatorJPanel() {
        images = new ImageIcon[TOTAL_IMAGES];
        // load 30 images
        for (int count = 0; count < images.length; count++) {
            images[ count] = new ImageIcon(IMAGE_NAME + count + ".jpg");
 //getClass().getResource( IMAGE_NAME + count + ".jpg")           
        }

        // this example assumes all images have the same width and height
        width = images[ 0].getIconWidth();   // get icon width
        height = images[ 0].getIconHeight(); // get icon height
    } // end LogoAnimatorJPanel constructor

    // display current image
    @Override
    public void paintComponent(Graphics g) {
        super.paintComponent(g); // call superclass paintComponent
        images[ currentImage].paintIcon(this, g, 0, 0);
        // set next image to be drawn only if timer is running
        if (animationTimer.isRunning()) {
            currentImage = (currentImage + 1) % TOTAL_IMAGES;
        }
    } // end method paintComponent

    // start animation, or restart if window is redisplayed
    public void startAnimation() {
        if (animationTimer == null) {
            currentImage = 0; // display first image
            // create timer                                     
            animationTimer = new Timer(ANIMATION_DELAY, new TimerHandler());
            animationTimer.start(); // start timer
        } // end if
        else // animationTimer already exists, restart animation
        {
            if (!animationTimer.isRunning()) {
                animationTimer.restart();
            }
        } // end else
    } // end method startAnimation

    // stop animation timer
    public void stopAnimation() {
        animationTimer.stop();
    } // end method stopAnimation

    // return minimum size of animation
    public Dimension getMinimumSize() {
        return getPreferredSize();
    } // end method getMinimumSize     

    // return preferred size of animation    
    public Dimension getPreferredSize() {
        return new Dimension(width, height);
    } // end method getPreferredSize         

    // inner class to handle action events from Timer
    private class TimerHandler implements ActionListener {
        // respond to Timer's event
        public void actionPerformed(ActionEvent actionEvent) {
            repaint(); // repaint animator
        } // end method actionPerformed
    } // end class TimerHandler
}

/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package trash;

import javax.swing.JFrame;

/**
 *
 * @author MAIHANKS
 */
public class LogoAnimator {
  // execute animation in a JFrame
      public static void main( String args[] )
      {
        LogoAnimatorJPanel animation = new LogoAnimatorJPanel();

        JFrame window = new JFrame( "Animator test" ); // set up window
        window.setBounds(50, 50, 500,500);
        window.setDefaultCloseOperation( JFrame.EXIT_ON_CLOSE );
        window.add( animation ); // add panel to frame

        window.pack(); // make window just large enough for its GUI
        window.setVisible( true );  // display window

        animation.startAnimation(); // begin animation
     } // end main
    
}

/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package com.maihanks.pupilAssistant;

import java.awt.Color;
import java.awt.Component;
import java.awt.Graphics;
import java.awt.GridLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import javax.swing.*;

/**
 *
 * @author MAIHANKS
 */
public class TakeTestHome extends JFrame {

    JButton mathsButton = new JButton(), englishButton = new JButton();
    String username;
    private JFrame parentFrame = new JFrame("Pupil Tutor");
    private JPanel parentPanel = new JPanel();
    private JPanel testPanel = new JPanel();
    private JButton homeButton = new JButton("home"), logoutButton = new JButton("logout");
    private JPanel menuPanel = new JPanel();

    public TakeTestHome(String theUsername) {
        username = theUsername;
        parentFrame.setBounds(250, 50, 1000, 600);
        parentFrame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        parentFrame.setResizable(false);
    }

    public void launch() {
        setUpParentFrameComponents();
        setUpEventHandlers();
        parentFrame.setVisible(true);
    }

    private void setUpParentFrameComponents() {
        parentFrame.setLayout(new GridLayout(1,1));
        parentPanel.setLayout(null);
        parentPanel.setBackground(Color.DARK_GRAY);
        
        
        menuPanel.setBounds(0, 0, 1000,50);
        menuPanel.setLayout(null);
        menuPanel.setBackground(Color.DARK_GRAY);
        homeButton.setBounds(20, 3, 150,40);
        logoutButton.setBounds(200, 3, 150,40);
        menuPanel.add(homeButton);
        menuPanel.add(logoutButton);
        
        testPanel.setBounds(0, 50, 1000, 500);
        testPanel.setLayout(new GridLayout(1, 1));
        ImageIcon mathsImageIcon = new javax.swing.ImageIcon("src\\com\\maihanks\\Resources\\images\\bigmaths.jpg");
        ImageIcon englishImageIcon = new javax.swing.ImageIcon("src\\com\\maihanks\\Resources\\images\\test-your-english.png");
        englishButton.setIcon(englishImageIcon);
        mathsButton.setIcon(mathsImageIcon);
        testPanel.add(mathsButton);
        testPanel.add(englishButton);
        
        parentPanel.add(menuPanel);
        parentPanel.add(testPanel);
        parentFrame.add(parentPanel);
    }

    private void setUpEventHandlers() {
        englishButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                Assessment assessment = new Assessment(username, new EnglishQuestions());
                assessment.start();
               parentFrame.dispose();
            }
        });

        mathsButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                Assessment assessment = new Assessment(username, new MathsQuestions());
                assessment.start();
               parentFrame.dispose();
            }
        });
        homeButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                PupilHome pupilHome = new PupilHome(username);
                pupilHome.start();
                parentFrame.dispose();
            }
        });
        logoutButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                Login login = new Login();
                login.start();
                parentFrame.dispose();
            }
        });
    }
    
    public static void main(String[] args){
    TakeTestHome th = new TakeTestHome("");
    th.launch();
    }
}

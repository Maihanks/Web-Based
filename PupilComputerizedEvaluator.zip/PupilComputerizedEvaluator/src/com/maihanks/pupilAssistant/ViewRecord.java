/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package com.maihanks.pupilAssistant;

import com.maihanks.FileDatabaseManager.Database;
import java.awt.Color;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.Arrays;
import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import javax.swing.table.TableModel;

/**
 *
 * @author MAIHANKS
 */
public class ViewRecord extends JFrame {
String pupilUsername;
    /**
     * This class Displays a frame containing a table with records according the
     * it's invoked method
     */
    private String databaseUrl;
    private JTable table;
    private DefaultTableModel model;
    private Database databaseAccess;
    private String[] columnHeaders;
    private JPanel parentPanel = new JPanel();
    private JButton homeButton = new JButton("Home");

    public ViewRecord(String theDatabaseUrl, String[] theColumnHeaders) {
        super("Statistics");
        this.databaseUrl = theDatabaseUrl;
        databaseAccess = new Database(databaseUrl);
        columnHeaders = theColumnHeaders;
        table = new JTable();
        model = new DefaultTableModel();
        parentPanel.setBackground(Color.WHITE.darker());
        parentPanel.setLayout(null);//absolute positioning
        super.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        super.setBounds(250, 100, 700, 500);
        registerEventHandlers();
    }
    
 
/**
 * to be used when displaying a student's performance
 * @param thePupilUsername 
 */
  public ViewRecord(String thePupilUsername) {
  super("Statistics");
         pupilUsername = thePupilUsername; 
        table = new JTable();
        model = new DefaultTableModel();
        parentPanel.setBackground(Color.WHITE.darker());
        parentPanel.setLayout(null);//absolute positioning
        super.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        super.setBounds(250, 100, 700, 500);
        registerEventHandlers();
    }//end ViewRecord()

    public String getPupilUsername() {
        return pupilUsername;
    }

    public void setPupilUsername(String pupilUsername) {
        this.pupilUsername = pupilUsername;
    }

    

    public void viewAllRecords() {
        model.setColumnIdentifiers(columnHeaders);
        table.setModel(model);
        String record[] = new String[columnHeaders.length];
        String allRecords[] = databaseAccess.getAllRows();

        for (int a = 0; a < allRecords.length; a++) {
            record = databaseAccess.getSingleRowAttributes(allRecords[a]);
            model.addRow(record);
        }//end for
        table.setBackground(Color.WHITE.darker());
        JScrollPane scroll = new JScrollPane(table);
        scroll.setBounds(10, 10, 650, 400);
        homeButton.setBounds(500, 410, 150, 40);
        parentPanel.add(scroll);
        parentPanel.add(homeButton);
        super.add(parentPanel);

        super.setVisible(true);
    }

    /**
     * this method displays the records of a single individual with respect to
     * the columnPosition and searchKey
     *
     * @param columnPosition the column of interest where match is made as it
     * appears in the database valid value( 0 to n-1)
     * @param searchKey
     */
    public void viewSinglePupilPerformanceRecord(String searchKey) {
       Database dbAccess = new Database(databaseUrl);// new Database("src\\com\\maihanks\\Resources\\Database\\OverseerBiodata.txt");

       ViewRecord viewPupiilPerfomanceRecord = new ViewRecord(searchKey);
        table = viewPupiilPerfomanceRecord.viewSinglePupilPerformanceRecordTable(); //
        table.setBackground(Color.WHITE.darker());
        JScrollPane scroll = new JScrollPane(table);
        parentPanel.add(scroll);
        scroll.setBounds(10, 10, 650, 400);
        homeButton.setBounds(500, 410, 150, 40);
        parentPanel.add(homeButton);
       
        super.add(parentPanel);
        super.setVisible(true);
    }
    
    public void viewAllPupilPerformanceRecord(){
        Database db = new Database("src\\com\\maihanks\\Resources\\Database\\pupilsBiodata.txt");
        String[] rowValues = db.getAllRows();
        String[] userNames = new String[rowValues.length];
        String theColumnHeaders[] = {"Name", "Maths-Easy", "Maths-Difficult", "Maths-Very Difficult", "Maths-Expert",
            "English-Easy", "English-Difficult", "English-Very Difficult", "English-Expert"};//headers for the table
        String percentageValues[] = new String[theColumnHeaders.length - 1];
        
        String thePupilUsername;
        String src = "src\\com\\maihanks\\Resources\\Database\\";
        String pupilName;
        String rec[] = {
            src + "MathsRecordEasy.txt", src + "MathsRecordDifficult.txt", src + "MathsRecordVeryDifficult.txt",
            src + "MathsRecordExpert.txt",
            src + "EnglishRecordEasy.txt",
            src + "EnglishRecordDifficult.txt",
            src + "EnglishRecordVeryDifficult.txt",
            src + "EnglishRecordExpert.txt"};
        String[] record ;
        record = new String[percentageValues.length + 1];
            model.setColumnIdentifiers(theColumnHeaders);
            table.setModel(model);
            // String record[] = new String[rec.length + 1];
        for (int a = 0; a < rowValues.length; a++) {//iterates through all pupils biodata to fetch usernames
            userNames[a] = db.getSingleRowAttributes(rowValues[a])[2];//gets username
            pupilName =  db.getSingleRowAttributes(rowValues[a])[0] +" "+db.getSingleRowAttributes(rowValues[a])[1];//gets pupil's name
             thePupilUsername = userNames[a];
             for (int d = 0; d < rec.length; d++) {//iterates through the courses offered by each pupil
                percentageValues[d] = getPupilSubjectRecordWrtDifficultyLevel(rec[d], thePupilUsername);//performance of each course wrt pupil usernamse  
              //  System.out.println(percentageValues[d]);
            }//end for
          
             
             record[0] = pupilName;
             for(int b = 0; b < rec.length; b++){
                record[b+1] =  percentageValues[b];
                 System.out.println(record[b+1]);
             }//end for
             //System.out.println(thePupilUsername);
          
            model.addRow(record);
        }//end for loop
      
            
        table.setBackground(Color.WHITE.darker());
     JScrollPane scroll = new JScrollPane(table);
        scroll.setBounds(10, 10, 650, 400);
        homeButton.setBounds(500, 410, 150, 40);
        parentPanel.add(scroll);
        parentPanel.add(homeButton);
       // super.setBounds(250, 100, 1000, 500);
        super.add(parentPanel);

        super.setVisible(true);
    }
    
    /**
     * returns a table containing a  single pupil's assessment record
     * @param thePupilUsername 
     */
public JTable viewSinglePupilPerformanceRecordTable(){
  //JOptionPane.showMessageDialog(null, "my user : \n"+ this.getPupilUsername());
    String thePupilUsername ="user1";// this.pupilUsername;
    String theColumnHeaders [] = 
    {"Maths-Easy", "Maths-Difficult", "Maths-Very Difficult", "Maths-Expert",
            "English-Easy", "English-Difficult", "English-Very Difficult", "English-Expert"};//headers for the table
  String percentageValues[] = new String[theColumnHeaders.length]; 
    model.setColumnIdentifiers(theColumnHeaders);
        table.setModel(model);

    String src = "src\\com\\maihanks\\Resources\\Database\\";
    String rec[] = {
        src + "MathsRecordEasy.txt", src + "MathsRecordDifficult.txt", src + "MathsRecordVeryDifficult.txt",
        src + "MathsRecordExpert.txt",
        src + "EnglishRecordEasy.txt",
        src +"EnglishRecordDifficult.txt",
        src +"EnglishRecordVeryDifficult.txt",
        src +"EnglishRecordExpert.txt",};
    String record[] = new String[rec.length];
    for (int d = 0; d < rec.length; d++) {
        //try{
        percentageValues[d] = getPupilSubjectRecordWrtDifficultyLevel(rec[d], thePupilUsername);
       // }catch(Exception ex){
         // percentageValues[d]="No Record";
        //}
    }//end for
     model.addRow(percentageValues);

 model.addRow(record);
        table.setBackground(Color.WHITE.darker());
    return table;
}//end viewSinglePupilPerformanceRecordTable()


public JTable viewSinglePupilPerformanceRecordTable(String username){
  //JOptionPane.showMessageDialog(null, "my user : \n"+ this.getPupilUsername());
    String thePupilUsername = username;// this.pupilUsername;
    String theColumnHeaders [] = 
    {"Maths-Easy", "Maths-Difficult", "Maths-Very Difficult", "Maths-Expert",
            "English-Easy", "English-Difficult", "English-Very Difficult", "English-Expert"};//headers for the table
  String percentageValues[] = new String[theColumnHeaders.length]; 
    model.setColumnIdentifiers(theColumnHeaders);
        table.setModel(model);

    String src = "src\\com\\maihanks\\Resources\\Database\\";
    String rec[] = {
        src + "MathsRecordEasy.txt", src + "MathsRecordDifficult.txt", src + "MathsRecordVeryDifficult.txt",
        src + "MathsRecordExpert.txt",
        src + "EnglishRecordEasy.txt",
        src +"EnglishRecordDifficult.txt",
        src +"EnglishRecordVeryDifficult.txt",
        src +"EnglishRecordExpert.txt",};
    String record[] = new String[rec.length];
    for (int d = 0; d < rec.length; d++) {
        //try{
        percentageValues[d] = getPupilSubjectRecordWrtDifficultyLevel(rec[d], thePupilUsername);
       // }catch(Exception ex){
         // percentageValues[d]="No Record";
        //}
    }//end for
     model.addRow(percentageValues);

 model.addRow(record);
        table.setBackground(Color.WHITE.darker());
    return table;
}//end viewSinglePupilPerformanceRecordTable()
    private void registerEventHandlers() {
        homeButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                AdminHome adminHome = new AdminHome(null);
                adminHome.start();
                dispose();
            }
        });
    }
/**
 * returns the percentage performance of a pupil with respect to a subjects difficulty level
 * @param theDatabaseUrl
 * @param searchKey
 * @return 
 */ 
    private String getPupilSubjectRecordWrtDifficultyLevel(String theDatabaseUrl, String searchKey) {
        String pupilrecord[] = null;
        String percentagePassString = "No record";;
         Database dbAccess  = new Database(theDatabaseUrl);
        int columnPosition = 0;
        int numberOfPassess = 0, numberOfFailures = 0, total = 0;
        double percentagePass = 0;
        // try{
        if (dbAccess.getNumberOfRows() > 0) {
            pupilrecord = dbAccess.getAllRowsWithAttributeMatch(columnPosition, searchKey);
            try{
            if (pupilrecord.length > 0) {
                String record[] = new String[dbAccess.getNumberOfRows()];
                for (int a = 0; a < pupilrecord.length - 1; a++) {
                    record = dbAccess.getSingleRowAttributes(pupilrecord[a]);
                    if (record[1].equals("0")) {//failed 
                        numberOfFailures++;
                    } else if (record[1].equals("1")) {//passed
                        numberOfPassess++;
                    }
                }
                total = numberOfFailures + numberOfPassess;
                percentagePass = numberOfPassess * 100 / Double.parseDouble(total + "");
              percentagePass = Math.ceil(percentagePass);
                percentagePassString = percentagePass + " %";
            } else {
                percentagePassString = "No record";
            }
             }catch(Exception ex){
    
}//end catch
        } else {//database  is totally empty
            percentagePassString = "No record";
        }
   
       // System.out.println(percentagePassString);
        return percentagePassString;
    }//end getPupilSubjectRecordWrtDifficultyLevel
    public static void main(String[] args) {
        String[] columns = {"First Name  ", "Last Name ", "User name", "password "};
        ViewRecord viewRecord = new ViewRecord("src\\com\\maihanks\\Resources\\Database\\OverseerBiodata.txt", columns);
       // viewRecord.viewSingleRecord(2, "admin2");
       /* src\\com\\maihanks\\Resources\\Database\\EnglishRecordEasy.txt","user1");*/
  /*      String thePupilUsername = "user1";
        String src = "src\\com\\maihanks\\Resources\\Database\\";
       String record[] = {
        src+"MathsRecordEasy.txt",src+"MathsRecordDifficult.txt",src+"MathsRecordVeryDifficult.txt",
        src+"MathsRecordExpert.txt",    
            src+"EnglishRecordEasy.txt",
        "EnglishRecordDifficult.txt",
        "EnglishRecordVeryDifficult.txt",
        "EnglishRecordExpert.txt",};  
        */
        
        viewRecord.viewAllPupilPerformanceRecord();
        
     //String p =  viewRecord.getPupilSubjectRecordWrtDifficultyLevel(record[2],"user1");
//       String x[] = viewRecord.viewSinglePupilPerformanceRecordTable();
       
    }
}

/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package com.maihanks.pupilAssistant;

/**
 *
 * @author MAIHANKS
 */
public interface Question {

    /**
     * This signifies the difficulty of the question
     */
    public enum DIFFICULTY_LEVEL {

        /**
         * The lowest difficulty level
         */
        EASY,
        /**
         * reasonably difficult
         */
        DIFFICULT,
        /**
         * A little difficult
         */
        VERY_DIFFICULT,
        /**
         * very complex
         */
        EXPERT
    };

    public abstract String generateQuestion(DIFFICULTY_LEVEL difficutLevel);

    public abstract int getNumOfPasses();

    public abstract int getNumOfFailures();

    //public abstract void generateProblem(String problemType);

    public abstract boolean isPromoted(int passes, int failures);

    /**
     * returns the subject of interest i.e maths or english
     *
     * @return
     */
    public abstract String getSubject();

    /**
     * returns comment with respect to performance Applaud is performance is
     * superb and motivation/reprimand if performance is poor
     *
     * @return
     */
    public abstract String getComment(boolean passed);
    /**
     * returns the correct answer
     * @return 
     */
    public abstract String getCorrectAnswer();
 public abstract String[] getOptions();   
}

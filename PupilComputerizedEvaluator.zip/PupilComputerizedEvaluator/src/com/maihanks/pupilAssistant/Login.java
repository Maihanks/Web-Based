/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package com.maihanks.pupilAssistant;

import com.maihanks.FileDatabaseManager.Database;
import com.maihanks.Utitlities.ManipulateFormElements;
import java.awt.GridLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import javax.swing.*;

/**
 *
 * @author MAIHANKS
 */
public class Login extends JFrame {
    
    private JLabel[] descLabels = {new JLabel("Username:"), new JLabel("Password:"), new JLabel()};
    private JTextField usernameTextField = new JTextField();
    private JPasswordField passwordTextField = new JPasswordField();
    private JButton submitButton = new JButton("Login");
    private Database databaseAccess[] = {new Database("src\\com\\maihanks\\Resources\\Database\\OverseerBiodata.txt"), new Database("src\\com\\maihanks\\Resources\\Database\\pupilsBiodata.txt")};
    private String username, password;
    private boolean loginSucess = false;
    private JPanel parentPanel = new JPanel();
    private JPanel imagePanel = new JPanel();
    private JPanel inputPanel = new JPanel();
    Login login;

    public Login() {
        super("Login");
        super.setBounds(500, 200, 500, 250);
        super.setLayout(new GridLayout(5,3));
        super.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        super.setResizable(false);
        super.setLayout(null);
        setUpDislay();
    }

    /**
     * returns the username
     *
     * @return
     */
    public String getUsername() {
        return username;
    }

    /**
     * returns the password
     *
     * @return
     */
    public String getPassword() {
        return password;
    }

    /**
     * returns true if login was successful and false if otherwise
     *
     * @return
     */
    public boolean getLoginSucess() {
        return loginSucess;
    }//end getLoginSucess()

    private void setUpDislay() {
        setUpParentPanelComponents();
    }
    private void setUpParentPanelComponents(){
        parentPanel.setLayout(null);
        parentPanel.setBounds(0, 0, super.getWidth(), super.getHeight());
        
        imagePanel.add(new JLabel(new ImageIcon("src\\com\\maihanks\\Resources\\images\\blank.jpg")));
        imagePanel.setBounds(0, 0, super.getWidth()/2, super.getHeight());
        
        inputPanel.setBounds(imagePanel.getWidth(), 0, super.getWidth()/2-50, super.getHeight());
        inputPanel.setLayout(null);
        //descLabels[0],usernameTextField,descLabels[1],passwordTextField,descLabels[2],submitButton
        descLabels[0].setBounds(5, 5, 70, 60);
        usernameTextField.setBounds(descLabels[0].getWidth()+5, descLabels[0].getY()+10, 120, 35);
        descLabels[1].setBounds(5, usernameTextField.getHeight()+40, descLabels[0].getWidth(), 35);
        passwordTextField.setBounds(usernameTextField.getX()+2, descLabels[1].getHeight()+40, 120, 35);
        submitButton.setBounds(90, 165, 90, 40);
        
        inputPanel.add(descLabels[0]);
        inputPanel.add(usernameTextField);
        inputPanel.add(descLabels[1]);
        inputPanel.add(passwordTextField);
//        inputPanel.add(descLabels[2]);
        inputPanel.add(submitButton);
        
        
        parentPanel.add(imagePanel);
        parentPanel.add(inputPanel);
        
        super.add(parentPanel);
 }
    public void start() {
        registerEventHandler();
        // Login login = this;
        super.setVisible(true);
    }

    /**
     * registers events
     */
    private void registerEventHandler() {
        submitButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                username = usernameTextField.getText();
                password = ManipulateFormElements.getContentOfPasswordField(passwordTextField);
                // JOptionPane.showMessageDialog(null, username+"\n"+password);
                if ((!username.equals("") && !username.equals(null)) && ((!password.equals("") && !password.equals(null)))) {
                    if ((username.charAt(0) + "").equals("a")) {//user is potentially an admin
                        String details[] = databaseAccess[0].getAllRowsWithAttributeMatch(2, username);

                        String userDetails[] = databaseAccess[0].getSingleRowAttributes(details[0]);
                        if (userDetails[2].equals(username) && userDetails[3].equals(password)) {//admin is valid
                            // JOptionPane.showMessageDialog(null, "admin is valid");
                            loginSucess = true;
                            //JOptionPane.showMessageDialog(null, "Admin is valid");

                            AdminHome adminHome = new AdminHome(username);
                            adminHome.start();
                            dispose();
                        } else {
                            JOptionPane.showMessageDialog(null, "invalid username or password ");
                            loginSucess = false;
                        }

                        //JOptionPane.showMessageDialog(null, "User is potentially admin");
                    } else if ((username.charAt(0) + "").equals("u")) {//user is potentially an pupil(user)
                        String details[] = databaseAccess[1].getAllRowsWithAttributeMatch(2, username);
                        String userDetails[] = databaseAccess[1].getSingleRowAttributes(details[0]);
                        if (userDetails[2].equals(username) && userDetails[3].equals(password)) {//admin is valid
                            // JOptionPane.showMessageDialog(null, "User is valid");
                            loginSucess = true;
                            PupilHome pupilHome = new PupilHome(username);
                            pupilHome.start();
                            dispose();
                        } else {
                            JOptionPane.showMessageDialog(null, "invalid username or password ");
                            loginSucess = false;
                        }
                    }//end else
                    else {
                        JOptionPane.showMessageDialog(null, "invalid username or password ");
                        loginSucess = false;
                    }

                }//end if
                else {
                    JOptionPane.showMessageDialog(null, "Please fill in your Username and Password and try again");
                    loginSucess = false;
                }
            }
        });
    }

    public static void main(String[] args) {
        new Login().start();
    }
}

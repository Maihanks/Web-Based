/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package com.maihanks.pupilAssistant;

import java.awt.Color;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JTabbedPane;

/**
 *
 * @author MAIHANKS
 */
public class AdminHome extends JFrame {

    JTabbedPane mainMenuTabbedPane = new javax.swing.JTabbedPane(JTabbedPane.LEFT);
    JPanel mainMenuTabbedPanePanels[] = new JPanel[5];//panels for coresponding tabbed pane
    JLabel mainMenuTabbedPaneTopLabel[] = new JLabel[5], mainMenuTabbedPaneBottomLabel[] = new JLabel[5], mainMenuTabbedPaneCenterLabel[] = new JLabel[5];
    Color mainMenuTabbedPaneColor = Color.WHITE.darker();// new Color(30,67,88);
    JButton registerAdmin = new JButton("Register Admin"), registerPupil = new JButton("Register Pupil");
    String username;
    JButton viewSinglePupilRecord = new JButton("View Single Pupil Record"), viewAllPupilRecords = new JButton("View All Pupil Records"), viewAllPupilBiodata = new JButton("View All pupil Profile");

    public AdminHome(String theUsername) {
        super("Pupil tutor");
        super.setBounds(250, 100, 700, 500);
        super.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setUpMainMenuTabbedPane();
        super.add(mainMenuTabbedPane);
        username = theUsername;
    }

    private void setUpMainMenuTabbedPane() {
        setUpMainMenuTabbePanePanels();
        // mainMenuTabbedPane.setForeground(Color.WHITE);
        mainMenuTabbedPane.addTab("Register User", new ImageIcon("src\\com\\maihanks\\Resources\\images\\Users.png"), mainMenuTabbedPanePanels[0]);
        //mainMenuTabbedPane.addTab("Guides/Tips", new ImageIcon("src\\com\\maihanks\\Resources\\images\\Purple Ball.png"), mainMenuTabbedPanePanels[1]);
        mainMenuTabbedPane.addTab("Statistics", new ImageIcon("src\\com\\maihanks\\Resources\\images\\Donate.png"), mainMenuTabbedPanePanels[2]);
        mainMenuTabbedPane.addTab("Developer", new ImageIcon("src\\com\\maihanks\\Resources\\images\\phone.jpg"), mainMenuTabbedPanePanels[3]);
        mainMenuTabbedPane.addTab("Logout", new ImageIcon("src\\com\\maihanks\\Resources\\images\\logout.png"), mainMenuTabbedPanePanels[4]);
        // mainMenuTabbedPane.addTab("Exit", new ImageIcon("src\\com\\maihanks\\Resources\\images\\Exit.jpg"), mainMenuTabbedPanePanels[4]);
    }//end setUpMainMenuTabbedPane()

    /**
     * sets up the tabbedPanes
     */
    private void setUpMainMenuTabbePanePanels() {
        setUpMainMenuTabbedPaneCenterLabels();
        for (int a = 0; a < mainMenuTabbedPanePanels.length; a++) {
            mainMenuTabbedPanePanels[a] = new JPanel();
            mainMenuTabbedPanePanels[a].setBackground(mainMenuTabbedPaneColor);
            if (a != 2) {
                mainMenuTabbedPanePanels[a].add(mainMenuTabbedPaneCenterLabel[a]/*, BorderLayout.CENTER*/);
            } else {
                mainMenuTabbedPanePanels[a].setBackground(mainMenuTabbedPaneColor);
                mainMenuTabbedPanePanels[a].add(viewSinglePupilRecord);
                mainMenuTabbedPanePanels[a].add(viewAllPupilRecords);
                mainMenuTabbedPanePanels[a].add(viewAllPupilBiodata);
            }
        }//end for loop
        mainMenuTabbedPanePanels[0].add(registerAdmin);
        mainMenuTabbedPanePanels[0].add(registerPupil);
        JLabel imageLabel = new JLabel();
        imageLabel.setIcon(new ImageIcon("src\\com\\maihanks\\Resources\\images\\africanchild.jpg"));
        mainMenuTabbedPanePanels[0].add(imageLabel);

        JLabel developerImageLabel = new JLabel();
        developerImageLabel.setIcon(new ImageIcon("src\\com\\maihanks\\Resources\\images\\Maihanks2.JPG"));
        mainMenuTabbedPanePanels[3].add(developerImageLabel);
    }

    private void setUpMainMenuTabbedPaneCenterLabels() {
        mainMenuTabbedPaneCenterLabel[0] = new JLabel("Register User");
        mainMenuTabbedPaneCenterLabel[1] = new JLabel("Welcome to guide section of the Pupil Assistant App, This Application is designed to assess the "
                + "\nskills of pupils in mathematics and English");
        mainMenuTabbedPaneCenterLabel[1].setBackground(Color.GREEN);
        mainMenuTabbedPaneCenterLabel[2] = new JLabel("records");
        mainMenuTabbedPaneCenterLabel[3] = new JLabel("Developer : MAIHANKS");
        mainMenuTabbedPaneCenterLabel[4] = new JLabel("Exit Section");
    }//end setUpMainMenuTabbedPaneCenterLabels()

    public void start() {
        setUpEventHandlers();
        super.setVisible(true);
    }

    private void setUpEventHandlers() {
        registerAdmin.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                RegisterClient registerClient = new RegisterClient("src\\com\\maihanks\\Resources\\Database\\OverseerBiodata.txt");
                registerClient.start();
                dispose();
            }
        });
        registerPupil.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                RegisterClient registerClient = new RegisterClient("src\\com\\maihanks\\Resources\\Database\\pupilsBiodata.txt");
                registerClient.start();
                dispose();
            }
        });

        viewSinglePupilRecord.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                try {
                    String userName = JOptionPane.showInputDialog(null, "\nEnter pupil's Username");
                    String[] columns = {"First Name  ", "Last Name ", "User name", "password "};
                    if(!userName.equals("") && !userName.equals(null)){
                    ViewRecord viewRecord = new ViewRecord("src\\com\\maihanks\\Resources\\Database\\PupilPerfomanceRecord.txt", columns);
                    viewRecord.viewSinglePupilPerformanceRecord(userName);
                    dispose();
                    }
                } catch (Exception ex) {
                }

            }
        });

        viewAllPupilRecords.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                String[] columns = {"First Name  ", "Last Name ", "User name", "password "};
                ViewRecord viewRecord = new ViewRecord("src\\com\\maihanks\\Resources\\Database\\PupilPerfomanceRecord.txt", columns);
                viewRecord.viewAllPupilPerformanceRecord();
                dispose();
            }
        });

        viewAllPupilBiodata.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                String[] columns = {"First Name  ", "Last Name ", "User name", "password "};
                ViewRecord viewRecord = new ViewRecord("src\\com\\maihanks\\Resources\\Database\\pupilsBiodata.txt", columns);
                viewRecord.viewAllRecords();
                dispose();
            }
        });

    }

    public static void main(String[] args) {
        AdminHome adminHome = new AdminHome("admin1");
        adminHome.start();
    }
}

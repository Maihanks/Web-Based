/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package com.maihanks.pupilAssistant;

import com.maihanks.FileDatabaseManager.Database;
import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Font;
import java.awt.GridLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import javax.swing.*;

/**
 *
 * @author MAIHANKS
 */
public class Assessment extends JFrame {

    private JPanel parentPanel = new JPanel();
    private JPanel difficultyLevelPanel = new JPanel(), questionPanel = new JPanel(), answerPanel = new JPanel(), buttonsPanel = new JPanel();
    private JButton difficultyLevelButtons[] = {new JButton("Easy"), new JButton("Difficult"), new JButton("Very Difficult"), new JButton("Expert")};
    private JLabel questionLabel = new JLabel("");
    private JLabel answersLabel[]= {new JLabel(), new JLabel(), new JLabel(), new JLabel()};
    private JButton submitButton = new JButton("Submit>"), homeButton = new JButton("<Home");
    private Color defaultColor = Color.gray.brighter();//new Color(80, 200, 160);
    private javax.swing.JRadioButton[] englishOptionsRadioButtons = {new JRadioButton(), new JRadioButton(), new JRadioButton(), new JRadioButton()};
    private String correctAnswer = "1", userAnswer = null;//to hold the appropriate answer and user anserw respectively
    private ButtonGroup radioGroup = new ButtonGroup(); // buttongroup to hold radio buttons
    private JTextField mathsAnswerTextField = new JTextField();
    private String subject;//the current subject of interest
    private String username;//the current user's user name
    Question SubjectCategory;//MathsQuestions or Englishquestions
    private Question.DIFFICULTY_LEVEL currentDifficultyLevel;

    public Assessment(String theUsername, Question questionType) {
        super("Pupil Assesement ");
        super.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        super.setResizable(false);
        super.setBounds(250, 100, 600, 500);
        super.setLayout(null);//absolute layout
        parentPanel.setLayout(null);//absolute layout
        SubjectCategory = questionType;
        subject = SubjectCategory.getSubject();
        username = theUsername;
        for (int a = 0; a < englishOptionsRadioButtons.length; a++) {//radio buttons to group
            radioGroup.add(englishOptionsRadioButtons[a]);
        }
        setUpDisplay();
    }//end Assessment()

    public String getSubject() {
        return subject;
    }

    public Question.DIFFICULTY_LEVEL getCurrentDifficultyLevel() {
        return currentDifficultyLevel;
    }

    public void setCurrentDifficultyLevel(Question.DIFFICULTY_LEVEL theDesiredDifficultyLevel) {
        this.currentDifficultyLevel = theDesiredDifficultyLevel;
    }

    private void setUpDisplay() {
        setUpSubPanels();
        parentPanel.setBounds(0, 0, super.getWidth(), super.getHeight());
        parentPanel.setBackground(defaultColor);

        difficultyLevelPanel.setBackground(defaultColor);
        questionPanel.setBackground(Color.WHITE);
        answerPanel.setBackground(defaultColor);
        buttonsPanel.setBackground(defaultColor);

        difficultyLevelPanel.setBounds(1, 50, 150, 200);
        questionPanel.setBounds(difficultyLevelPanel.getWidth(), 50, 275, 300);
        answerPanel.setBounds(difficultyLevelPanel.getWidth() + questionPanel.getWidth(), 50, 700, 300);
        buttonsPanel.setBounds(0, 300, super.getWidth(), 200);



        parentPanel.add(difficultyLevelPanel, BorderLayout.WEST);
        parentPanel.add(questionPanel, BorderLayout.CENTER);
        parentPanel.add(answerPanel, BorderLayout.EAST);
        parentPanel.add(buttonsPanel, BorderLayout.SOUTH);
        super.add(parentPanel);
    }//end setUpDisplay()

    private void setUpSubPanels() {
        difficultyLevelPanel.setLayout(new GridLayout(5, 1));
        difficultyLevelPanel.add(new JLabel("Select Difficulty Level"));
        for (int a = 0; a < difficultyLevelButtons.length; a++) {
            difficultyLevelPanel.add(difficultyLevelButtons[a]);
        }

        questionPanel.add(questionLabel);
        buttonsPanel.setLayout(null);
        submitButton.setBounds(300, 80, 120, 50);
        homeButton.setBounds(150, 80, 120, 50);
        buttonsPanel.add(homeButton);
        buttonsPanel.add(submitButton);

        if (this.getSubject().equalsIgnoreCase("english")) {//current test of interest is english
            answerPanel.setLayout(new GridLayout(4, 1));
            for (int n = 0; n < this.englishOptionsRadioButtons.length; n++) {
                answerPanel.add(englishOptionsRadioButtons[n]);
            }//end for
        } else if (this.getSubject().equalsIgnoreCase("maths")) {//current test of interest is maths
            answerPanel.setLayout(null);
            JLabel anserLabelDesc = new JLabel("Enter Answer");
            anserLabelDesc.setBounds(10, 50, 150, 50);
            mathsAnswerTextField.setBounds(10, 100, 150, 30);
            answerPanel.add(anserLabelDesc);
            answerPanel.add(this.mathsAnswerTextField);
        }//end else
    }

    private void setUpEventHandlers() {
        homeButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                //JOptionPane.showMessageDialog(null, "HomeButton");
                new PupilHome(username).start();
                dispose();
            }
        });
        submitButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                // JOptionPane.showMessageDialog(null, "SubmitButton");
                processUserAnswer();
            }
        });

        difficultyLevelButtons[0].addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                // JOptionPane.showMessageDialog(null, "SubmitButton");
                setCurrentDifficultyLevel(Question.DIFFICULTY_LEVEL.EASY);
                generateQuestion(getCurrentDifficultyLevel());
            }
        });
        difficultyLevelButtons[1].addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                // JOptionPane.showMessageDialog(null, "SubmitButton");
                setCurrentDifficultyLevel(Question.DIFFICULTY_LEVEL.DIFFICULT);
                generateQuestion(getCurrentDifficultyLevel());
            }
        });
        difficultyLevelButtons[2].addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                // JOptionPane.showMessageDialog(null, "SubmitButton");
                setCurrentDifficultyLevel(Question.DIFFICULTY_LEVEL.VERY_DIFFICULT);
                generateQuestion(getCurrentDifficultyLevel());
            }
        });
        difficultyLevelButtons[3].addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                // JOptionPane.showMessageDialog(null, "SubmitButton");
                setCurrentDifficultyLevel(Question.DIFFICULTY_LEVEL.EXPERT);
                generateQuestion(getCurrentDifficultyLevel());
            }
        });
    }//end setUpEventHandlers()

    private void processUserAnswer() {
        collectAnswer();
        int passStatus = 0;
        correctAnswer = SubjectCategory.getCorrectAnswer();
        if (!userAnswer.equals(null) && !userAnswer.equals("")) {
            //JOptionPane.showMessageDialog(null, "Your answer :\n"+userAnswer);
            if (userAnswer.equals(this.correctAnswer)) {//correct answer
                passStatus = 1;
                sendPerformanceToDB(passStatus);
                JOptionPane.showMessageDialog(null, SubjectCategory.getComment(true));
                generateQuestion(this.getCurrentDifficultyLevel());
            } else {//incorrect answer
                passStatus = 0;
                sendPerformanceToDB(passStatus);
                JOptionPane.showMessageDialog(null,SubjectCategory.getComment(false));
            }
        } else {//no answer entered
            JOptionPane.showMessageDialog(null, "Please enter answer");
        }
    }//end processUserAnswer()

    /**
     * collects the answer
     */
    private void collectAnswer() {
        if (this.getSubject().equalsIgnoreCase("maths")) {//curently attempting maths questions
            //JOptionPane.showMessageDialog(null, "Subject is Maths!!");
            if (!this.mathsAnswerTextField.getText().equals(null) && !this.mathsAnswerTextField.getText().equals("")) {//user typed  in an answer
                this.userAnswer = mathsAnswerTextField.getText();
            } else {//user did not type in answer
                JOptionPane.showMessageDialog(null, "Please type in your answer!!");
            }//end else
        } else if (this.getSubject().equalsIgnoreCase("english")) {//curently attempting english questions
            // JOptionPane.showMessageDialog(null, "Subject is English!!");
            boolean userEnteredAnswer = false;
            for (int a = 0; a < englishOptionsRadioButtons.length; a++) {
                if (englishOptionsRadioButtons[a].isSelected()) {//the selected answer
                    userEnteredAnswer = true;
                    this.userAnswer = englishOptionsRadioButtons[a].getText();
                    break;
                } else {
                }
            }//end for
            if (userEnteredAnswer == true) {//user selected an answer
            } else {//user did not select an answer
                JOptionPane.showMessageDialog(null, "Please select one option as answer!!");
            }//end else
        }
    }

    private void generateQuestion(Question.DIFFICULTY_LEVEL desiredDifficultyLevel) {
        if (this.SubjectCategory.getSubject().equalsIgnoreCase("maths")) {//subject of interest is mathematics
            Font font = new java.awt.Font(Font.SANS_SERIF, Font.BOLD, 29) ;
        questionLabel.setFont(font);
            questionLabel.setText(SubjectCategory.generateQuestion(desiredDifficultyLevel));
        } else if (this.SubjectCategory.getSubject().equalsIgnoreCase("english")) {//subject of interest is english
            Font font = new java.awt.Font(Font.SANS_SERIF, Font.BOLD, 12) ;
        questionLabel.setFont(font);
            questionLabel.setText(SubjectCategory.generateQuestion(desiredDifficultyLevel));
            for (int a = 0; a < englishOptionsRadioButtons.length; a++) {//sets optionss to be displayed  
                englishOptionsRadioButtons[a].setText(SubjectCategory.getOptions()[a]);
                //englishOptionsRadioButtons[a].setSelected(false);
            }//end for

        }
        this.correctAnswer = SubjectCategory.getCorrectAnswer();
    }

    public void sendPerformanceToDB(int passStatus) {
        String dbUrl = "";
        String src = "src\\com\\maihanks\\Resources\\Database\\";
        if (SubjectCategory.getSubject().equals("english")) {
            if (getCurrentDifficultyLevel() == Question.DIFFICULTY_LEVEL.EASY) {
                dbUrl = src + "EnglishRecordEasy.txt";
            } else if (getCurrentDifficultyLevel() == Question.DIFFICULTY_LEVEL.DIFFICULT) {
                dbUrl = src + "EnglishRecordDifficult.txt";
            } else if (getCurrentDifficultyLevel() == Question.DIFFICULTY_LEVEL.VERY_DIFFICULT) {
                dbUrl = src + "EnglishRecordVeryDifficult.txt";
            } else if (getCurrentDifficultyLevel() == Question.DIFFICULTY_LEVEL.EXPERT) {
                dbUrl = src + "EnglishRecordExpert.txt";
            }

        }//end if
        else if (SubjectCategory.getSubject().equals("maths")) {
            
            if (getCurrentDifficultyLevel() == Question.DIFFICULTY_LEVEL.EASY) {
                dbUrl = src + "MathsRecordEasy.txt";
            } else if (getCurrentDifficultyLevel() == Question.DIFFICULTY_LEVEL.DIFFICULT) {
                dbUrl = src + "MathsRecordDifficult.txt";
            } else if (getCurrentDifficultyLevel() == Question.DIFFICULTY_LEVEL.VERY_DIFFICULT) {
                dbUrl = src + "MathsRecordVeryDifficult.txt";
            } else if (getCurrentDifficultyLevel() == Question.DIFFICULTY_LEVEL.EXPERT) {
                dbUrl = src + "MathsRecordExpert.txt";
            }
           // JOptionPane.showMessageDialog(null, "dificulty level = "+getCurrentDifficultyLevel()+"\nYou answered "+SubjectCategory.getSubject()+" question\n"+"dbUrl = "+dbUrl+"username = "+username);
        }//end else if
        if (!dbUrl.equals("")) {//process sending to database
            //columns in database: username passStatus
            Database dbAccess = new Database(dbUrl);
            dbAccess.write(username + dbAccess.getDelimeter() + passStatus);
            //JOptionPane.showMessageDialog(null,"records sent to "+dbUrl);
        }//end if
    }//end sendPerformanceToDB()

    /**
     * Starts the assessment
     */
    public void start() {
        setUpEventHandlers();
        super.setVisible(true);
    }

    public static void main(String[] args) {
        EnglishQuestions englishQuestions = new EnglishQuestions();
        MathsQuestions mathsQuestions = new MathsQuestions();
       // Assessment assessment = new Assessment("user2", mathsQuestions);
        Assessment assessment = new Assessment("user1", englishQuestions);

        assessment.start();
    }
}

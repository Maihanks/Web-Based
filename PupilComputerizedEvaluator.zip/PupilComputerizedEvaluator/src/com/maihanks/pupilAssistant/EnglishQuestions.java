/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package com.maihanks.pupilAssistant;

import com.maihanks.FileDatabaseManager.Database;
import java.util.Random;
import javax.swing.JOptionPane;

/**
 *
 * @author MAIHANKS
 */
public class EnglishQuestions implements Question {

    private String generatedQuestion;
    private String questionAttributes[];
    private String questionOptions[] = new String[4];
    Database databaseAccess;
    Random randomNumbers = new Random();
    private String correctAnswer;

    @Override
    public String generateQuestion(DIFFICULTY_LEVEL difficultyLevel) {


        if (difficultyLevel == DIFFICULTY_LEVEL.EASY) { 
            databaseAccess = new Database("src\\com\\maihanks\\Resources\\Database\\EnglishQuestionsEasy.txt");
            prepareQstAndAnswer();
        } else if (difficultyLevel == DIFFICULTY_LEVEL.DIFFICULT) {
            databaseAccess = new Database("src\\com\\maihanks\\Resources\\Database\\EnglishQuestionsDifficult.txt");
            prepareQstAndAnswer();
        } else if (difficultyLevel == DIFFICULTY_LEVEL.VERY_DIFFICULT) {
            databaseAccess = new Database("src\\com\\maihanks\\Resources\\Database\\EnglishQuestionsVeryDifficult.txt");
            prepareQstAndAnswer();
        } else if (difficultyLevel == DIFFICULTY_LEVEL.EXPERT) {
            databaseAccess = new Database("src\\com\\maihanks\\Resources\\Database\\EnglishQuestionsExpert.txt");
            prepareQstAndAnswer();
        }
        return generatedQuestion;
    }

    private void prepareQstAndAnswer() {
        int qstNum = 0;
        qstNum = randomNumbers.nextInt(databaseAccess.getNumberOfRows());//generates one digit number
       // JOptionPane.showMessageDialog(null,"qstNum = "+qstNum);
        questionAttributes = databaseAccess.getSingleRowAttributes(qstNum);
        generatedQuestion = questionAttributes[0];
        correctAnswer =questionAttributes[1];
        int a = randomNumbers.nextInt(4);
        questionOptions[a] = questionAttributes[1];//generates random option index for the  correct answer
        int c = 2;
        for (int b = 0; b < 4; b++) {//shuffles the options
            if (b != a) {
                questionOptions[b] = questionAttributes[c];
                c++;
            }//end if
        }//end for

    }

    @Override
    public int getNumOfPasses() {
        throw new UnsupportedOperationException("Not supported yet.");
    }

    @Override
    public int getNumOfFailures() {
        throw new UnsupportedOperationException("Not supported yet.");
    }

    @Override
    public boolean isPromoted(int passes, int failures) {
        throw new UnsupportedOperationException("Not supported yet.");
    }

    @Override
    public String getSubject() {
        return ("english");
    }

    @Override
    public String getComment(boolean passed) {
        Random randomComments = new Random();
        String comment = null;
        int pass = 1 + randomComments.nextInt(4);
        if (passed == true) {//an instant where a pupil supplies one correct answer
            switch (pass) {
                case 1:
                    comment = "Very good!";
                    break;
                case 2:
                    comment = "Excellent!";
                    break;
                case 3:
                    comment = "Nice Work!";
                    break;
                case 4:
                    comment = "Keep up the good work!";
                    break;
            }//end switch
        }//end if
        else {//an instant where a pupil supplies one wrong answer
            switch (pass) {
                case 1:
                    comment = "No. Please Try again.";
                    break;
                case 2:
                    comment = "Wrong. Try once more";
                    break;
                case 3:
                    comment = "Don't give up!";
                    break;
                case 4:
                    comment = "No. keep trying";
                    break;
            }//end switch 
        }//end else
        return comment;
    }

    @Override
    public String getCorrectAnswer() {
       return correctAnswer;
    }

    @Override
    public String[] getOptions() {
        return questionOptions;
    }
}

/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package com.maihanks.pupilAssistant;

import java.util.Random;
import java.util.Scanner;
/**
 *
 * @author MAIHANKS
 */
public class CAI {

    private static int num1, num2;//the two numbers to be generated with respect to the difficulty level
    private static long pupilAns, correctAns;//pupils answer and accurate answer respectively
    static int numOfPasses = 0, numOfFailures = 0;//number of passess and failures respectively
/**
 * returns the number of questions answered correctly
 * @return 
 */
    public static int getNumOfPasses() {
        return numOfPasses;
    }//end getNumOfPasses()
/**
 * returns the number of questions failed
 * @return 
 */
    public static int getNumOfFailures() {
        return numOfFailures;
    }//end getNumOfFailures()
    
    /**
     * returns the first number generated
     * @return 
     */
    public static int getNum1() {
        return num1;
    }//end getNum1()

    /**
     *  returns the second number generated
     * @return 
     */
    public static int getNum2() {
        return num2;
    }//end getNum2()

    /**
     * generates random numbers with respect to the difficulty level
     * @param difficultyLevel 
     */
    private static void generateNumbers(int difficultyLevel) {
        Random randomNumbers = new Random();
        switch (difficultyLevel) {
            case 1://generates one digit numbers
                num1 = 1 + randomNumbers.nextInt(9);//generates one digit number
                num2 = 1 + randomNumbers.nextInt(9);//generates one digit number
                break;
            case 2://generates two digit numbers
                num1 = 10 + randomNumbers.nextInt(99);//generates two digit number
                num2 = 10 + randomNumbers.nextInt(99);//generates two digit number
                break;
            case 3://generates three digit numbers
                num1 = 100 + randomNumbers.nextInt(999);//generates three digit number
                num2 = 100 + randomNumbers.nextInt(999);//generates three digit number
                break;
            case 4://generates four digit numbers
                num1 = 1000 + randomNumbers.nextInt(9999);//generates four digit number
                num2 = 1000 + randomNumbers.nextInt(9999);//generates four digit number
                break;
        }//end switch
    }//end generateNumbers()

    /**
     * evaluates comment to be outputted based on the student's performance with respect to each question
     * @param passed the state whether a student passed or failed a question
     * @return 
     */
    private static String comments(boolean passed) {
        Random randomComments = new Random();
        String comment = null;
        int pass = 1 + randomComments.nextInt(4);
        if (passed == true) {//an instant where a pupil supplies one correct answer
            switch (pass) {
                case 1:
                    comment = "Very good!";
                    break;
                case 2:
                    comment = "Excellent!";
                    break;
                case 3:
                    comment = "Nice Work!";
                    break;
                case 4:
                    comment = "Keep up the good work!";
                    break;
            }//end switch
        }//end if
        else {//an instant where a pupil supplies one wrong answer
            switch (pass) {
                case 1:
                    comment = "No. Please Try again.";
                    break;
                case 2:
                    comment = "Wrong. Try once more";
                    break;
                case 3:
                    comment = "Don't give up!";
                    break;
                case 4:
                    comment = "No. keep trying";
                    break;
            }//end switch 
        }//end else
        return comment;
    }//end comments()

/**
 * evaluates the type of question the user choose
 * @param type
 * @return 
 */
    private static String questionType(int type) {
        String question = null;
        switch (type) {
            case 1:
                question = "+";
                break;
            case 2:
                question = "-";
                break;
            case 3:
                question = "*";
                break;
            case 4:
                question = "/";
                break;
            case 5:
                question = "random";
                break;
        }//end switch
        return question;
    }//end questionType()

/**
 * prompts
 */
    private static void prompt() {
        final int numOfTrials = 2;
        int difficulttyLevel;//holds the difficulty level 
        int counter = 0;
        String qstType;
        Scanner input = new Scanner(System.in);

        //prompts  for question type i.e +,-,*, or / questions
        System.out.println("Enter question type");
        System.out.println("enter 1 for Addition\n enter 2 for Subtraction\n enter 3 for  Multiplication"
                + " \n enter 4 for Division \n enter 5 for random");
        qstType = questionType(input.nextInt());//saves question type

        //prompts for difficulty level
        System.out.println("Enter Difficulty level");
        System.out.println("enter 1 for easy\n enter 2 for difficult\n enter 3 for very difficult"
                + " \n enter 4 for expert");
        difficulttyLevel = input.nextInt();//saves difficultyLevel

        //to generate question within desired range with respect to choices of question  type and difficultyLevel
        problem(qstType, difficulttyLevel);
    }//end prompt()

    //generates question due to type selected i.e +,-,*, or / questions
    private static void generateProblem(String operator) {
        Scanner input = new Scanner(System.in);

        switch (operator) {
            case "+":
                System.out.println(" How much is " + getNum1() + " + " + getNum2() + " ? ");
                correctAns = getNum1() + getNum2();
                pupilAns = input.nextInt();
                break;

            case "-":
                System.out.println(" How much is " + getNum1() + " - " + getNum2() + " ? ");
                correctAns = getNum1() - getNum2();
                pupilAns = input.nextInt();
                break;
            case "*":
                System.out.println(" How much is " + getNum1() + " * " + getNum2() + " ? ");
                correctAns = getNum1() * getNum2();
                pupilAns = input.nextInt();
                break;

            case "/":
                System.out.println(" How much is " + getNum1() + " / " + getNum2() + " ? ");
                correctAns = getNum1() * getNum2();
                pupilAns = input.nextInt();
                break;

            default:
                break;//random case, yet to be evaluated

        }//end switch
    }//end generatePrblem()

    private static void problem(String operator, int difficulttyLevel) {
        boolean status;
        int counter = 0;
        boolean promoted;
        final int numOfTrials = 5;
        Scanner input = new Scanner(System.in);

        while (counter <= numOfTrials) {
            //generates random numbers to be used with regards to already selected difficulty level
            generateNumbers(difficulttyLevel);

            //generates question  with regards to already selected question type
            generateProblem(operator);

            //validates pupil's answer
            if (pupilAns == correctAns) {//pupil entered the correct answer
                System.out.println(comments(true));
                status = true;
                numOfPasses++;
                counter++;
            }//end if
            else {//pupil entered the wrong answer
                System.out.println(comments(false));
                status = false;
                numOfFailures++;
                counter++;

                //repeats the same question while pupil supplies the wrong answer
                while (status == false && counter <= numOfTrials) {
                    generateProblem(operator);
                    if (pupilAns == correctAns) {//pupil entered the correct answer
                        System.out.println(comments(true));
                        status = true;
                        numOfPasses++;
                        counter++;
                    }//end if
                    else {//pupil entered the wrong answer
                        System.out.println(comments(false));
                        status = false;
                        numOfFailures++;
                        counter++;
                    }//end else
                }//end while-loop
            }//end else
        }//end  while loop

        promoted = isPromoted(numOfPasses, numOfFailures);
        if (promoted == true) {
            System.out.println(" \n\nYou are ready to go to the next level !");
            System.out.println("Please give way for next student \n\n\n");
            prompt();//recursion
        }//end if
        else {
            System.out.println("\n\n Please ask your teacher for extra help ");
            System.out.println("Please give way for next student \n\n\n");
            prompt();//recursion
        }//end else

    }//end multiplicationProblem()

    //evaluates pupils result based on performance
    private static boolean isPromoted(int passes, int failures) {
        boolean status = false;
        double passedPercentage;
        passedPercentage = (double) passes / (passes + failures) * 100;
        if (passedPercentage >= 75) {
            status = true;
        }//end if
        else {
            status = false;
        }//end else
        return status;
    }// end isPromoted()

    public static void main(String[] args) {
        prompt();
    }//end main()
}//end clas CAI

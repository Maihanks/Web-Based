/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package com.maihanks.FileDatabaseManager;

import java.io.FileNotFoundException;
import java.io.FileWriter;
import java.io.IOException;
import java.io.PrintWriter;
import java.util.ArrayList;
import javax.swing.JOptionPane;

public class WriteToFile {
private ArrayList<String> fileContent = new ArrayList<>();//content o file
private     String directory;//file directory
    public WriteToFile(String dir) {
        directory = dir;
    }

    public void setDirectory(String fileDir) {
        directory = fileDir;
    }//end method setDirectory

    public String getDirectory() {
        return (directory);
    }//end method getDirectory()

    public void write(String text) {
        String[] textArray = new String [1];
        textArray[0] = text;
        write(textArray);
    }//end writeToFile()
    public void write(String[] text) 
    //write's array to file where each each elemennt is written as a a single new line of string
    {
        try {
            ReadFromFile readFromFile = new ReadFromFile(directory);;//updates global variable fileContent[] with contents of file
            fileContent = readFromFile.getFileContent();
            FileWriter FileWriterObj = new FileWriter(directory);
            PrintWriter PrintWriterObj = new PrintWriter(FileWriterObj);
            String txt = "";
            if(fileContent.size() > 0){//there was record in file
            for (int a = 0; a < fileContent.size(); a++) {
               PrintWriterObj.println(fileContent.get(a));//writes to contentdts of array  fileContent to file  
            }//end for loop
            }//end if
            for (int b = 0; b < text.length; b++) {
                //System.out.println(fileContent[a]);
                PrintWriterObj.println(text[b]);//writes to contentdts of array  fileContent to file 
            }//end for loop
            PrintWriterObj.close();
        } catch (FileNotFoundException e) {
            JOptionPane.showMessageDialog(null, "File not found", "Error Message", JOptionPane.ERROR_MESSAGE);
             System.exit(1);
        } catch (IOException e) {
            JOptionPane.showMessageDialog(null, "Error accessing file", "Error Message", JOptionPane.ERROR_MESSAGE);
            System.exit(1);
        }//catch 
    }//end method writeToFile

}//end class WriteToFile

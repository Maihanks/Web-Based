/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package com.maihanks.FileDatabaseManager;

import java.io.IOException;
import java.util.ArrayList;

/**
 *
 * @author MAIHANKS
     */
public class WriteToFileTest {
    public static void main(String[] args) throws IOException {
        //src\com\maihanks\Resources\Database
        String fileDirectory = "src\\com\\maihanks\\Resources\\Database\\OverseerBiodata.txt";
       String[] text = new String[10];
       for(int i = 0; i < text.length; i++){
            text[i] = ""+i;
        }//end for loop
        WriteToFile WriteToFileObj1 = new WriteToFile(fileDirectory);
        WriteToFileObj1.write(text);
        ReadFromFile rff = new ReadFromFile(fileDirectory);
        ArrayList<String>  a ;//= new ArrayList<>();
        a =  rff.getFileContent();
        for( int x = 0; x < a.size(); x++){
            System.out.println(a.get(x));
        }

    }//end method main
}

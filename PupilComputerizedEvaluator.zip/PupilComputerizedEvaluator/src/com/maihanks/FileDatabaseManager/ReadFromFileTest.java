/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package com.maihanks.FileDatabaseManager;
import java.util.ArrayList;
import java.util.Random;
/**
 *
 * @author MAIHANKS
 */
public class ReadFromFileTest {
    public static void main(String[] args){
     String fileDirectory = "src\\com\\maihanks\\Resources\\Database\\OverseerBiodata.txt";
        ReadFromFile readFromFile = new  ReadFromFile(fileDirectory);
       // ArrayList<String> list;
        //list = new ArrayList()<>;
       //list = readFromFile.getFileContent();
       
      // for(int a = 0; a < list.size(); a++){
        //   System.out.println(list.get(a));
      // }
    /* Database database = new Database(fileDirectory);
     database.write("Hello Every body");
     String s [] = database.getAllRows();
     for(int a = 0; a<s.length; a++){
         System.out.println(s[a]);
     }*/
        ArrayList<String>  a;
        a = readFromFile.getFileContent();
        
        for(int i = 0; i< a.size(); i++){
            System.out.println(a.get(i));
        }
     
    }//end main
}

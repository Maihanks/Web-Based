/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package com.maihanks.FileDatabaseManager;

import java.io.FileNotFoundException;
import java.io.FileWriter;
import java.io.IOException;
import java.io.PrintWriter;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.StringTokenizer;
import javax.swing.JOptionPane;

/**
 *
 * @author MAIHANKS
 */
public class Database {
/**
 * author maihanks(maihankspinas@gmail.com , 08068816818)
 * This class manages read and write to text file databases a database in this context is a text file
 * all fields of a record are represented by a single string which contains where all attributes of that row are seperate by a delimeter
 * eg a record might be saved as Adam~male~Nigeria 
 */
    private String fileDirectory;
    private ArrayList<String> attributes = new ArrayList<>();
    private int numberOfFields;//number of columns in database
    private ReadFromFile read;//to read record from database
    private final String delimeter = "~";
    private int numberOfRows;//number of rows in database
    private ArrayList<String> fileContent;
    public Database(String theFileDirectory) {
        fileDirectory = theFileDirectory;
        read = new ReadFromFile(fileDirectory);
        setAttributes();//intializes attributes
    }//end constructor

    /**
     * returns the directory of the file from which data is read from
     *author maihanks(maihankspinas@gmail.com , 08068816818)
     * @return
     */
    public String getFileDirectory() {
        return fileDirectory;
    }

    /**
     * resets the directory from which data is read from
     *author maihanks(maihankspinas@gmail.com , 08068816818)
     * @param theFileDirectory
     */
    public void setFileDirectory(String theFileDirectory) {
        fileDirectory = theFileDirectory;
    }

    public String getDelimeter() {
        return delimeter;
    }
    

    /**
     * returns the number of fields i.e as delimited by the delimeter "~"
     *
     * @return
     */
    public int getNumberOfFields() {
        return numberOfFields;
    }

    /**
     * returns the number of rows in the file
     *
     * @return
     */
    /**
     * returns the number of rows contained in the file
     *
     * @return
     */
    public int getNumberOfRows() {
        return numberOfRows;
    }

    private void setNumberOfRows() {
        numberOfRows = attributes.size();
    }

    /**
     * sets the number of fields present according to the number of delimeters
     * encountered in the file delimeter = "|"
     */
    private void setNumberOfFields() {
        try {
            String[] row = getAllRows()[0].split(delimeter);
            numberOfFields = row.length;
        } catch (Exception e) {
            numberOfFields = 0;
        }
    }//end setNumberOfFields()

    /**
     * initializes instance variable array list attributes with the whole
     * content of the directory given
     */
    private void setAttributes() {
        attributes = read.getFileContent();
        setNumberOfRows();
        setNumberOfFields();
    }

    /**
     * this method returns the whole content of a file where each element is a
     * row in the file, according to the order it appears in the file all
     * attributes of a row are returned as a single String
     *
     * @return
     */
    public String[] getAllRows() {
        String[] rows = new String[attributes.size()];//array has thesame size as attributes
        for (int counter = 0; counter < attributes.size(); counter++) {
            rows[counter] = attributes.get(counter);
        }//end for loop
        return rows;
    }

    /**
     * returns all components of a row as a single string
     *
     * @param rowPosition
     * @return
     */
    private String getRow(int rowPosition) {
        return getAllRows()[rowPosition];
    }

    /**
     * this overloaded method accepts an integer parameter(rowPosition) uses the
     * row position to return all attributes of this row as an array a row
     * position falls between 0 and n-1, where n is the value returned by method
     * getNumberOfRows()
     *
     * @param rowPosition
     * @return
     */
    public String[] getSingleRowAttributes(int rowPosition) {
        String[] fields = getAllRows()[rowPosition].split(delimeter);
        return fields;
    }

    /**
     * this overloaded method accepts a String parameter(rowValue) that is most
     * likely to be an element of the the array returned by method
     * getAllRowsWithAttributeMatch()
     *
     * @param rowValue the row whose attributes are to be returned as an array
     * containing the row's attributes
     * @return
     */
    public String[] getSingleRowAttributes(String rowValue) {
        StringTokenizer token1;
        token1 = new StringTokenizer(rowValue,delimeter);
        String[] fields = new String[token1.countTokens()];
        int counter = 0;
        while(token1.hasMoreTokens()){
            fields[counter] = token1.nextToken();
            counter++;
        }
        //String[] fields = new String[token1.countTokens()]; //rowValue.split(delimeter);
        return fields;
    }//end getSingleRowAttributes()

    /**
     * returns all values corresponding to this column, a column position i.e
     * 0<= columnPosition <=n-1, where n is the number of columns available, the
     * first column has columnPosition = 0 and the last column has
     * columnPosition = n - 1
     *
     *
     *

     *
     * @param columnPosition
     * @return
     */
    public String[] getAllColumnValues(int columnPosition) {
        String[] columnValues = new String[getNumberOfRows()];
        if ((columnPosition >= 0) && (columnPosition < getNumberOfFields())) {//column position is valid
            String[] rows = getAllRows();
            String row;
            String[] rowAtributes = new String[this.getNumberOfFields()];
            for (int a = 0; a < rows.length; a++) {//loops through all rows
                row = rows[a];//gets each row
                rowAtributes = row.split(delimeter);//gets the individual attributes of a row 
                columnValues[a] = rowAtributes[columnPosition];//gets a particular attribute for each row
            }//end for
        }//end if
        return columnValues;
    }

    /**
     * This method returns an array containing(as strings) all rows whose
     * column(int columnPosition) value match the searchKeyAttributeValue value
     * it is equivalent to the query "select * from tabeleName where fieldName =
     * 'fieldValue'" in this case, the field names are identified by position
     * i.e the first field name has position zero(0) and the last field has
     * position n-1, this method returns null if no match was found otherwise it
     * returns a number of matching rows equivalent to the size of the returned
     * String array. To get the attributes of the returned row, elements of the
     * array returned by this method should be passed as arguments to overloaded
     * method getSingleRowAttributes(String rowValue) - hence each element of
     * the array returned by getSingleRowAttributes(String rowValue) is an
     * attribute of the index passed to it. attributes occur ass elements of the
     * array according to how they are declared in the database(text file)
     *
     * @param columnPosition
     * @param searchKeyAttributeValue
     * @return
     */
    public String[] getAllRowsWithAttributeMatch(int columnPosition, String searchKeyAttributeValue) {
        String[] tempRow = new String[this.getNumberOfRows()];//a temporary array whose size  is the number of rows
        int tempIndex = 0;
        
        for (int a = 0; a < this.getNumberOfRows(); a++) {//loops through all rows 
            if (searchKeyAttributeValue.equals(getSingleRowAttributes(a)[columnPosition])) {//gets desired column value of a particular row
                tempRow[tempIndex] = this.getRow(a);//gets this row that matches search requirement
                tempIndex++;//increments index
            }//end if
            else{
                
            }
        }//end for loop
      
        String[] matchRow;//array to contain search result
        if (tempIndex > 0) {//atleast one row met the search requirements
            matchRow = new String[tempIndex + 1];//array that contains search result
            System.arraycopy(tempRow, 0, matchRow, 0, tempIndex);//populates array matchRow
            return matchRow;
        }//end if
        else {//no row met the search requirements
            matchRow = null;
        }//end else
        
        return matchRow;
    }//end getAllRowsWithAttributeMatch()

    /**
     * This method sends record(a string) to the file
     *
     * @param text
     */
    public void write(String text) {
        String[] textArray = new String[1];
        textArray[0] = text;
        write(textArray);
    }//end writeToFile()

    /**
     * This method sends record(array of strings) to the file
     *
     * @param text
     */
    public void write(String[] text) //write's array to file where each each elemennt is written as a a single new line of string
    {
        try {
            ReadFromFile readFromFile = new ReadFromFile(fileDirectory);;//updates global variable fileContent[] with contents of file
            fileContent = readFromFile.getFileContent();
            FileWriter FileWriterObj = new FileWriter(fileDirectory);
            PrintWriter PrintWriterObj = new PrintWriter(FileWriterObj);
            String txt = "";
            if ( (fileContent.size() > 0 )) {//there was record in file
                for (int a = 0; a < fileContent.size(); a++) {
                    PrintWriterObj.println(fileContent.get(a));//writes to contentdts of array  fileContent to file  
                }//end for loop
            }//end if
            for (int b = 0; b < text.length; b++) {
                //System.out.println(fileContent[a]);
                PrintWriterObj.println(text[b]);//writes to contentdts of array  fileContent to file 
            }//end for loop
            PrintWriterObj.close();
        } catch (FileNotFoundException e) {
            JOptionPane.showMessageDialog(null, "File not found", "Error Message", JOptionPane.ERROR_MESSAGE);
            System.exit(1);
        } catch (IOException e) {
            JOptionPane.showMessageDialog(null, "Error accessing file", "Error Message", JOptionPane.ERROR_MESSAGE);
            System.exit(1);
        }//catch 
    }//end method writeToFile    
    public static void main(String[] args) {
        Database db = new Database("clients.txt");
        // for(int a = 0; a < db.getNumberOfRows(); a++){
        // System.out.println(db.getAllRows()[0]);
        // }//end for
        // for (int i = 0; i < db.getNumberOfFields(); i++) {
        //   System.out.println(db.getSingleRowAttributes(1)[i]);
        // }
        //String[] array  = db.getAllRowsWithAttributeMatch(0, "Okwuma Timothy");
      /*  String[] array  = db.getAllRowsWithAttributeMatch(0, "Maihankali Munura");
         if(array == null){
         System.out.println("No match found");
         }else{
         System.out.println("Match found");
         String[] arrayContents =  db.getSingleRowAttributes(array[0]);
         for(String content : arrayContents){
         // db.getSingleRowAttributes(content)
         System.out.println(content);
         }//end for
         }
         */

    }
}
